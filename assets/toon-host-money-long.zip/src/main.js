// Boot: fonts → script + timing → captions → shots. Then draw(t) renders film time t (pure function of t).
// window.OP is the API tools/capture.mjs drives: ready, bootError, duration(), draw(t), frame(t, q), cues(), shots().
import { W, H, setCtx, ctx, clamp, eo, eio } from './core/lib.js';
import { T, loadTiming } from './core/timing.js';
import { buildCaptions, drawCaption, captionList } from './core/captions.js';
import { buildShots } from './shots.js';

const cv = document.getElementById('cv');
setCtx(cv.getContext('2d'));
const OP = (window.OP = { ready: false });


// Channel watermark: small RR badge, top-left, faint. Fades with the film. Remove this call to ship without it.
function drawWatermark() {
  const badge = OP.script && OP.script.badge !== undefined ? OP.script.badge : 'RR';   // script.json "badge": "" = none, or other initials
  if (!badge) return;
  const x = 70, y = 66, r = 30;
  ctx.save(); ctx.globalAlpha = 0.7; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fillStyle = '#FFE48A'; ctx.fill();
  ctx.lineWidth = 5; ctx.strokeStyle = '#17211D'; ctx.stroke();
  ctx.font = (badge.length > 2 ? '900 18px Inter' : '900 27px Inter'); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.letterSpacing = '1px';
  ctx.fillStyle = '#17211D'; ctx.fillText(badge, x, y + 2);
  ctx.restore(); ctx.globalAlpha = 1; ctx.letterSpacing = '0px';
}

function draw(t) {
  t = clamp(t, 0, T.dur - 1e-4);
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.letterSpacing = '0px';
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  const S = OP._shots; let i = S.length - 1; while (i > 0 && S[i].at > t) i--;
  const sh = S[i], end = i < S.length - 1 ? S[i + 1].at : T.dur, d = end - sh.at, lt = t - sh.at;
  // camera: punch-in on the cut + a slow push across the shot ("camera always moving")
  const punch = 1 + 0.035 * (1 - eo(clamp(lt / 0.5)));
  const drift = 1 + (sh.zoom ?? 0.06) * eio(clamp(lt / d));
  const [cx, cy] = sh.cam || [W / 2, H / 2];
  ctx.save(); ctx.translate(cx, cy); ctx.scale(punch * drift, punch * drift); ctx.translate(-cx, -cy);
  sh.draw(lt, d, t);
  ctx.restore();
  ctx.globalAlpha = 1; ctx.letterSpacing = '0px';
  if (i > 0 && lt < 0.12) { ctx.fillStyle = '#FFFFFF'; ctx.globalAlpha = 0.18 * (1 - lt / 0.12); ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  drawWatermark();
  // fade from / to black on the first and last 0.25 s
  const fade = Math.min(clamp(t / 0.25), clamp((T.dur - t) / 0.35));
  if (fade < 1) { ctx.fillStyle = '#000'; ctx.globalAlpha = 1 - fade; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  if (!new URLSearchParams(location.search).has('nocap')) drawCaption(t);
}

(async () => {
  try {
    await document.fonts.load('900 100px Inter');
    if (new URLSearchParams(location.search).has('sheet')) {   // style sheet mode: draws the one-image look guide (src/sheet.js)
      const { drawSheet } = await import('./sheet.js');
      OP.duration = () => 1; OP.draw = () => drawSheet(); OP.frame = () => { drawSheet(); return cv.toDataURL('image/png'); };
      OP.shots = () => []; OP.captions = () => []; OP.cues = () => []; OP.ready = true; return;
    }
    if (new URLSearchParams(location.search).has('thumb')) {
      const { drawThumb } = await import('./thumb.js');
      OP.duration = () => 1; OP.draw = () => drawThumb(); OP.frame = () => { drawThumb(); return cv.toDataURL('image/png'); };
      OP.shots = () => []; OP.captions = () => []; OP.cues = () => []; OP.ready = true; return;
    }
    const script = await (await fetch('script.json', { cache: 'no-store' })).json();
    await loadTiming();
    buildCaptions(script);
    const { shots, cues } = buildShots();
    shots.sort((a, b) => a.at - b.at);
    OP._shots = shots; OP.script = script;
    OP.duration = () => T.dur;
    OP.draw = draw;
    OP.frame = (t, q = 0.92) => { draw(t); return cv.toDataURL('image/jpeg', q); };
    OP.shots = () => shots.map((s, i) => ({ id: s.id, at: +s.at.toFixed(3), end: +(i < shots.length - 1 ? shots[i + 1].at : T.dur).toFixed(3), note: s.note || '' }));
    OP.captions = () => captionList().map((c) => ({ s: +c.s.toFixed(3), e: +c.e.toFixed(3), text: c.words.map((w) => (w.hi ? '*' : '') + w.txt).join(' ') }));
    OP.cues = () => cues.slice().sort((a, b) => a.t - b.t);
    OP.ready = true;
    // preview mode (not capture): play in real time, ?t=12.3 to hold a frame
    const q = new URLSearchParams(location.search);
    if (!q.has('capture')) {
      if (q.has('t')) draw(+q.get('t'));
      else {
        const audio = new Audio('data/mix.wav'); let t0 = null;
        const btn = document.getElementById('play'); btn.hidden = false;
        btn.onclick = () => { btn.hidden = true; t0 = performance.now(); audio.currentTime = 0; audio.play().catch(() => {}); };
        const loop = (now) => { const t = t0 == null ? 0 : (now - t0) / 1000; draw(t0 == null ? 0 : t); if (t0 != null && t > T.dur) { t0 = null; btn.hidden = false; } requestAnimationFrame(loop); };
        requestAnimationFrame(loop);
      }
    }
  } catch (e) { OP.bootError = String(e && e.stack || e); console.error(e); }
})();
