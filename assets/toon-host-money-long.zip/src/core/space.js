// LONG-FORM component set (landscape 1920x1080): clean backgrounds, rocket, drone ship, diagrams, labels.
// Same Toon Host rules: flat fills, thick wobbly ink outline, one orange accent. Import as `R`.
// LAYOUT GRID: margins >= 120 px; the bottom 150 px (y > 930) belong to the subtitle; at most ONE focal object per shot.
import { ctx, C, W, H, TAU, INK, lerp, clamp, seg, eo, eio, eob, rnd, circle, ell, line, fillAll, blob, poly, wEll, wRect, inkLine } from './lib.js';

export const SKY = '#D5E6F3', SKY_LO = '#BAD7EC', NAVY = '#222C40', SEA = '#4A7FB5', SEA_HI = '#86AACD', DECK = '#6B6762';
export const SAFE = { l: 120, r: W - 120, t: 110, b: 920 };

// ───────────── text + labels ─────────────
export function txt(s, x, y, size = 44, color = C.ink, align = 'center', ls = 1) {
  ctx.save(); ctx.font = `900 ${size}px Inter`; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.letterSpacing = ls + 'px'; ctx.fillText(s, x, y); ctx.restore();
}
/** white label pill with ink outline (the one label style for the whole video). sc = pop. hi = orange fill */
export function pill(text, x, y, size = 40, sc = 1, o = {}) {
  if (sc <= 0) return 0;
  ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc); ctx.font = `900 ${size}px Inter`; ctx.letterSpacing = '1px';
  const w = ctx.measureText(text).width + size * 1.1, h = size * 1.55;
  wRect(-w / 2, -h / 2, w, h, h * 0.4, o.hi ? C.orange : (o.bg || C.white), { seed: text.length + 5, lw: 6 });
  ctx.fillStyle = o.hi ? C.ink : (o.fg || C.ink); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, 0, size * 0.04);
  ctx.letterSpacing = '0px'; ctx.restore(); return w;
}
/** pill with a pointer line + dot to (tx, ty) */
export function callout(text, x, y, tx, ty, size = 40, sc = 1, o = {}) {
  if (sc <= 0) return;
  ctx.save(); ctx.globalAlpha = clamp(sc); inkLine([[x, y], [tx, ty]], C.ink, 4, 0); circle(tx, ty, 11, C.orange); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.restore();
  pill(text, x, y, size, sc, o);
}
/** top-left chapter tag: slides in, holds, fades (lt = time in the chapter's first shot) */
export function chapterTag(num, title, lt) {
  const a = Math.min(eo(seg(lt, 0, 0.45)), 1 - seg(lt, 3.4, 4.0)); if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = a; ctx.translate((1 - eo(seg(lt, 0, 0.45))) * -60, 0);
  ctx.font = '900 34px Inter'; ctx.letterSpacing = '2px';
  const label = `${String(num).padStart(2, '0')}   ${title}`, w = ctx.measureText(label).width + 84;
  wRect(128, 36, w, 62, 31, C.white, { seed: 31, lw: 6 });
  circle(128 + 31, 67, 15, C.orange); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.fillStyle = C.ink; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(label, 128 + 58, 69);
  ctx.letterSpacing = '0px'; ctx.restore();
}
/** progress pills for the 4 landing steps, top centre. active = 0..3 (fractional ok), labels fixed */
export function stepTracker(active, a = 1) {
  if (a <= 0) return;
  const L = ['1  FLIP', '2  BOOSTBACK', '3  ENTRY BURN', '4  LANDING BURN'];
  ctx.save(); ctx.globalAlpha = a; ctx.font = '900 28px Inter'; ctx.letterSpacing = '1px';
  const ws = L.map((s) => ctx.measureText(s).width + 48), gap = 18, total = ws.reduce((p, q) => p + q, 0) + gap * 3;
  let x = W / 2 - total / 2;
  L.forEach((s, i) => {
    const on = Math.round(active) === i;
    wRect(x, 62, ws[i], 56, 28, on ? C.orange : C.white, { seed: 40 + i, lw: 5 });
    ctx.fillStyle = on ? C.white : '#7A7570'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x + ws[i] / 2, 92);
    x += ws[i] + gap;
  });
  ctx.letterSpacing = '0px'; ctx.restore();
}

// ───────────── backgrounds (flat) ─────────────
export function cloud(x, y, s = 1, a = 1) {
  ctx.save(); ctx.globalAlpha = a; ctx.translate(x, y); ctx.scale(s, s);
  wEll(-60, 8, 80, 42, C.white, { seed: 61, lw: 5 }); wEll(30, -14, 92, 56, C.white, { seed: 62, lw: 5 }); wEll(110, 14, 70, 38, C.white, { seed: 63, lw: 5 });
  ctx.fillStyle = C.white; ctx.fillRect(-100, 4, 250, 28);
  ctx.restore();
}
export function sky(t = 0, low = true) {
  fillAll(SKY);
  if (low) { ctx.fillStyle = SKY_LO; ctx.fillRect(-300, 560, W + 600, 700); }
  cloud(((300 + t * 14) % (W + 500)) - 250, 250, 1.1, 0.95); cloud(((1250 + t * 9) % (W + 500)) - 250, 170, 0.8, 0.95); cloud(((820 + t * 11) % (W + 500)) - 250, 420, 0.7, 0.9);
}
export function space(t = 0, limb = true) {
  fillAll(NAVY);
  for (let i = 0; i < 70; i++) {
    const x = rnd(i) * W, y = rnd(i + 90) * (limb ? 800 : H), r = 1.4 + rnd(i + 200) * 2.2, tw = 0.55 + 0.45 * Math.sin(t * 1.5 + i);
    ctx.globalAlpha = 0.5 + 0.5 * tw; circle(x, y, r, C.white);
  }
  ctx.globalAlpha = 1;
  if (limb) { circle(W / 2, 1980, 1100 + 26, SEA_HI); circle(W / 2, 1980, 1100, C.blue); ctx.beginPath(); ctx.arc(W / 2, 1980, 1100, 0, TAU); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); }
}
export function paper() {
  fillAll(C.paper); ctx.fillStyle = C.paperLine;
  for (let x = 60; x < W; x += 60) for (let y = 60; y < H; y += 60) circle(x, y, 2.4, C.paperLine);
}
export function studio(fy = 880) {
  fillAll(C.bg); ctx.fillStyle = C.floor; ctx.fillRect(-300, fy, W + 600, 700); ctx.fillStyle = C.floorLine; ctx.fillRect(-300, fy, W + 600, 6);
}
export function sea(y = 800, t = 0) {
  ctx.fillStyle = SEA; ctx.fillRect(-300, y, W + 600, 700);
  ctx.fillStyle = C.ink; ctx.fillRect(-300, y - 3, W + 600, 6);
  ctx.strokeStyle = SEA_HI; ctx.lineWidth = 6; ctx.lineCap = 'round';
  for (let r = 0; r < 4; r++) for (let i = -1; i < 9; i++) {
    const x = i * 260 + ((t * (22 + r * 6) + r * 90) % 260), yy = y + 40 + r * 52;
    ctx.beginPath(); ctx.moveTo(x, yy); ctx.quadraticCurveTo(x + 40, yy - 14, x + 80, yy); ctx.stroke();
  }
}
export function surf(y, t = 0, h = 70) {   // front strip of water, drawn after the ship so the hull sits IN the sea
  ctx.fillStyle = SEA; ctx.fillRect(-300, y, W + 600, h + 700); ctx.fillStyle = SEA_HI;
  for (let i = -1; i < 12; i++) { const x = i * 190 + ((t * 40) % 190); ctx.beginPath(); ctx.ellipse(x, y + 4, 54, 7, 0, 0, TAU); ctx.fill(); }
}
export function pad(y, x0 = -300, x1 = W + 300) {
  ctx.fillStyle = C.floor; ctx.fillRect(x0, y, x1 - x0, 400); ctx.fillStyle = C.ink; ctx.fillRect(x0, y - 3, x1 - x0, 6);
}

// ───────────── the rocket ─────────────
function fin(x, y, open, side) {
  const w = lerp(9, 76, open), h = lerp(74, 56, open);
  ctx.save(); ctx.translate(x, y); ctx.scale(side, 1);
  wRect(0, -h / 2, w, h, 4, C.sweater, { lw: 6, wob: 1, seed: 71 });
  ctx.strokeStyle = C.grayLight; ctx.lineWidth = 3;
  const n = Math.round(w / 15);
  for (let i = 1; i < n; i++) { ctx.beginPath(); ctx.moveTo(i * w / n, -h / 2 + 6); ctx.lineTo(i * w / n, h / 2 - 6); ctx.stroke(); }
  if (open > 0.3) for (const f of [-0.18, 0.18]) { ctx.beginPath(); ctx.moveTo(5, h * f); ctx.lineTo(w - 5, h * f); ctx.stroke(); }
  ctx.restore();
}
export function exhaust(x, y, len, w, t, seed = 0) {
  if (len <= 4) return;
  const f = Math.sin(t * 22 + seed) * 0.06;
  ctx.save(); ctx.translate(x, y);
  blob([[-w, 0], [-w * 0.85, len * 0.35], [-w * 0.35, len * 0.8], [0, len * (1 + f)], [w * 0.35, len * 0.8], [w * 0.85, len * 0.35], [w, 0]], C.orange, { seed: 81 + seed, wob: 1.5, lw: 6 });
  blob([[-w * 0.5, 0], [-w * 0.42, len * 0.3], [0, len * 0.62 * (1 + f)], [w * 0.42, len * 0.3], [w * 0.5, 0]], C.yellow, { seed: 82 + seed, wob: 1, lw: 0 });
  ctx.restore();
}
/** Falcon-9-style first stage, origin = stage centre (about 614 tall at s = 1: top -330, nozzles -> +284).
 *  o: { rot, legs 0..1, fins 0..1 (grid fins deployed), flame 0..1 (exhaust length), nozzles (1|3 flames), t, puffs 0..1 (nitrogen),
 *       upper (gap px above the interstage: draws the second stage), upperFlame 0..1 } */
export function rocket(x, y, s = 1, o = {}) {
  const { rot = 0, legs = 0, fins = 0, flame = 0, nozzles = 3, t = 0, puffs = 0, upper = null, upperFlame = 0 } = o;
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  // exhaust (behind everything)
  if (flame > 0) { const xs = nozzles === 1 ? [0] : [-26, 0, 26]; xs.forEach((nx, i) => exhaust(nx, 282, 230 * flame * (nozzles === 1 ? 1 : 0.85), nozzles === 1 ? 20 : 15, t, i)); }
  // legs (two visible): hinge at the lower body, fold out to the feet
  if (legs > 0) for (const sd of [-1, 1]) {
    const foot = [sd * lerp(56, 168, eio(legs)), lerp(292, 340, eio(legs))];
    inkLine([[sd * 44, 146], foot], C.sweater, 12, 5);
    wRect(foot[0] - 22, foot[1] - 5, 44, 14, 5, C.sweater, { seed: 90 + sd, lw: 5, wob: 0.8 });
  }
  // body
  wRect(-48, -300, 96, 520, 12, C.white, { seed: 11, lw: 0 });
  ctx.fillStyle = C.shoeShade; ctx.fillRect(22, -292, 20, 504);
  ctx.fillStyle = C.gray; ctx.fillRect(-45, 150, 90, 66);
  wRect(-48, -300, 96, 520, 12, null, { seed: 11 });
  wRect(-48, -332, 96, 68, 10, C.sweater, { seed: 12 });
  // engines
  wRect(-40, 216, 80, 30, 6, C.sweater, { seed: 13 });
  [-26, 0, 26].forEach((nx, i) => poly([[nx - 13, 244], [nx + 13, 244], [nx + 19, 284], [nx - 19, 284]], C.gray, { seed: 14 + i, wob: 1, lw: 5 }));
  // grid fins
  fin(-48, -250, fins, -1); fin(48, -250, fins, 1);
  // nitrogen puffs
  if (puffs > 0) for (const sd of [-1, 1]) for (let i = 0; i < 3; i++) {
    const p = (t * 1.6 + i / 3 + (sd > 0 ? 0.15 : 0)) % 1, r = 8 + 14 * p;
    ctx.globalAlpha = puffs * (1 - p); circle(sd * (58 + p * 70), -310 - p * 10 - i * 4, r, C.white); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke();
  }
  ctx.globalAlpha = 1;
  // second stage + fairing, floating above (separation)
  if (upper !== null) {
    const gy = -332 - upper;
    exhaust(0, gy - 6, 120 * upperFlame, 12, t, 5);
    poly([[-14, gy - 4], [14, gy - 4], [20, gy - 30], [-20, gy - 30]], C.gray, { seed: 21, wob: 1, lw: 5 });
    wRect(-48, gy - 330, 96, 300, 12, C.white, { seed: 22 });
    blob([[-48, gy - 330], [-36, gy - 410], [0, gy - 470], [36, gy - 410], [48, gy - 330]], C.white, { seed: 23, wob: 1.2 });
  }
  ctx.restore();
}

// ───────────── drone ship ─────────────
/** side view; y = deck top; w = width. Hull sits in the water: draw R.surf() after it. */
export function ship(x, y, w, t = 0, name = null) {
  const bob = Math.sin(t * 1.3) * 3, hh = w * 0.14;
  ctx.save(); ctx.translate(x, y + bob);
  poly([[-w / 2, w * 0.03], [w / 2, w * 0.03], [w / 2 - w * 0.035, w * 0.03 + hh], [-w / 2 + w * 0.035, w * 0.03 + hh]], C.sweater, { seed: 101, wob: 1, lw: 6 });
  wRect(-w / 2, 0, w, w * 0.034, 5, DECK, { seed: 102, lw: 6, wob: 1 });
  wRect(w * 0.31, -w * 0.07, w * 0.14, w * 0.07, 5, C.white, { seed: 103, lw: 5 });
  wRect(w * 0.33, -w * 0.053, w * 0.03, w * 0.022, 3, C.blue, { seed: 104, lw: 3 });
  if (name) txt(name, 0, w * 0.03 + hh * 0.5, Math.max(14, w * 0.034), C.white, 'center', 1);
  ctx.restore();
}
/** top view of the deck with the landing target; w = 91 m -> w px */
export function shipTop(x, y, w, t = 0) {
  const h = w * 52 / 91;
  ctx.save(); ctx.translate(x, y);
  wRect(-w / 2, -h / 2, w, h, 14, DECK, { seed: 111, lw: 8 });
  wRect(-w / 2 + 22, -h / 2 + 22, w - 44, h - 44, 8, '#7B7771', { seed: 112, lw: 0 });
  for (const [cx, cy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { wEll(cx * (w / 2 - 20), cy * (h / 2 - 20), 20, 20, C.orange, { seed: 113, lw: 5 }); }
  circle(0, 0, h * 0.34, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke();
  line([[-h * 0.2, -h * 0.2], [h * 0.2, h * 0.2]], C.ink, 12); line([[h * 0.2, -h * 0.2], [-h * 0.2, h * 0.2]], C.ink, 12);
  ctx.restore();
}

// ───────────── diagram helpers ─────────────
/** polyline from a parametric curve fn(u) -> [x, y] for u in [u0, u1], dashed or solid */
export function trail(fn, u0, u1, o = {}) {
  if (u1 <= u0) return;
  const { color = C.ink, w = 8, dash = [24, 18], n = 80, arrow = false } = o;
  ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.setLineDash(dash); ctx.lineWidth = w; ctx.strokeStyle = color; ctx.beginPath();
  for (let i = 0; i <= n; i++) { const [px, py] = fn(lerp(u0, u1, i / n)); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
  ctx.stroke(); ctx.setLineDash([]);
  if (arrow) { const [ax, ay] = fn(u1), [bx, by] = fn(Math.max(u0, u1 - 0.01)), an = Math.atan2(ay - by, ax - bx); ctx.translate(ax, ay); ctx.rotate(an); poly([[0, 0], [-34, -18], [-34, 18]], color, { seed: 121, wob: 0.5, lw: 3 }); }
  ctx.restore();
}
/** plain chunky arrow, ink outline. colour defaults orange. */
export function arrowV(x, y, len, ang, color = C.orange, w = 34) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  poly([[0, -w / 2], [len - 54, -w / 2], [len - 54, -w], [len, 0], [len - 54, w], [len - 54, w / 2], [0, w / 2]], color, { seed: 131, wob: 1, lw: 6 });
  ctx.restore();
}
/** bar (grows upward from baseline y0), p = 0..1 */
export function bar(x, y0, w, h, color, p = 1, seed = 1) {
  const hh = h * clamp(p); if (hh < 4) return;
  wRect(x - w / 2, y0 - hh, w, hh, 12, color, { seed, lw: 7, wob: 1.2 });
}
/** vertical scale with ticks; draws a marker at value v (0..1 from bottom) */
export function ruler(x, y0, y1, ticks, v) {
  inkLine([[x, y0], [x, y1]], C.ink, 4, 0);
  for (let i = 0; i <= ticks; i++) { const yy = lerp(y0, y1, i / ticks); line([[x - 12, yy], [x + 12, yy]], C.ink, 4); }
  const my = lerp(y0, y1, clamp(v)); poly([[x + 16, my], [x + 52, my - 20], [x + 52, my + 20]], C.orange, { seed: 141, wob: 0.5, lw: 4 });
}
export function pie(x, y, r, parts, p = 1, hiIdx = 0) {
  // parts: [{v, color}] summing to 1; drawn clockwise from 12 o'clock, first slice pulled out
  let a0 = -Math.PI / 2; const total = clamp(p) * TAU;
  parts.forEach((pt, i) => {
    const a1 = a0 + pt.v * TAU, e = Math.min(a1, -Math.PI / 2 + total); if (e <= a0) { a0 = a1; return; }
    const mid = (a0 + a1) / 2, off = i === hiIdx ? 22 : 0;
    ctx.save(); ctx.translate(Math.cos(mid) * off, Math.sin(mid) * off);
    ctx.beginPath(); ctx.moveTo(x, y); ctx.arc(x, y, r, a0, e); ctx.closePath(); ctx.fillStyle = pt.color; ctx.fill(); ctx.lineWidth = 8; ctx.lineJoin = 'round'; ctx.strokeStyle = C.ink; ctx.stroke();
    ctx.restore(); a0 = a1;
  });
}
