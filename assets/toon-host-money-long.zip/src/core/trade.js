// Trade props for the Rupee Roots look (flat fill + wobbly ink outline, green + gold). Centred at (x, y), scale s.
import { ctx, C, TAU, wRect, wEll, poly, circle, line, inkLine, lerp } from './lib.js';
const RS = (t, x, y, size, color = C.ink) => { ctx.save(); ctx.font = `900 ${size}px Inter`; ctx.fillStyle = color; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, x, y); ctx.restore(); };

/** oil barrel, 170 x 240 at s = 1 */
export function barrel(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-85, -120, 170, 240, 26, C.ink, { seed: 701, lw: 8 });
  wRect(-85, -120, 170, 240, 26, '#2E3C36', { seed: 701, lw: 8 });
  wRect(-85, -70, 170, 26, 4, C.orange, { seed: 702, lw: 5, wob: 0.6 }); wRect(-85, 44, 170, 26, 4, C.orange, { seed: 703, lw: 5, wob: 0.6 });
  circle(0, -2, 30, C.ink); circle(0, -2, 20, C.orange);
  ctx.restore();
}
/** gold bar (ingot), 300 wide at s = 1 */
export function goldBar(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  poly([[-150, 60], [-110, -50], [110, -50], [150, 60]], C.orange, { seed: 711, wob: 1.2, lw: 8 });
  poly([[-100, -50], [-80, -80], [80, -80], [100, -50]], C.yellow, { seed: 712, wob: 1, lw: 7 });
  RS('GOLD', 0, 4, 52, C.orangeDark);
  ctx.restore();
}
/** cargo ship with containers (460 wide at s = 1), waves are drawn by the caller */
export function cargo(x, y, s = 1, bob = 0, ncont = 6) {
  ctx.save(); ctx.translate(x, y + bob); ctx.scale(s, s);
  const cols = [C.orange, C.green, C.blue, C.red, C.orange, C.green, C.blue, C.red];
  for (let r = 0; r < 2; r++) for (let i = 0; i < ncont; i++) if (r === 0 || i < ncont - 1) wRect(-210 + i * 64, -64 - r * 56, 60, 52, 6, cols[(i + r * 3) % cols.length], { seed: 721 + i + r * 9, lw: 5, wob: 0.8 });
  wRect(190, -130, 70, 110, 8, C.paper, { seed: 731, lw: 6 }); wRect(200, -118, 50, 24, 4, C.blue, { seed: 732, lw: 4, wob: 0.5 });
  poly([[-240, -10], [250, -10], [210, 70], [-200, 70]], C.sweater, { seed: 733, wob: 1.5, lw: 8 });
  ctx.restore();
}
/** simple globe, radius 130 at s = 1 */
export function globe(x, y, s = 1, spin = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  circle(0, 0, 130, C.blue); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.save(); ctx.beginPath(); ctx.arc(0, 0, 124, 0, TAU); ctx.clip();
  const o = ((spin * 60) % 360) - 60;
  for (const [dx, dy, w, h] of [[-90, -40, 90, 70], [30, -60, 80, 90], [60, 40, 70, 60], [-40, 60, 60, 50]]) wEll(dx + o * 0.6, dy, w / 2, h / 2, C.green, { seed: 741 + dx, lw: 5, n: 12 });
  ctx.restore();
  circle(0, 0, 130, 'rgba(0,0,0,0)'); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.beginPath(); ctx.arc(0, 0, 130, 0, TAU); ctx.stroke();
  ctx.restore();
}
/** balance scale: tilt -1..1 (negative = left pan lower) */
export function scale(x, y, s = 1, tilt = 0, leftItem = null, rightItem = null) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-14, -150, 28, 300, 8, C.grayLight, { seed: 751, lw: 7, wob: 0.8 }); wRect(-110, 140, 220, 30, 10, C.grayLight, { seed: 752, lw: 7, wob: 0.8 });
  ctx.save(); ctx.translate(0, -150); ctx.rotate(tilt * 0.22);
  wRect(-300, -14, 600, 28, 12, C.orange, { seed: 753, lw: 7, wob: 1 });
  for (const sx of [-300, 300]) {
    const py = 150; line([[sx, 10], [sx - 70, py], [sx + 70, py]].slice(0, 2), C.ink, 5); line([[sx, 10], [sx + 70, py]], C.ink, 5);
    ctx.save(); ctx.translate(sx, py); ctx.rotate(-tilt * 0.22); wEll(0, 0, 110, 28, C.grayLight, { seed: 754 + sx, lw: 7, n: 14 });
    if (sx < 0 && leftItem) leftItem(); if (sx > 0 && rightItem) rightItem();
    ctx.restore();
  }
  ctx.restore();
  ctx.restore();
}
/** a flat money bag */
export function bag(x, y, s = 1, label = '$') {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[-30, -110], [30, -110], [20, -70], [110, 20], [90, 100], [-90, 100], [-110, 20], [-20, -70]], C.green, { seed: 761, wob: 1.4, lw: 8 });
  wRect(-40, -84, 80, 20, 8, C.orange, { seed: 762, lw: 5, wob: 0.5 });
  RS(label, 0, 28, 100, C.paper);
  ctx.restore();
}
