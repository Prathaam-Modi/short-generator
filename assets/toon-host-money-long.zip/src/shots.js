// INDIA IMPORTS $333 BILLION MORE THAN IT SELLS. WHO PAYS?  (Rupee Roots long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, gold = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as M from './core/money.js';
import * as X from './core/trade.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
const big = (s, x, y, size, color = C.ink) => R.txt(s, x, y, size, color, 'center', 2);
function vault(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-190, -170, 380, 340, 28, C.grayLight, { seed: 921 }); wRect(-150, -130, 300, 260, 18, C.sweater, { seed: 922, lw: 6 });
  circle(0, 0, 76, C.paper); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke();
  circle(0, 0, 22, C.orange); ctx.lineWidth = 6; ctx.stroke();
  for (let i = 0; i < 8; i++) { const a = i * TAU / 8; line([[Math.cos(a) * 30, Math.sin(a) * 30], [Math.cos(a) * 62, Math.sin(a) * 62]], C.ink, 6); }
  ctx.restore();
}
// goods sold vs goods bought: sold 442, bought 442 + gold gap 333 (bn dollars)
function tradeBars(lt) {
  const base = 820, k = 0.72, p = eo(seg(lt, 0.2, 1.4)), g = eo(seg(lt, 1.2, 2.4));
  line([[420, base], [1500, base]], C.ink, 6);
  R.bar(700, base, 260, 442 * k, C.green, p, 3); R.bar(1220, base, 260, 442 * k, C.green, p, 4);
  if (g > 0) wRect(1090, base - (442 + 333 * g) * k, 260, 333 * g * k, 12, C.orange, { seed: 5, lw: 7, wob: 1.2 });
  R.txt('SOLD', 700, base + 44, 38, C.ink, 'center', 1); R.txt('BOUGHT', 1220, base + 44, 38, C.ink, 'center', 1);
  if (p > 0.9) R.txt('$442B', 700, base - 442 * k - 40, 56, C.ink, 'center', 1);
  if (g > 0.9) R.txt('+$333B', 1220, base - 775 * k - 40, 56, C.ink, 'center', 1);
}
// waterfall of the full-year current account (RBI, bn dollars): goods -337, services +217, profits out -48, money home +144 -> -25
function waterfall(n, lt, label = true) {
  const z = 300, k = 1.0, xs = [330, 660, 990, 1320, 1650], bw = 190, lev = [0, -337, -120, -168, -25];
  const y = (v) => z - v * k;
  line([[220, z], [1760, z]], C.ink, 5);
  const names = ['GOODS', 'SERVICES', 'PROFITS OUT', 'MONEY HOME', 'TOTAL'], vals = ['−337', '+217', '−48', '+144', '−25'];
  const cols = [C.red, C.green, C.red, C.green, C.orange];
  for (let i = 0; i < 5; i++) {
    if (i + 1 > n) break;
    const a = i === 4 ? 0 : lev[i], b = i === 4 ? lev[4] : lev[i + 1]; // bar i spans lev[i] -> lev[i+1]; the last bar spans 0 -> -25
    const p = i + 1 === n ? eo(seg(lt, 0.2, 1.1)) : 1, bb = a + (b - a) * p;
    const t0 = Math.min(y(a), y(bb)), h = Math.abs(y(bb) - y(a));
    if (h > 3) wRect(xs[i] - bw / 2, t0, bw, h, 10, cols[i], { seed: 60 + i, lw: 7, wob: 1 });
    if (p > 0.9) R.txt(vals[i], xs[i], z - 46, 60, C.ink, 'center', 1);
    R.txt(names[i], xs[i], 860, 34, C.ink, 'center', 1);
  }
}
const lap = (x, y, s) => K.laptop(x, y, s, C.white, (w, h) => { wRect(-w / 2 + 24, -h / 2 + 22, w - 48, 40, 8, C.green, { seed: 77, lw: 4, wob: 0.5 }); for (let i = 0; i < 4; i++) wRect(-w / 2 + 24, -h / 2 + 84 + i * 36, i % 2 ? 190 : 300, 16, 6, C.paperLine, { lw: 0 }); wRect(w / 2 - 130, -h / 2 + 90, 100, 100, 10, C.orange, { seed: 78, lw: 4, wob: 0.5 }); });
const sea = (t) => { R.sky(0); R.sea(800, t); };
const env = (x, y, s, rot = 0) => M.envelope(x, y, s, rot, '₹');

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i, off = 0) => (i === 0 ? off : L(i) - 0.06 + off);
  const cam = [960, 520];
  const sh = (id, at, note, draw, extra = {}) => add({ id, at, cam, zoom: 0.04, note, draw, ...extra });

  // ═════════ HOOK ═════════
  sh('S01a', A(0), '333 bn more goods bought', (lt, d, t) => { R.paper(); big('$333 BILLION', 960, 430, 230, C.ink); R.pill('MORE GOODS BOUGHT THAN SOLD', 960, 690, 54, pop(lt, 0.5), { hi: true }); });
  sh('S01b', A(0, 4.0), 'so who paid', (lt, d, t) => { R.paper(); X.scale(960, 520, 1.2, -0.9 + Math.sin(lt * 2) * 0.05, () => X.barrel(0, -90, 0.5), () => M.note(0, -40, 0.35)); R.pill('SO WHO PAID THE BILL?', 960, 220, 56, pop(lt, 0.3), { hi: true }); });
  sh('S02a', A(1), 'host: how covered', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('HOW A COUNTRY COVERS A GAP', 640, 450, 54, pop(lt, 0.2), { hi: true }); });
  sh('S02b', A(1, 4.4), 'shortfall small', (lt, d, t) => { R.paper(); const base = 820; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 220, 333 * 1.4 * eo(seg(lt, 0.2, 1.2)), C.grayLight, 1, 6); R.bar(1160, base, 220, 25 * 1.4 * eo(seg(lt, 1.4, 2.2)), C.orange, 1, 7); R.pill('THE FINAL SHORTFALL: SMALL', 1160, 640, 46, pop(lt, 2.0), { hi: true }); });
  sh('S03a', A(2), 'running out? no', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill('RUNNING OUT OF MONEY? NO.', 1300, 420, 50, pop(lt, 0.3), { hi: true }); });
  sh('S03b', A(2, 4.9), 'work and family payments', (lt, d, t) => { R.paper(); lap(960, 650, 1.3); R.pill('PAID BY WORK + FAMILY PAYMENTS', 960, 220, 50, pop(lt, 0.4), { hi: true }); });
  sh('S04a', A(3), 'april 2025 to march 2026', (lt, d, t) => { R.paper(); wRect(560, 250, 800, 480, 30, C.white, { seed: 971 }); wRect(560, 250, 800, 120, 30, C.green, { seed: 972 }); R.txt('FULL YEAR', 960, 312, 62, C.white, 'center', 3); R.txt('2025-26', 960, 520, 150, C.ink, 'center', 2); R.pill('APRIL 2025 TO MARCH 2026', 960, 830, 48, pop(lt, 0.5), { hi: true }); });
  sh('S04b', A(3, 4.2), 'rbi page', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, -0.04, 'RBI'); R.pill('RESERVE BANK OF INDIA', 960, 860, 50, pop(lt, 0.4)); });
  sh('S04c', A(3, 8.0), 'pages we opened', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, 0.04, 'COMMERCE'); K.check(1250, 330, 0.3, pop(lt, 0.6)); R.pill('PAGES WE ACTUALLY OPENED', 960, 860, 50, pop(lt, 0.3), { hi: true }); });
  sh('S05', A(4), 'why now', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('OIL · GOLD · THE RUPEE: ONE BILL', 1300, 400, 44, pop(lt, 0.4), { hi: true }); });

  // ═════════ 1 · THE BILL ═════════
  sh('S06a', A(5), 'family budget', (lt, d, t) => { R.paper(); M.note(960, 520, 1.5, -0.05); R.arrowV(520, 520, 200, 0, C.green, 30); R.arrowV(1400, 520, 200, 0, C.red, 30); R.pill('COMES IN', 480, 380, 40, pop(lt, 0.4)); R.pill('GOES OUT', 1440, 380, 40, pop(lt, 1.0)); }, { chap: [1, 'THE BILL'] });
  sh('S06b', A(5, 4.6), 'current account', (lt, d, t) => { R.paper(); X.globe(960, 500, 1.5, t); R.pill('THE CURRENT ACCOUNT', 960, 820, 54, pop(lt, 0.5), { hi: true }); });
  sh('S07a', A(6), 'import', (lt, d, t) => { sea(t); X.cargo(960, 640 + Math.sin(t * 2) * 6, 1.6); R.surf(790, t); R.pill('IMPORT = BUY FROM ABROAD', 960, 220, 54, pop(lt, 0.3), { hi: true }); });
  sh('S07b', A(6, 2.6), 'export', (lt, d, t) => { sea(t); X.cargo(960, 640 + Math.sin(t * 2) * 6, 1.6); R.surf(790, t); R.pill('EXPORT = SELL ABROAD', 960, 220, 54, pop(lt, 0.3), { hi: true }); });
  sh('S08a', A(7), 'goods in a box', (lt, d, t) => { sea(t); X.cargo(960, 640 + Math.sin(t * 2) * 6, 1.6); R.surf(790, t); R.pill('GOODS YOU CAN BOX AND SHIP', 960, 220, 52, pop(lt, 0.3)); });
  sh('S08b', Wd('442', 7) - 0.3, '442 bn sold', (lt, d, t) => { R.paper(); big('$442 BILLION', 960, 440, 210, C.ink); R.pill('GOODS SOLD ABROAD  ·  2025-26', 960, 690, 50, pop(lt, 0.5), { hi: true }); });
  sh('S09a', A(8), 'scale tips', (lt, d, t) => { R.paper(); X.scale(960, 520, 1.2, -0.9, () => X.cargo(0, -60, 0.28), () => X.cargo(0, -60, 0.18, 0, 3)); R.pill('BOUGHT MORE THAN SOLD', 960, 200, 54, pop(lt, 0.3), { hi: true }); });
  sh('S09b', Wd('333', 8) + 0.3, 'gap 333', (lt, d, t) => { R.paper(); tradeBars(lt); R.pill('THE TRADE DEFICIT', 640, 330, 54, pop(lt, 2.0), { hi: true }); });
  sh('S10a', A(9), 'year earlier 283', (lt, d, t) => { R.paper(); const base = 820; line([[460, base], [1460, base]], C.ink, 6); R.bar(760, base, 240, 283 * 1.7 * eo(seg(lt, 0.2, 1.2)), C.grayLight, 1, 8); R.bar(1160, base, 240, 333 * 1.7 * eo(seg(lt, 1.2, 2.2)), C.orange, 1, 9); R.txt('2024-25', 760, base + 44, 36, C.ink, 'center', 1); R.txt('2025-26', 1160, base + 44, 36, C.ink, 'center', 1); R.pill('A YEAR EARLIER: ~$283B', 760, 230, 40, pop(lt, 0.8)); });
  sh('S10b', A(9, 4.0), 'grew 17 pct', (lt, d, t) => { R.paper(); big('+17%', 960, 440, 320, C.ink); R.pill('THE GAP GREW IN ONE YEAR', 960, 720, 52, pop(lt, 0.5), { hi: true }); });
  sh('S11a', A(10), 'oil 174', (lt, d, t) => { R.paper(); X.barrel(960, 520, 1.7); R.pill('OIL: ABOUT $174 BILLION', 960, 880, 50, pop(lt, 0.4), { hi: true }); });
  sh('S11b', A(10, 5.0), 'most oil from abroad', (lt, d, t) => { R.paper(); X.globe(960, 500, 1.5, t); R.pill('MOST OF ITS OIL COMES FROM ABROAD', 960, 820, 46, pop(lt, 0.4), { hi: true }); });
  sh('S12a', A(11), 'gold 72', (lt, d, t) => { R.paper(); X.goldBar(960, 540, 2.2); R.pill('GOLD: ABOUT $72 BILLION', 960, 880, 50, pop(lt, 0.4), { hi: true }); });
  sh('S12b', A(11, 4.6), 'tonnes down', (lt, d, t) => { R.paper(); const base = 820; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 220, 757 * 0.5 * eo(seg(lt, 0.2, 1.2)), C.grayLight, 1, 10); R.bar(1160, base, 220, 721 * 0.5 * eo(seg(lt, 1.0, 2.0)), C.orange, 1, 11); R.txt('757 t', 760, base - 757 * 0.5 - 36, 50, C.ink, 'center', 1); R.txt('721 t', 1160, base - 721 * 0.5 - 36, 50, C.ink, 'center', 1); R.txt('2024-25', 760, base + 44, 34, C.ink, 'center', 1); R.txt('2025-26', 1160, base + 44, 34, C.ink, 'center', 1); R.pill('BOUGHT LESS BY WEIGHT', 960, 190, 50, pop(lt, 2.2), { hi: true }); });
  sh('S13a', A(12), 'price per kilo', (lt, d, t) => { R.paper(); big('$76,600 → $99,800', 960, 440, 150, C.ink); R.pill('PRICE PER KILO OF GOLD', 960, 660, 50, pop(lt, 0.5), { hi: true }); });
  sh('S13b', Wd('same', 12) - 0.2, 'dearer tag', (lt, d, t) => { R.paper(); X.goldBar(960, 540, 1.8); K.sticker('DEARER TAG', 1260, 380, 56, C.yellow, C.ink, pop(lt, 0.5), 0.12); });
  sh('S14a', A(13), 'oil and gold', (lt, d, t) => { R.paper(); X.barrel(600, 520, 1.3); X.goldBar(1320, 560, 1.3); R.pill('OIL', 600, 820, 46, pop(lt, 0.3)); R.pill('GOLD', 1320, 820, 46, pop(lt, 0.8)); });
  sh('S14b', A(13, 3.7), 'a third', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.32, color: C.orange }, { v: 0.68, color: C.grayLight }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('ABOUT A THIRD OF IMPORTS', 960, 880, 50, pop(lt, 1.0), { hi: true }); R.pill('OUR OWN ARITHMETIC', 1500, 300, 36, pop(lt, 1.8)); });
  sh('S15', A(14), 'payoff ch1', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.point, armL: K.ARM.hip }); R.pill('BIG BILL. TWO ITEMS = A THIRD.', 640, 450, 48, pop(lt, 0.3), { hi: true }); });

  // ═════════ 2 · THE QUIET PAYER ═════════
  sh('S16', A(15), 'sells work', (lt, d, t) => { R.paper(); lap(960, 650, 1.4); R.pill('INDIA ALSO SELLS WORK', 960, 210, 56, pop(lt, 0.4), { hi: true }); }, { chap: [2, 'THE QUIET PAYER'] });
  sh('S17a', A(16), 'software it support', (lt, d, t) => { R.paper(); lap(960, 650, 1.4); R.pill('SOFTWARE · IT SUPPORT · BACK OFFICE', 960, 210, 46, pop(lt, 0.4)); });
  sh('S17b', A(16, 5.4), 'internet not ship', (lt, d, t) => { R.paper(); X.globe(960, 500, 1.5, t); R.pill('SERVICES TRAVEL BY INTERNET', 960, 820, 52, pop(lt, 0.4), { hi: true }); });
  sh('S18a', A(17), '418 bn sold', (lt, d, t) => { R.paper(); big('$418 BILLION', 960, 440, 210, C.ink); R.pill('SERVICES SOLD ABROAD', 960, 690, 52, pop(lt, 0.5), { hi: true }); });
  sh('S18b', A(17, 5.9), 'bought 204', (lt, d, t) => { R.paper(); const base = 820; line([[460, base], [1460, base]], C.ink, 6); R.bar(760, base, 240, 418 * 1.4 * eo(seg(lt, 0.2, 1.2)), C.green, 1, 12); R.bar(1160, base, 240, 204 * 1.4 * eo(seg(lt, 1.2, 2.2)), C.grayLight, 1, 13); R.txt('SOLD $418B', 760, base + 44, 34, C.ink, 'center', 1); R.txt('BOUGHT $204B', 1160, base + 44, 34, C.ink, 'center', 1); R.pill('SERVICES SOLD VS BOUGHT', 960, 190, 48, pop(lt, 0.5)); });
  sh('S19', A(18), 'surplus 214', (lt, d, t) => { R.paper(); big('+$214 BILLION', 960, 440, 200, C.ink); R.pill('MORE EARNED THAN SPENT ON SERVICES', 960, 690, 48, pop(lt, 0.5), { hi: true }); });
  sh('S20a', A(19), 'covers 64 pct', (lt, d, t) => { R.paper(); const base = 820; line([[560, base], [1360, base]], C.ink, 6); R.bar(960, base, 300, 333 * 1.5, C.grayLight, eo(seg(lt, 0.1, 0.8)), 14); R.bar(960, base, 300, 214 * 1.5, C.green, eo(seg(lt, 0.8, 1.8)), 15); R.pill('GOODS GAP', 560, 400, 40, pop(lt, 0.3)); R.pill('SERVICES COVER ~64%', 1360, 560, 42, pop(lt, 1.6), { hi: true }); });
  sh('S20b', A(19, 4.4), 'two thirds', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.64, color: C.green }, { v: 0.36, color: C.grayLight }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('NEARLY TWO THIRDS OF THE BILL', 960, 880, 50, pop(lt, 1.0), { hi: true }); });
  sh('S21', A(20), 'payoff ch2', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('PAID WITH WORK, NOT BORROWING', 1300, 400, 44, pop(lt, 0.4), { hi: true }); });

  // ═════════ 3 · TWO MORE ITEMS ═════════
  sh('S22', A(21), 'opposite directions', (lt, d, t) => { R.paper(); R.arrowV(660, 560, 280, -PI / 2, C.green, 36); R.arrowV(1260, 280, 280, PI / 2, C.red, 36); R.pill('ONE HELPS', 660, 760, 46, pop(lt, 0.4)); R.pill('ONE HURTS', 1260, 760, 46, pop(lt, 1.2)); }, { chap: [3, 'TWO MORE ITEMS'] });
  sh('S23a', A(22), 'money sent home', (lt, d, t) => { R.paper(); env(960, 500, 1.5, -0.05); R.pill('MONEY SENT HOME FROM ABROAD', 960, 800, 50, pop(lt, 0.4), { hi: true }); });
  sh('S23b', A(22, 4.9), 'secondary income', (lt, d, t) => { R.paper(); K.sticker('SECONDARY INCOME', 960, 450, 100, C.yellow, C.ink, pop(lt, 0.3), -0.03); R.pill('THE RBI\'S NAME FOR IT', 960, 700, 46, pop(lt, 1.0)); });
  sh('S24a', A(23), 'plus 144', (lt, d, t) => { R.paper(); big('+$144 BILLION', 960, 440, 200, C.ink); R.pill('NET  ·  2025-26', 960, 690, 52, pop(lt, 0.5), { hi: true }); });
  sh('S24b', A(23, 5.9), 'small payments river', (lt, d, t) => { R.paper(); for (let i = 0; i < 5; i++) { const x = 300 + i * 330; env(x, 520 + Math.sin(t * 2 + i) * 10, 0.5, (i - 2) * 0.06); } R.pill('MILLIONS OF SMALL PAYMENTS', 960, 800, 52, pop(lt, 0.4), { hi: true }); });
  sh('S25a', A(24), 'the leak', (lt, d, t) => { R.paper(); X.bag(760, 520, 1.5, '₹'); R.arrowV(960, 520, 360, 0, C.red, 40); R.pill('PROFITS + INTEREST GO OUT', 960, 800, 50, pop(lt, 0.5), { hi: true }); });
  sh('S25b', A(24, 5.9), 'minus 48', (lt, d, t) => { R.paper(); big('−$48 BILLION', 960, 440, 210, C.ink); R.pill('NET OUTFLOW', 960, 690, 52, pop(lt, 0.5), { hi: true }); });
  sh('S26a', A(25), 'rbi own count', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, -0.03, 'RBI'); R.pill('THE RBI\'S OWN COUNT', 960, 860, 52, pop(lt, 0.4), { hi: true }); });
  sh('S26b', A(25, 4.0), 'goods minus 337', (lt, d, t) => { R.paper(); waterfall(1, lt); });
  sh('S26c', A(25, 7.8), 'services plus 217', (lt, d, t) => { R.paper(); waterfall(2, lt); });
  sh('S27a', A(26), 'minus 48', (lt, d, t) => { R.paper(); waterfall(3, lt); });
  sh('S27b', A(26, 3.3), 'plus 144', (lt, d, t) => { R.paper(); waterfall(4, lt); });
  sh('S28a', A(27), 'total minus 25', (lt, d, t) => { R.paper(); waterfall(5, lt); R.pill('A SHORTFALL OF ABOUT $25 BILLION', 960, 760, 46, pop(lt, 1.4), { hi: true }); });
  sh('S28b', A(27, 5.8), '0.6 pct of gdp', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.006, color: C.orange }, { v: 0.988, color: C.grayLight }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('0.6% OF A YEAR\'S INCOME', 960, 880, 50, pop(lt, 1.0), { hi: true }); });
  sh('S29a', A(28), '333 to 25', (lt, d, t) => { R.paper(); const base = 820; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 220, 333 * 1.6, C.grayLight, eo(seg(lt, 0.1, 0.9)), 16); R.bar(1160, base, 220, 25 * 1.6 * eo(seg(lt, 1.0, 1.8)), C.orange, 1, 17); R.pill('$333B → $25B', 960, 190, 56, pop(lt, 1.2), { hi: true }); });
  sh('S29b', A(28, 4.1), 'payoff ch3', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('LESS THAN A TENTH OF THE GAP', 640, 450, 48, pop(lt, 0.3), { hi: true }); });

  // ═════════ 4 · THE LAST GAP ═════════
  sh('S30', A(29), 'who pays last piece', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.chin, armL: K.ARM.hip }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('WHO PAYS THE LAST PIECE?', 640, 450, 52, pop(lt, 0.2), { hi: true }); }, { chap: [4, 'THE LAST GAP'] });
  sh('S31a', A(30), 'two sides', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('EVERY PAYMENT HAS TWO SIDES', 1300, 400, 46, pop(lt, 0.4), { hi: true }); });
  sh('S31b', A(30, 3.8), 'books balance', (lt, d, t) => { R.paper(); X.scale(960, 520, 1.2, Math.sin(lt * 2) * 0.05); R.pill('THE BOOKS MUST BALANCE', 960, 200, 56, pop(lt, 0.3), { hi: true }); });
  sh('S32a', A(31), 'short on one side', (lt, d, t) => { R.paper(); X.scale(960, 520, 1.2, -0.7, () => M.note(0, -40, 0.35, 0, C.red), null); R.pill('SHORT ON ONE SIDE', 960, 200, 54, pop(lt, 0.3), { hi: true }); });
  sh('S32b', A(31, 4.3), 'money comes in', (lt, d, t) => { R.paper(); X.globe(480, 500, 1.1, t); R.arrowV(660, 500, 440, 0, C.green, 40); M.bank(1480, 500, 0.9); R.pill('LOANS · INVESTMENT · DEPOSITS', 960, 800, 46, pop(lt, 0.4), { hi: true }); });
  sh('S33a', A(32), 'lend or invest', (lt, d, t) => { R.paper(); M.bank(960, 500, 1.3); R.pill('FOREIGNERS LEND OR INVEST', 960, 820, 50, pop(lt, 0.4), { hi: true }); });
  sh('S33b', A(32, 4.2), 'or savings', (lt, d, t) => { R.paper(); M.jar(960, 520, 1.5, 0.6); R.pill('OR DIP INTO SAVINGS', 960, 820, 52, pop(lt, 0.4), { hi: true }); });
  sh('S34a', A(33), 'ecb 14', (lt, d, t) => { R.paper(); X.bag(960, 500, 1.6, '$'); R.pill('COMPANIES: ~$14B MORE BORROWED', 960, 820, 50, pop(lt, 0.4), { hi: true }); });
  sh('S34b', A(33, 5.7), 'nri deposits 14', (lt, d, t) => { R.paper(); M.piggy(960, 520, 1.3, -0.05, Math.sin(lt * 3) * 5); R.pill('OVERSEAS INDIANS\' DEPOSITS: ~$14B', 960, 820, 48, pop(lt, 0.4), { hi: true }); });
  sh('S34c', A(33, 11.4), 'fdi 7', (lt, d, t) => { R.paper(); M.coinStack(960, 700, 1.6, 5); R.pill('FOREIGN DIRECT INVESTMENT: ~$7B', 960, 200, 50, pop(lt, 0.4), { hi: true }); });
  sh('S35a', A(34), 'reserves fell 24', (lt, d, t) => { R.paper(); M.jar(960, 520, 1.5, 0.75 - 0.2 * eo(seg(lt, 0.4, 3))); R.pill('RESERVES FELL ~$24 BILLION', 960, 820, 52, pop(lt, 0.4), { hi: true }); });
  sh('S35b', A(34, 4.4), 'on the books', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, 0.03, 'RBI'); R.pill('ON THE BOOKS, 2025-26', 960, 860, 50, pop(lt, 0.4)); });
  sh('S36a', A(35), 'reserves cushion', (lt, d, t) => { R.paper(); vault(960, 500, 1.5); R.pill('A CUSHION OF FOREIGN CURRENCY', 960, 860, 50, pop(lt, 0.4), { hi: true }); });
  sh('S36b', Wd('691', 35) - 0.4, '691 bn', (lt, d, t) => { R.paper(); big('~$691 BILLION', 960, 440, 200, C.ink); R.pill('RESERVES AT END-MARCH 2026', 960, 690, 52, pop(lt, 0.5), { hi: true }); });
  sh('S36c', Wd('december', 35) - 0.3, '10.8 months', (lt, d, t) => { R.paper(); K.clock(960, 500, 1.5, t * 0.8); R.pill('10.8 MONTHS OF IMPORTS · DEC 2025', 960, 820, 46, pop(lt, 0.4), { hi: true }); });
  sh('S37', A(36), 'payoff ch4', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.point, armL: K.ARM.hip }); R.pill('INFLOWS + A CUSHION BUILT FOR THIS', 640, 450, 44, pop(lt, 0.3), { hi: true }); });

  // ═════════ 5 · READ THE HEADLINE ═════════
  sh('S38', A(37), 'record headline', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, -0.04, 'NEWS'); R.pill('"TRADE DEFICIT HITS A RECORD"', 960, 860, 50, pop(lt, 0.4), { hi: true }); }, { chap: [5, 'READ THE HEADLINE'] });
  sh('S39', A(38), 'q1 how big', (lt, d, t) => { R.paper(); R.pie(960, 480, 250, [{ v: 0.006, color: C.orange }, { v: 0.988, color: C.grayLight }], eo(seg(lt, 0.2, 1.4)), 0); R.pill('1  HOW BIG VS THE WHOLE ECONOMY?', 960, 860, 46, pop(lt, 0.6), { hi: true }); });
  sh('S40', A(39), 'q2 what pays', (lt, d, t) => { R.paper(); lap(960, 520, 1.3); R.pill('2  WHAT IS PAYING FOR IT?', 960, 860, 52, pop(lt, 0.4), { hi: true }); });
  sh('S41', A(40), 'q3 cushion', (lt, d, t) => { R.paper(); vault(960, 500, 1.4); R.pill('3  HOW THICK IS THE CUSHION?', 960, 860, 52, pop(lt, 0.4), { hi: true }); });
  sh('S42', A(41), 'measurement not grade', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill('A MEASUREMENT, NOT A GRADE', 1300, 400, 46, pop(lt, 0.3), { hi: true }); });
  sh('S43', A(42), 'not advice', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('HOW THE NUMBERS WORK, NOT ADVICE', 640, 450, 44, pop(lt, 0.3), { hi: true }); });

  // ═════════ RECAP ═════════
  sh('S44a', A(43), 'host recap', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('QUICK RECAP', 1300, 420, 56, pop(lt, 0.3), { hi: true }); }, { chap: [6, 'RECAP'] });
  sh('S44b', A(43, 4.7), 'recap bars', (lt, d, t) => { R.paper(); tradeBars(lt); R.pill('GOODS GAP ~$333B', 640, 330, 52, pop(lt, 2.0), { hi: true }); });
  sh('S45a', A(44), 'oil and gold third', (lt, d, t) => { R.paper(); X.barrel(600, 520, 1.2); X.goldBar(1320, 560, 1.2); R.pill('OIL + GOLD: ABOUT A THIRD', 960, 880, 48, pop(lt, 0.4), { hi: true }); });
  sh('S45b', A(44, 2.8), 'services two thirds', (lt, d, t) => { R.paper(); lap(960, 650, 1.3); R.pill('SERVICES COVER ABOUT 64%', 960, 220, 50, pop(lt, 0.3), { hi: true }); });
  sh('S46a', A(45), 'recap waterfall', (lt, d, t) => { R.paper(); waterfall(5, 99); R.pill('FINAL SHORTFALL: ~$25 BILLION', 960, 760, 46, pop(lt, 0.6), { hi: true }); });
  sh('S46b', A(45, 4.9), '0.6 pct recap', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.006, color: C.orange }, { v: 0.988, color: C.grayLight }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('0.6% OF A YEAR\'S INCOME', 960, 880, 50, pop(lt, 0.8), { hi: true }); });
  sh('S47', A(46), 'inflows and reserves', (lt, d, t) => { R.paper(); X.globe(480, 500, 1.1, t); R.arrowV(660, 500, 440, 0, C.green, 40); vault(1480, 500, 0.8); R.pill('MONEY IN  +  RESERVES', 960, 800, 52, pop(lt, 0.4), { hi: true }); });
  sh('S48a', A(47), 'who paid', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.chin, armL: K.ARM.hip }); R.pill('WHO PAID THE $333B BILL?', 640, 450, 52, pop(lt, 0.3), { hi: true }); });
  sh('S48b', A(47, 3.6), 'laptops and families', (lt, d, t) => { R.paper(); lap(700, 540, 1.1); env(1360, 520, 0.9, 0.05); R.pill('WORK + MONEY SENT HOME', 960, 860, 50, pop(lt, 0.4), { hi: true }); });
  sh('S49', A(48), 'subscribe', (lt, d, t) => { R.studio(880); host(960, lt, { arm: K.ARM.open, armL: K.ARM.open, mouth: 'grin' }); R.pill('RUPEE ROOTS  ·  EDUCATION ONLY', 960, 190, 54, pop(lt, 0.4), { hi: true }); });

  return { shots: S, cues: CUES };
}
