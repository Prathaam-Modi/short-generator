// YOUR BANK PAYS 7% AND CHARGES 10%: WHERE DOES THE GAP GO?  (Rupee Roots long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, gold = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as M from './core/money.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
const big = (s, x, y, size, color = C.orange) => R.txt(s, x, y, size, color, 'center', 2);
const mini = (x, y, s, rot = 0) => M.upiPhone(x, y, s, rot, 1);
function bankN(x, y, s, name, sc = 1, hi = false) { M.bank(x, y, s); if (name) R.pill(name, x, y + 190 * s + 40, 36, sc, hi ? { hi: true } : {}); }

// shield (deposit insurance): gold with a rupee
function shield(x, y, s = 1, p = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s * p, s * p);
  poly([[-110, -130], [110, -130], [110, 20], [0, 140], [-110, 20]], C.orange, { seed: 901, wob: 1.2, lw: 8 });
  poly([[-76, -96], [76, -96], [76, 8], [0, 100], [-76, 8]], C.yellow, { seed: 902, wob: 1, lw: 5 });
  R.txt('₹', 0, -10, 130, C.ink, 'center', 1);
  ctx.restore();
}
// padlock
function lock(x, y, s = 1, col = C.orange) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  ctx.beginPath(); ctx.arc(0, -40, 62, PI, 0); ctx.lineWidth = 30; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.beginPath(); ctx.arc(0, -40, 62, PI, 0); ctx.lineWidth = 14; ctx.strokeStyle = C.grayLight; ctx.stroke();
  wRect(-100, -40, 200, 160, 20, col, { seed: 911 });
  circle(0, 25, 18, C.ink); wRect(-6, 30, 12, 40, 4, C.ink, { lw: 0 });
  ctx.restore();
}
// vault (cash with the RBI)
function vault(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-190, -170, 380, 340, 28, C.grayLight, { seed: 921 }); wRect(-150, -130, 300, 260, 18, C.sweater, { seed: 922, lw: 6 });
  circle(0, 0, 76, C.paper); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke();
  circle(0, 0, 22, C.orange); ctx.lineWidth = 6; ctx.stroke();
  for (let i = 0; i < 8; i++) { const a = i * TAU / 8; line([[Math.cos(a) * 30, Math.sin(a) * 30], [Math.cos(a) * 62, Math.sin(a) * 62]], C.ink, 6); }
  ctx.restore();
}
// water well + dry field for the pipe picture
function well(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-110, -40, 220, 140, 18, C.grayLight, { seed: 931 }); wEll(0, -40, 110, 36, C.blue, { seed: 932, n: 18 });
  wRect(-120, -150, 20, 110, 6, C.ink, { lw: 0 }); wRect(100, -150, 20, 110, 6, C.ink, { lw: 0 }); wRect(-130, -170, 260, 28, 8, C.orangeDark, { seed: 933 });
  ctx.restore();
}
function dryField(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-190, -20, 380, 120, 16, '#D8B97A', { seed: 941 });
  for (const [a, b, c2, d] of [[-120, 10, -70, 60], [-20, 20, 30, 70], [70, 5, 130, 55]]) inkLine([[a, b], [(a + c2) / 2 + 12, (b + d) / 2 - 8], [c2, d]], C.ink, 5, 0);
  ctx.restore();
}
// pipe with a bank on it (water drops flow left to right)
function pipe(x0, x1, y, t, hi = false) {
  wRect(x0, y - 36, x1 - x0, 72, 30, hi ? C.orange : C.grayLight, { seed: 951 });
  for (let i = 0; i < 6; i++) { const p = ((t * 0.4 + i / 6) % 1); circle(lerp(x0 + 30, x1 - 30, p), y, 12, C.blue); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke(); }
}
// the deposit rate vs loan rate bars. p = grow 0..1, gapHi = gold gap segment, labels on/off
function rateBars(p, gapHi = false, lt = 0) {
  const base = 820, k = 46; // px per percent
  line([[420, base], [1500, base]], C.ink, 6);
  const dv = 7.0 * eo(seg(p, 0, 0.6)), lv = 9.87 * eo(seg(p, 0.3, 1));
  R.bar(700, base, 240, dv * k, C.green, 1, 3);
  if (gapHi) { R.bar(1220, base, 240, 7.0 * k, C.green, 1, 4); wRect(1100, base - lv * k, 240, (lv - 7.0) * k, 12, C.orange, { seed: 5, lw: 7, wob: 1.2 }); }
  else R.bar(1220, base, 240, lv * k, C.green, 1, 4);
  R.txt('DEPOSITS', 700, base + 46, 38, C.ink, 'center', 1); R.txt('LOANS', 1220, base + 46, 38, C.ink, 'center', 1);
  if (p > 0.7) { R.txt('7.00%', 700, base - dv * k - 40, 56, C.ink, 'center', 1); R.txt('9.87%', 1220, base - lv * k - 40, 56, C.ink, 'center', 1); }
}
// a horizontal stacked bar. segs: [{v, color, label}] sum to total
function stack(x, y, w, h, segs, total, p, seed = 1) {
  let cx = x; const lim = x + w * clamp(p);
  segs.forEach((sg, i) => { const sw = (sg.v / total) * w, e = Math.min(cx + sw, lim); if (e > cx + 2) wRect(cx, y, e - cx, h, 10, sg.color, { seed: seed + i, lw: 7, wob: 1 }); cx += sw; });
}
// 100 little squares, first n gold (n can be fractional)
function grid100(x0, y0, size, n, p = 1) {
  for (let i = 0; i < 100; i++) {
    const c = i % 10, r = Math.floor(i / 10), x = x0 + c * (size + 8), y = y0 + r * (size + 8);
    const on = i < Math.floor(n) ? 1 : i === Math.floor(n) ? n - Math.floor(n) : 0;
    wRect(x, y, size, size, 8, C.paper, { seed: 100 + i, lw: 4, wob: 0.6 });
    if (on > 0) wRect(x, y + size * (1 - on), size, size * on, 8, C.orange, { seed: 100 + i, lw: 4, wob: 0.6 });
  }
}
function infoCard(x, y, w, h, title, sc = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc); wRect(-w / 2, -h / 2, w, h, 20, C.white, { seed: 961 }); R.txt(title, 0, 0, 46, C.ink, 'center', 1); ctx.restore();
}

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i, off = 0) => (i === 0 ? off : L(i) - 0.06 + off);
  const cam = [960, 520];
  const sh = (id, at, note, draw, extra = {}) => add({ id, at, cam, zoom: 0.04, note, draw, ...extra });

  // ═════════ HOOK ═════════
  sh('S01a', A(0), 'bank pays 7%', (lt, d, t) => { R.studio(880); M.bank(960, 520, 1.2); M.piggy(480, 640, 0.6, -0.1, Math.sin(lt * 3) * 6); R.pill('PAYS YOU ABOUT 7%', 480, 330, 50, pop(lt, 0.4)); });
  sh('S01b', A(0, 3.1), 'charges 10%', (lt, d, t) => { R.studio(880); M.bank(960, 520, 1.2); M.note(1440, 640, 0.8, 0.08); R.pill('CHARGES ALMOST 10%', 1440, 330, 50, pop(lt, 0.4), { hi: true }); });
  sh('S01c', A(0, 5.5), 'where does the gap go', (lt, d, t) => { R.paper(); rateBars(1, true); R.pill('WHERE DOES THE GAP GO?', 960, 190, 58, pop(lt, 0.3), { hi: true }); });
  sh('S02a', A(1), 'host: what you get', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('HOW A BANK EARNS', 640, 450, 58, pop(lt, 0.2), { hi: true }); });
  sh('S02b', A(1, 3.6), 'thin profit', (lt, d, t) => { R.paper(); stack(360, 440, 1200, 150, [{ v: 98.6, color: C.grayLight }, { v: 1.4, color: C.orange }], 100, eo(seg(lt, 0.2, 1.4)), 20); R.pill('PROFIT: MUCH THINNER THAN YOU\'D GUESS', 960, 270, 46, pop(lt, 0.4)); });
  sh('S03', A(2), 'gap shrinks', (lt, d, t) => { R.paper(); const k = lerp(1, 0.12, eio(seg(lt, 1.2, 4.2))); wRect(560, 560, 800 * k + 20, 110, 12, C.orange, { seed: 31, lw: 7 }); if (k > 0.5) R.txt('THE GAP', 560 + (800 * k + 20) / 2, 615, 56, C.ink, 'center', 2); R.pill('MOST OF THE GAP VANISHES', 960, 360, 56, pop(lt, 0.3), { hi: true }); R.pill('BEFORE THE BANK KEEPS A RUPEE', 960, 800, 44, pop(lt, 2.0)); });
  sh('S04a', A(3), 'official pages', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, -0.04, 'RBI'); K.check(1250, 330, 0.3, pop(lt, 0.8)); R.pill('PAGES WE ACTUALLY OPENED', 960, 860, 50, pop(lt, 0.3), { hi: true }); });
  sh('S04b', A(3, 4.2), 'our maths labelled', (lt, d, t) => { R.paper(); M.calc(960, 480, 1.1, 0, '2.9'); R.pill('OUR OWN MATHS IS LABELLED', 960, 860, 50, pop(lt, 0.3)); });
  sh('S05a', A(4), 'host: both sides', (lt, d, t) => { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('YOU ARE ON ONE SIDE OF THIS DEAL', 1300, 400, 46, pop(lt, 0.4), { hi: true }); });
  sh('S05b', A(4, 3.8), 'deposit and EMI', (lt, d, t) => { R.paper(); M.piggy(560, 560, 0.8, -0.05, 0); M.bank(960, 520, 0.7); M.calc(1370, 540, 0.8, 0.05, 'EMI'); R.pill('DEPOSIT', 560, 800, 40, pop(lt, 0.3)); R.pill('EMI', 1370, 800, 40, pop(lt, 0.9)); });

  // ═════════ 1 · THE MIDDLEMAN ═════════
  sh('S06a', A(5), 'people with spare money', (lt, d, t) => { R.paper(); M.jar(960, 540, 1.5, 0.7); R.pill('PEOPLE WITH SPARE MONEY', 960, 220, 52, pop(lt, 0.3)); }, { chap: [1, 'THE MIDDLEMAN'] });
  sh('S06b', A(5, 3.2), 'middleman', (lt, d, t) => { R.paper(); M.jar(430, 560, 0.8, 0.7); M.bank(960, 520, 0.85); M.note(1500, 560, 0.7, 0.08); R.arrowV(560, 540, 200, 0, C.orange, 28); R.arrowV(1160, 540, 200, 0, C.orange, 28); R.pill('THE MIDDLEMAN', 960, 800, 50, pop(lt, 0.3), { hi: true }); });
  sh('S07a', A(6), 'well and dry field', (lt, d, t) => { R.paper(); well(460, 560, 1.1); dryField(1460, 600, 1.0); R.pill('EXTRA WATER', 460, 800, 40, pop(lt, 0.3)); R.pill('DRY FIELDS', 1460, 800, 40, pop(lt, 0.9)); });
  sh('S07b', A(6, 3.6), 'bank is the pipe', (lt, d, t) => { R.paper(); well(300, 560, 0.7); dryField(1620, 600, 0.7); pipe(440, 1500, 640, t, true); M.bank(960, 520, 0.65); R.pill('THE BANK IS THE PIPE', 960, 250, 54, pop(lt, 0.3), { hi: true }); });
  sh('S08a', A(7), '1806', (lt, d, t) => { R.paper(); big('1806', 960, 450, 300, C.ink); R.pill('BANK OF CALCUTTA BEGINS', 960, 720, 52, pop(lt, 0.5), { hi: true }); });
  sh('S08b', A(7, 5.2), 'scale today is huge', (lt, d, t) => { R.studio(880); M.coinStack(960, 760, 1.8, 8); R.pill('BUT THE SCALE TODAY IS HUGE', 960, 200, 52, pop(lt, 0.3), { hi: true }); });
  sh('S09a', A(8), '281 lakh crore', (lt, d, t) => { R.paper(); const n = Math.floor(lerp(0, 281, eo(seg(lt, 0.2, 2.2)))); big('₹' + n + ' LAKH CRORE', 960, 450, 170, C.ink); R.pill('BANK ASSETS IN 2024', 960, 700, 52, pop(lt, 1.8), { hi: true }); });
  sh('S09b', A(8, 4.6), '25x since 2000', (lt, d, t) => { R.paper(); const base = 800; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 200, 20, C.green, 1, 7); R.bar(1160, base, 200, 520 * eo(seg(lt, 0.3, 1.6)), C.orange, 1, 8); R.txt('2000', 760, base + 46, 38, C.ink, 'center', 1); R.txt('2024', 1160, base + 46, 38, C.ink, 'center', 1); R.pill('ABOUT 25 TIMES MORE  ·  OUR MATHS', 960, 190, 46, pop(lt, 1.6), { hi: true }); });
  sh('S10a', A(9), 'buys cheap', (lt, d, t) => { R.paper(); M.piggy(480, 560, 0.7, -0.05, 0); M.bank(1200, 520, 0.9); R.arrowV(660, 540, 300, 0, C.orange, 28); R.pill('BUYS MONEY CHEAP', 960, 220, 52, pop(lt, 0.3)); });
  sh('S10b', A(9, 3.2), 'sells dearer', (lt, d, t) => { R.paper(); M.bank(560, 520, 0.9); M.note(1440, 560, 0.8, 0.08); R.arrowV(760, 540, 400, 0, C.orange, 28); R.pill('SELLS IT DEARER', 960, 220, 52, pop(lt, 0.3), { hi: true }); });

  // ═════════ 2 · THE GAP ═════════
  sh('S11a', A(10), 'december 2024 rbi', (lt, d, t) => { R.paper(); wRect(560, 250, 800, 480, 30, C.white, { seed: 971 }); wRect(560, 250, 800, 120, 30, C.green, { seed: 972 }); R.txt('DECEMBER 2024', 960, 312, 62, C.white, 'center', 3); R.txt('RBI DATA', 960, 520, 110, C.ink, 'center', 2); R.pill('BOTH PRICES MEASURED', 960, 830, 50, pop(lt, 0.5), { hi: true }); }, { chap: [2, 'THE GAP'] });
  sh('S11b', A(10, 5.0), 'deposits 7.00', (lt, d, t) => { R.paper(); const base = 820; line([[560, base], [1360, base]], C.ink, 6); R.bar(960, base, 260, 7.0 * 56 * eo(seg(lt, 0.2, 1.4)), C.green, 1, 3); R.txt('DEPOSITS', 960, base + 46, 38, C.ink, 'center', 1); R.pill('ABOUT 7.00% PAID', 960, 260, 56, pop(lt, 1.2), { hi: true }); });
  sh('S12a', A(11), 'loans 9.87', (lt, d, t) => { R.paper(); rateBars(eo(seg(lt, 0.1, 2.5))); R.pill('LOANS: ALMOST 10%', 960, 190, 56, pop(lt, 0.8), { hi: true }); });
  sh('S12b', A(11, 4.6), 'exactly', (lt, d, t) => { R.paper(); rateBars(1); R.pill('EXACTLY 7.00% AND 9.87%', 960, 190, 52, pop(lt, 0.3)); });
  sh('S13a', A(12), 'gap 2.9 points', (lt, d, t) => { R.paper(); rateBars(1, true); R.pill('THE GAP: ABOUT 2.9 POINTS', 960, 190, 54, pop(lt, 0.5), { hi: true }); });
  sh('S13b', A(12, 4.8), 'rs 2900 on a lakh', (lt, d, t) => { R.studio(880); M.coinStack(960, 740, 1.6, 4); R.pill('ON ₹1 LAKH: ABOUT ₹2,900 A YEAR', 960, 200, 52, pop(lt, 0.4), { hi: true }); R.pill('OUR OWN ARITHMETIC', 960, 300, 36, pop(lt, 1.0)); });
  sh('S14a', A(13), 'net interest margin', (lt, d, t) => { R.paper(); K.sticker('NET INTEREST MARGIN', 960, 440, 90, C.orange, C.ink, pop(lt, 0.3), -0.03); R.pill('BANKERS\' NAME FOR THE GAP', 960, 700, 46, pop(lt, 1.0)); });
  sh('S14b', A(13, 4.6), '2.5 to 3 for 25 years', (lt, d, t) => { R.paper(); const base = 760; line([[300, base], [1620, base]], C.ink, 6); const x25 = 300 + (2.5 / 4) * 1320, x3 = 300 + (3 / 4) * 1320; wRect(x25, base - 160, x3 - x25, 160, 10, C.orange, { seed: 41, lw: 7 }); [0, 1, 2, 3, 4].forEach((v) => { line([[300 + v / 4 * 1320, base], [300 + v / 4 * 1320, base + 16]], C.ink, 5); R.txt(v + '%', 300 + v / 4 * 1320, base + 50, 36, C.ink, 'center', 1); }); R.pill('ABOUT 25 YEARS: 2.5 TO 3%', 960, 250, 52, pop(lt, 0.8), { hi: true }); });
  sh('S15', A(14), 'comfortable cushion?', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill('A COMFORTABLE CUSHION?', 700, 430, 54, pop(lt, 0.2), { hi: true }); });
  sh('S16', A(15), 'three bites', (lt, d, t) => { R.paper(); wRect(360, 200, 1200, 110, 12, C.orange, { seed: 51, lw: 7 }); R.txt('THE GAP', 960, 255, 56, C.ink, 'center', 2); R.pill('LOCKED MONEY', 560, 560, 44, pop(lt, 0.4)); R.pill('BAD LOANS', 960, 700, 44, pop(lt, 1.6)); R.pill('RUNNING COSTS', 1360, 560, 44, pop(lt, 2.8)); });

  // ═════════ 3 · LOCKED MONEY ═════════
  sh('S17', A(16), 'deposit 100', (lt, d, t) => { R.paper(); M.note(960, 480, 1.6, -0.04); R.pill('YOU DEPOSIT ₹100', 960, 800, 56, pop(lt, 0.4), { hi: true }); }, { chap: [3, 'LOCKED MONEY'] });
  sh('S18a', A(17), 'cash with RBI', (lt, d, t) => { R.paper(); vault(960, 500, 1.3); R.pill('CASH KEPT WITH THE RBI', 960, 820, 52, pop(lt, 0.4), { hi: true }); });
  sh('S18b', A(17, 5.4), 'earns no interest', (lt, d, t) => { R.paper(); vault(960, 500, 1.1); K.redX(1260, 330, 0.4, pop(lt, 0.5)); R.pill('EARNS THE BANK NO INTEREST', 960, 820, 52, pop(lt, 0.3), { hi: true }); });
  sh('S18c', A(17, 9.0), 'say 4 rupees', (lt, d, t) => { R.paper(); M.coinStack(960, 700, 1.3, 4); R.pill('SAY ₹4  ·  ILLUSTRATIVE', 960, 200, 56, pop(lt, 0.4), { hi: true }); });
  sh('S18d', A(17, 12.4), 'share changes', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.shrug, armL: K.ARM.hip }); R.pill('THE REAL SHARE CHANGES OVER TIME', 1330, 420, 44, pop(lt, 0.4)); });
  sh('S19a', A(18), 'SLR 18 percent', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.18, color: C.orange }, { v: 0.82, color: C.grayLight }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('AT LEAST 18% IN SAFE ASSETS', 960, 880, 50, pop(lt, 1.0), { hi: true }); });
  sh('S19b', A(18, 5.2), 'govt securities not loans', (lt, d, t) => { R.paper(); M.page(960, 480, 1.4, -0.03, 'GOVT'); R.pill('MOSTLY GOVERNMENT SECURITIES', 960, 860, 46, pop(lt, 0.3)); R.pill('THESE ARE NOT LOANS', 960, 190, 50, pop(lt, 1.2), { hi: true }); });
  sh('S20', A(19), 'held 22-25', (lt, d, t) => { R.paper(); const base = 780; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 200, 0.18 * 1600 * eo(seg(lt, 0.2, 1)), C.green, 1, 9); R.bar(1160, base, 200, 0.235 * 1600 * eo(seg(lt, 0.5, 1.4)), C.orange, 1, 10); R.txt('MINIMUM', 760, base + 46, 36, C.ink, 'center', 1); R.txt('HELD', 1160, base + 46, 36, C.ink, 'center', 1); R.pill('HELD: 22 TO 25%', 1160, 250, 50, pop(lt, 1.4), { hi: true }); });
  sh('S21a', A(20), '4 + 18 + 78', (lt, d, t) => { R.paper(); stack(260, 450, 1400, 160, [{ v: 4, color: C.grayLight }, { v: 18, color: C.blue }, { v: 78, color: C.green }], 100, eo(seg(lt, 0.2, 2.4)), 60); R.pill('₹4', 260 + 28, 340, 40, pop(lt, 0.8)); R.pill('₹18', 260 + 4 / 100 * 1400 + 126, 340, 40, pop(lt, 1.4)); R.pill('₹78 CAN BE LENT', 260 + 22 / 100 * 1400 + 546, 740, 46, pop(lt, 2.2), { hi: true }); });
  sh('S21b', A(20, 5.4), 'about 78', (lt, d, t) => { R.paper(); big('~₹78', 960, 440, 300, C.ink); R.pill('OUT OF ₹100  ·  ILLUSTRATIVE', 960, 700, 50, pop(lt, 0.4), { hi: true }); });
  sh('S22', A(21), 'rate applies to part of the money', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('LOAN RATE: ONLY ON PART OF YOUR MONEY', 1300, 400, 44, pop(lt, 0.4), { hi: true }); });

  // ═════════ 4 · BAD LOANS ═════════
  sh('S23', A(22), 'some do not repay', (lt, d, t) => { R.paper(); M.note(960, 480, 1.5, -0.05); K.redX(1340, 340, 0.4, pop(lt, 1.0)); R.pill('SOME BORROWERS DON\'T PAY BACK', 960, 840, 50, pop(lt, 0.3), { hi: true }); }, { chap: [4, 'BAD LOANS'] });
  sh('S24a', A(23), '2.3 pct stuck', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.023, color: C.orange }, { v: 0.977, color: C.green }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('2.3% OF LOANS STUCK  ·  MARCH 2025', 960, 880, 46, pop(lt, 1.2), { hi: true }); });
  sh('S24b', A(23, 5.2), 'vs 2.8', (lt, d, t) => { R.paper(); const base = 780; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 200, 2.8 * 130 * eo(seg(lt, 0.2, 1)), C.grayLight, 1, 11); R.bar(1160, base, 200, 2.3 * 130 * eo(seg(lt, 0.5, 1.3)), C.orange, 1, 12); R.txt('MAR 2024', 760, base + 46, 34, C.ink, 'center', 1); R.txt('MAR 2025', 1160, base + 46, 34, C.ink, 'center', 1); R.pill('2.8% A YEAR EARLIER', 960, 220, 50, pop(lt, 1.4)); });
  sh('S25', A(24), 'multi-decade low', (lt, d, t) => { R.paper(); K.crown(960, 520, 1.4); R.pill('A MULTI-DECADE LOW', 960, 820, 56, pop(lt, 0.3), { hi: true }); });
  sh('S26a', A(25), 'provisions', (lt, d, t) => { R.studio(880); M.jar(960, 560, 1.4, 0.2 + 0.6 * eo(seg(lt, 0.3, 4))); R.pill('MONEY SET ASIDE IN ADVANCE', 960, 220, 52, pop(lt, 0.3)); R.pill('CALLED PROVISIONING', 960, 320, 40, pop(lt, 1.2)); });
  sh('S26b', A(25, 5.4), '3 pct in 2018', (lt, d, t) => { R.paper(); big('~3%', 960, 440, 320, C.ink); R.pill('OF ASSETS  ·  PUBLIC SECTOR BANKS, 2018', 960, 720, 46, pop(lt, 0.5), { hi: true }); });
  sh('S27', A(26), 'more than the margin', (lt, d, t) => { R.paper(); const base = 780; line([[560, base], [1360, base]], C.ink, 6); R.bar(760, base, 200, 3.0 * 150 * eo(seg(lt, 0.2, 1.2)), C.orange, 1, 13); R.bar(1160, base, 200, 2.4 * 150 * eo(seg(lt, 0.5, 1.4)), C.green, 1, 14); R.txt('SET ASIDE', 760, base + 46, 34, C.ink, 'center', 1); R.txt('MARGIN', 1160, base + 46, 34, C.ink, 'center', 1); R.pill('MORE THAN THE WHOLE MARGIN', 960, 200, 52, pop(lt, 1.4), { hi: true }); });
  sh('S28', A(27), 'checks income and history', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.hold, armL: K.ARM.hip, mouth: 'talk', holding: (x, y) => { M.page(x + 30, y - 40, 0.28, 0.08, 'CHECK'); } }); R.pill('INCOME + CREDIT HISTORY CHECKED', 700, 430, 44, pop(lt, 0.4), { hi: true }); });
  sh('S29', A(28), 'risk the gap pays for', (lt, d, t) => { R.paper(); pipe(420, 1500, 520, t, true); K.redX(960, 520, 0.5, pop(lt, 0.4)); R.pill('BAD LOANS: THE RISK THE GAP PAYS FOR', 960, 800, 44, pop(lt, 0.3), { hi: true }); });

  // ═════════ 5 · WHAT IS LEFT ═════════
  sh('S30a', A(29), 'running the place', (lt, d, t) => { R.studio(880); M.bank(960, 520, 1.2); R.pill('BRANCHES, STAFF, COMPUTERS', 960, 190, 52, pop(lt, 0.3)); }, { chap: [5, 'WHAT\'S LEFT'] });
  sh('S30b', A(29, 5.2), '2 per 100', (lt, d, t) => { R.paper(); big('~₹2', 960, 440, 320, C.ink); R.pill('RUNNING COSTS PER ₹100 OF ASSETS', 960, 720, 46, pop(lt, 0.5), { hi: true }); });
  sh('S31', A(30), 'tax 50 paise', (lt, d, t) => { R.paper(); big('~50 PAISE', 960, 440, 230, C.ink); R.pill('TAX PER ₹100 OF ASSETS', 960, 700, 52, pop(lt, 0.4), { hi: true }); });
  sh('S32', A(31), 'stack it up', (lt, d, t) => { R.paper(); const base = 780, k = 150; line([[500, base], [1420, base]], C.ink, 6); R.bar(640, base, 200, 2.75 * k, C.green, eo(seg(lt, 0.2, 1)), 15); const c = eo(seg(lt, 2.2, 3.6)), tx = eo(seg(lt, 4.2, 5.4)); wRect(960 - 100, base - 2.75 * k, 200, 2.0 * k * c, 10, C.grayLight, { seed: 16, lw: 7 }); wRect(1280 - 100, base - 2.75 * k + 2.0 * k, 200, 0.5 * k * tx, 10, C.grayLight, { seed: 17, lw: 7 }); R.pill('MARGIN 2.5 TO 3', 640, 880 - 60, 36, pop(lt, 0.3)); R.pill('COSTS ~2', 960, 880 - 60, 36, pop(lt, 2.3)); R.pill('TAX ~0.5', 1280, 880 - 60, 36, pop(lt, 4.3)); });
  sh('S33a', A(32), 'fees too', (lt, d, t) => { R.paper(); M.note(960, 480, 1.4, -0.05); R.pill('BANKS ALSO EARN FEES', 960, 800, 52, pop(lt, 0.4)); });
  sh('S33b', A(32, 4.6), 'ROA 1.4', (lt, d, t) => { R.paper(); big('1.4%', 960, 440, 340, C.ink); R.pill('RETURN ON ASSETS  ·  2024-25', 960, 720, 50, pop(lt, 0.5), { hi: true }); });
  sh('S34a', A(33), '1.4 out of 100', (lt, d, t) => { R.paper(); grid100(660, 130, 52, 1.4 * eo(seg(lt, 0.4, 1.6))); R.pill('ABOUT ₹1.40 PER ₹100 OF ASSETS', 960, 850, 44, pop(lt, 1.2), { hi: true }); });
  sh('S34b', A(33, 5.4), 'thin margin big scale', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('THIN MARGIN, MADE BIG BY SCALE', 1300, 400, 46, pop(lt, 0.4), { hi: true }); });

  // ═════════ 6 · THE SAFETY NET ═════════
  sh('S35', A(34), 'what if the bank fails', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.chin, armL: K.ARM.hip }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('WHAT IF THE BANK FAILS?', 640, 450, 52, pop(lt, 0.2), { hi: true }); }, { chap: [6, 'THE SAFETY NET'] });
  sh('S36a', A(35), 'DICGC shield', (lt, d, t) => { R.paper(); shield(960, 500, 1.8, pop(lt, 0.2, 0.5)); R.pill('DEPOSIT INSURANCE  ·  DICGC', 960, 880, 50, pop(lt, 0.8), { hi: true }); });
  sh('S36b', A(35, 5.0), '5 lakh per depositor per bank', (lt, d, t) => { R.paper(); big('₹5 LAKH', 960, 420, 250, C.ink); R.pill('PER DEPOSITOR, PER BANK', 960, 640, 52, pop(lt, 0.4), { hi: true }); R.pill('PRINCIPAL + INTEREST TOGETHER', 960, 740, 40, pop(lt, 1.2)); });
  sh('S37', A(36), 'feb 2020', (lt, d, t) => { R.paper(); wRect(560, 230, 800, 560, 30, C.white, { seed: 981 }); wRect(560, 230, 800, 130, 30, C.green, { seed: 982 }); R.txt('FEBRUARY 2020', 960, 296, 66, C.white, 'center', 3); big('₹5 LAKH', 960, 560, 170, C.ink); R.pill('THE LIMIT SINCE', 960, 850, 50, pop(lt, 0.4)); });
  sh('S38', A(37), 'accounts added together', (lt, d, t) => { R.paper(); ['SAVINGS', 'CURRENT', 'FD', 'RD'].forEach((s, i) => infoCard(480 + i * 320, 380, 280, 130, s, pop(lt, 0.3 + i * 0.5))); shield(960, 680, 0.7, pop(lt, 2.8)); R.pill('ADDED TOGETHER: ONE LIMIT PER BANK', 960, 880, 44, pop(lt, 3.0), { hi: true }); });
  sh('S39', A(38), 'other bank own limit', (lt, d, t) => { R.paper(); bankN(560, 460, 0.7); bankN(1360, 460, 0.7); shield(560, 300, 0.4, pop(lt, 0.6)); shield(1360, 300, 0.4, pop(lt, 1.4)); R.pill('EACH BANK: ITS OWN LIMIT', 960, 840, 50, pop(lt, 0.3), { hi: true }); });
  sh('S40', A(39), 'not advice', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill('HOW THE RULE WORKS, NOT ADVICE', 1300, 400, 44, pop(lt, 0.3), { hi: true }); });
  sh('S41', A(40), 'safety net because bank lends', (lt, d, t) => { R.paper(); M.bank(960, 500, 1.1); shield(1400, 560, 0.8, pop(lt, 0.4)); R.pill('A NET FOR A BANK THAT LENDS YOUR MONEY', 960, 880, 44, pop(lt, 0.8), { hi: true }); });

  // ═════════ RECAP ═════════
  sh('S42a', A(41), 'host recap', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('QUICK RECAP', 700, 450, 58, pop(lt, 0.3), { hi: true }); }, { chap: [7, 'RECAP'] });
  sh('S42b', A(41, 3.6), 'rates recap', (lt, d, t) => { R.paper(); rateBars(1, true); R.pill('DEC 2024: ~7% PAID, ALMOST 10% CHARGED', 960, 190, 46, pop(lt, 0.3), { hi: true }); });
  sh('S43', A(42), 'three bites recap', (lt, d, t) => { R.paper(); [[480, 'LOCKED MONEY'], [960, 'BAD LOANS'], [1440, 'COSTS + TAX']].forEach(([x, lab], i) => { const p = pop(lt, 0.3 + i * 1.5); if (p > 0) { ctx.save(); ctx.translate(x, 480); ctx.scale(p, p); if (i === 0) lock(0, 0, 1.1); else if (i === 1) M.note(0, 0, 0.7, -0.05); else M.bank(0, 0, 0.7); ctx.restore(); if (i === 1) K.redX(x + 140, 400, 0.3, p); R.pill(lab, x, 780, 40, p); } }); });
  sh('S44', A(43), 'left over 1.4', (lt, d, t) => { R.paper(); grid100(660, 130, 52, 1.4); R.pill('WHAT\'S LEFT: ~₹1.40 PER ₹100  ·  2024-25', 960, 850, 44, pop(lt, 0.4), { hi: true }); });
  sh('S45', A(44), 'insured 5 lakh', (lt, d, t) => { R.paper(); shield(960, 480, 1.7, pop(lt, 0.2, 0.5)); R.pill('INSURED UP TO ₹5 LAKH PER BANK', 960, 880, 48, pop(lt, 0.8), { hi: true }); });
  sh('S46', A(45), 'what the gap pays for', (lt, d, t) => { R.paper(); rateBars(1, true); R.pill('WHAT IS THAT GAP PAYING FOR?', 960, 190, 54, pop(lt, 0.3), { hi: true }); });
  sh('S47', A(46), 'price of the pipe', (lt, d, t) => { R.paper(); pipe(380, 1540, 560, t, true); M.bank(960, 460, 0.7); R.pill('THE PRICE OF THE PIPE', 960, 820, 56, pop(lt, 0.4), { hi: true }); });
  sh('S48', A(47), 'where does the gap go', (lt, d, t) => { R.paper(); stack(360, 430, 1200, 150, [{ v: 25, color: C.blue }, { v: 25, color: C.red }, { v: 25, color: C.grayLight }, { v: 25, color: C.orange }], 100, eo(seg(lt, 0.2, 2.2)), 70); R.pill('LOCKED · BAD LOANS · COSTS + TAX · PROFIT', 960, 300, 42, pop(lt, 1.0)); R.pill('ILLUSTRATION, NOT TO SCALE', 960, 660, 40, pop(lt, 2.4)); R.pill('THE GAP GOES HERE', 960, 780, 54, pop(lt, 2.4), { hi: true }); });
  sh('S49', A(48), 'subscribe', (lt, d, t) => { R.studio(880); host(960, lt, { arm: K.ARM.open, armL: K.ARM.open, mouth: 'grin' }); R.pill('RUPEE ROOTS  ·  EDUCATION ONLY', 960, 190, 54, pop(lt, 0.4), { hi: true }); });

  return { shots: S, cues: CUES };
}
