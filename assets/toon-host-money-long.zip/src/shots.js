// UPI IS NOT AN APP  (Rupee Roots long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, gold = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as M from './core/money.js';
import * as G from './core/gps.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
const big = (s, x, y, size, color = C.orange) => R.txt(s, x, y, size, color, 'center', 2);
const bgPaper = () => R.paper();
// a bank with a name pill under it
function bankN(x, y, s, name, sc = 1, hi = false) { M.bank(x, y, s); if (name) R.pill(name, x, y + 190 * s + 40, 36, sc, hi ? { hi: true } : {}); }
// a tiny phone with a rupee screen
const mini = (x, y, s, rot = 0) => M.upiPhone(x, y, s, rot, 1);
// shop-keeper style small stall for the chai scenes
function bars(vals, labels, base, h, p, hiIdx = -1, x0 = 360, step = 300, w = 180) {
  line([[x0 - 120, base], [x0 + step * (vals.length - 1) + 120, base]], C.ink, 6);
  vals.forEach((v, i) => {
    const pp = eo(seg(p, i * 0.18, i * 0.18 + 0.4)); R.bar(x0 + i * step, base, w, Math.max(6, v * h), i === hiIdx ? C.orange : C.green, pp, i + 1);
    R.txt(labels[i], x0 + i * step, base + 44, 36, C.ink, 'center', 1);
  });
}
function grid21(lt, t0 = 0) {
  for (let i = 0; i < 21; i++) { const c = i % 7, r = Math.floor(i / 7), p = pop(lt, t0 + i * 0.07, 0.3); if (p > 0) { ctx.save(); ctx.translate(420 + c * 180, 330 + r * 180); ctx.scale(p, p); M.bank(0, 0, 0.3); ctx.restore(); } }
}
function hub(t, lt, n = 1) {
  // a central gold hub with banks (top) and phones (bottom) plugged in; lines first, hub on top
  const cx = 960, cy = 470;
  const tops = [[400, 250], [760, 190], [1160, 190], [1520, 250]], bots = [[400, 690], [760, 730], [1160, 730], [1520, 690]];
  tops.forEach(([x, y], i) => { if (lt > i * 0.25) line([[x, y + 40], [cx, cy]], C.ink, 6); });
  bots.forEach(([x, y], i) => { if (lt > 1.0 + i * 0.25) line([[x, y - 40], [cx, cy]], C.ink, 6); });
  wEll(cx, cy, 150, 150, C.orange, { seed: 501, n: 20 }); R.txt('UPI', cx, cy, 90, C.ink, 'center', 3);
  tops.forEach(([x, y], i) => { if (lt > i * 0.25) M.bank(x, y, 0.28); });
  bots.forEach(([x, y], i) => { if (lt > 1.0 + i * 0.25) mini(x, y, 0.3); });
}

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;
  const cam = [960, 520];
  const sh = (id, at, note, draw, extra = {}) => add({ id, at, cam, zoom: 0.04, note, draw, ...extra });

  // ═════════ HOOK ═════════
  { const st = A(0), two = Wc('two', 0);
    sh('S01', st, 'chai stall with a QR sticker', (lt, d, t) => { R.studio(880); M.stall(960, 880, 1.6, t); mini(1480 - Math.min(lt / 1.5, 1) * 220, 600, 0.6, -0.25); R.pill('2 SECONDS', 440, 300, 54, pop(lt, two - st), { hi: true }); }); }
  { const st = A(1), less = Wc('less', 1);
    sh('S02a', st, '21 banks', (lt, d, t) => { R.paper(); M.bank(960, 520, 1.2); R.pill('JUST 21 BANKS', 960, 850, 56, pop(lt, 0.6), { hi: true }); });
    sh('S02b', less, 'less than 1 lakh payments', (lt, d, t) => { R.paper(); M.coinStack(960, 640, 1.1, 2); R.pill('LESS THAN 1 LAKH PAYMENTS A MONTH', 960, 220, 50, pop(lt, 0.3), { hi: true }); }); }
  sh('S03', A(2), 'about half of real-time payments', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.5, color: C.orange }, { v: 0.5, color: C.grayLight }], eo(seg(lt, 0.2, 1.4)), 0); R.pill('ABOUT HALF OF THE WORLD\'S REAL-TIME PAYMENTS', 960, 880, 44, pop(lt, 1.4)); });
  sh('S04', A(3), 'host: what you will learn', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('HOW ONE PAYMENT TRAVELS', 640, 450, 52, pop(lt, 0.1), { hi: true }); });
  { const st = A(4), ev = Wc('every', 4);
    sh('S05a', st, 'not just an app', (lt, d, t) => { R.paper(); mini(960, 500, 0.95); K.redX(1300, 330, 0.4, pop(lt, 1.6)); R.pill('JUST AN APP?', 1450, 660, 54, pop(lt, 0.5)); });
    sh('S05b', ev, 'numbers from official pages', (lt, d, t) => { R.paper(); M.page(960, 500, 1.4, 0.04, 'REPORT'); K.check(1250, 330, 0.3, pop(lt, 0.8)); R.pill('EVERY NUMBER FROM A PAGE WE OPENED', 960, 860, 46, pop(lt, 0.3)); }); }
  sh('S06', A(5), 'UPI turned ten', (lt, d, t) => { R.paper(); K.burst(960, 480, 2.8, 1, C.yellow, lt * 0.1); big('10', 960, 480, 330, C.ink); R.pill('UPI TURNED TEN IN 2026', 960, 850, 52, pop(lt, 0.4), { hi: true }); });

  // ═════════ 1 · THE OLD PROBLEM ═════════
  { const st = A(6), diff = Wc('different', 6);
    sh('S07', st, 'two banks, money between', (lt, d, t) => { R.paper(); M.bank(520, 520, 0.9); M.bank(1400, 520, 0.9); const p = (lt * 0.5) % 1; M.note(lerp(640, 1280, p), 480 - Math.sin(p * PI) * 90, 0.35, 0.1); R.pill('A FRIEND IN ANOTHER BANK', 960, 190, 52, pop(lt, 0.4), { hi: true }); }, { chap: [1, 'THE OLD PROBLEM'] }); }
  sh('S08', A(7), 'needs account number and IFSC', (lt, d, t) => { R.paper(); wRect(560, 250, 800, 440, 24, C.white, { seed: 601 }); R.pill('ACCOUNT NUMBER', 960, 360, 46, pop(lt, 0.3)); R.pill('IFSC CODE', 960, 480, 46, pop(lt, 1.6)); wRect(700, 570, 520, 40, 10, C.paperLine, { lw: 0 }); });
  sh('S09', A(8), 'one wrong digit', (lt, d, t) => { R.paper(); const ds = ['4', '7', '2', '9', '1', '6']; ds.forEach((c, i) => R.txt(c, 560 + i * 160, 480, 150, i === 3 ? C.red : C.ink, 'center', 1)); ctx.save(); ctx.beginPath(); ctx.ellipse(560 + 3 * 160, 470, 80, 110, 0, 0, TAU); ctx.lineWidth = 12; ctx.strokeStyle = C.red; ctx.stroke(); ctx.restore(); R.pill('ONE WRONG DIGIT', 960, 790, 56, pop(lt, 1.0), { hi: true }); });
  { const st = A(9), np = A(9) + 99;
    sh('S10a', st, 'IMPS 2010', (lt, d, t) => { R.paper(); big('IMPS', 960, 450, 260, C.ink); R.pill('FAST BANK-TO-BANK  ·  2010  ·  RUN BY NPCI', 960, 700, 52, pop(lt, 0.5), { hi: true }); }); }
  { const st = A(10), rb = Wc('Reserve', 10), roads = Wc('shared', 10);
    sh('S11a', st, 'around 2009', (lt, d, t) => { R.paper(); big('2009', 960, 450, 300, C.ink); R.pill('NPCI IS BORN', 960, 720, 54, pop(lt, 0.5), { hi: true }); });
    sh('S11b', rb, 'RBI + IBA set it up', (lt, d, t) => { R.paper(); R.pill('RESERVE BANK OF INDIA', 560, 330, 44, pop(lt, 0.2)); R.pill('INDIAN BANKS\' ASSOCIATION', 560, 650, 44, pop(lt, 0.9)); R.arrowV(870, 360, 280, 0.4, C.orange, 28); R.arrowV(870, 620, 280, -0.4, C.orange, 28); wRect(1160, 400, 420, 180, 30, C.sweater, { seed: 612 }); big('NPCI', 1370, 490, 100, C.white); });
    sh('S11c', roads, 'shared payment roads', (lt, d, t) => { R.studio(700); M.road(780, 150, t); M.bank(420, 480, 0.5); M.bank(960, 480, 0.5); M.bank(1500, 480, 0.5); R.pill('SHARED ROADS FOR EVERY BANK', 960, 200, 50, pop(lt, 0.4), { hi: true }); }); }
  sh('S12', A(11), 'host: roads exist, no easy way on', (lt, d, t) => { R.studio(880); host(640, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, mouth: 'talk' }); R.pill('ROADS: YES.  EASY ENTRANCE: NO', 1300, 400, 46, pop(lt, 0.4), { hi: true }); });

  // ═════════ 2 · ONE ADDRESS, ONE PIN ═════════
  sh('S13', A(12), 'a payment address', (lt, d, t) => { R.paper(); M.envelope(960, 480, 1.4, -0.06); R.pill('AN ADDRESS FOR MONEY', 960, 820, 56, pop(lt, 0.5), { hi: true }); }, { chap: [2, 'ONE ADDRESS, ONE PIN'] });
  sh('S14', A(13), 'short ID hides the account', (lt, d, t) => { R.paper(); wRect(640, 320, 640, 340, 30, C.grayLight, { seed: 621 }); R.txt('ACCOUNT DETAILS', 960, 400, 40, C.gray, 'center', 2); K.sticker('ravi@bank', 960, 520, 70, C.orange, C.ink, pop(lt, 0.5), -0.04); R.pill('THE REST STAYS HIDDEN', 960, 820, 50, pop(lt, 1.6)); });
  { const st = A(14), pin = Wc('secret', 14);
    sh('S15a', st, 'phone tied to your bank', (lt, d, t) => { R.paper(); mini(640, 520, 0.9); line([[800, 520], [1100, 520]], C.ink, 14); M.bank(1300, 520, 0.7); R.pill('YOUR PHONE, TIED TO YOUR BANK', 960, 190, 50, pop(lt, 0.4), { hi: true }); });
    sh('S15b', pin, 'secret PIN', (lt, d, t) => { R.paper(); M.pinBox(960, 460, 1.6, 4, eo(seg(lt, 0.2, 1.2))); R.pill('A SECRET PIN ONLY YOU KNOW', 960, 760, 54, pop(lt, 0.4), { hi: true }); }); }
  sh('S16', A(15), 'scan, amount, PIN', (lt, d, t) => { R.paper(); mini(700, 520, 1.0, 0); M.qr(1250, 520, 0.9, 0.05); R.pill('SCAN  ·  AMOUNT  ·  PIN', 960, 180, 56, pop(lt, 0.4), { hi: true }); });
  { const st = A(16), buzz = Wc('buzz', 16);
    sh('S17a', st, 'money from your bank to shop bank', (lt, d, t) => { R.paper(); bankN(480, 470, 0.8, 'YOUR BANK'); bankN(1440, 470, 0.8, 'SHOP\'S BANK'); const p = eio((lt * 0.4) % 1); M.note(lerp(640, 1280, p), 440, 0.38, 0.1); });
    sh('S17b', buzz, 'both phones buzz', (lt, d, t) => { R.studio(880); const sh2 = Math.sin(lt * 40) * 5; mini(660 + sh2, 520, 0.8, -0.1); mini(1260 - sh2, 520, 0.8, 0.1); M.chai(960, 640, 1.0, t); K.check(960, 330, 0.22, pop(lt, 0.4)); }); }
  sh('S18', A(17), '24x7', (lt, d, t) => { R.paper(); K.clock(960, 450, 1.5, lt * 1.1); R.pill('24 x 7  ·  EVEN SUNDAYS AND HOLIDAYS', 960, 830, 46, pop(lt, 0.5), { hi: true }); });
  sh('S19', A(18), 'open: any bank any app plugs in', (lt, d, t) => { R.paper(); hub(t, lt); R.pill('OPEN TO EVERY BANK AND APP', 960, 880, 44, pop(lt, 2.0), { hi: true }); });
  { const st = A(19), road = Wc('road', 19);
    sh('S20a', st, 'apps are windows', (lt, d, t) => { R.paper(); [[620, 540, C.green], [960, 540, C.orange], [1300, 540, C.sweater]].forEach(([x, y, c], i) => { wRect(x - 120, y - 150, 240, 300, 20, c, { seed: 630 + i }); wRect(x - 90, y - 120, 180, 240, 10, C.paper, { seed: 640 + i, lw: 5 }); line([[x, y - 120], [x, y + 120]], C.ink, 6); line([[x - 90, y], [x + 90, y]], C.ink, 6); }); R.pill('APPS ARE JUST WINDOWS', 960, 850, 52, pop(lt, 0.4), { hi: true }); });
    sh('S20b', road, 'the road belongs to everybody', (lt, d, t) => { R.studio(700); M.road(760, 170, t); M.bank(480, 440, 0.5); mini(960, 440, 0.4); M.bank(1440, 440, 0.5); R.pill('THE ROAD BELONGS TO EVERYBODY', 960, 200, 50, pop(lt, 0.4), { hi: true }); }); }
  sh('S21', A(20), 'different bank, different app, it works', (lt, d, t) => { R.studio(880); mini(560, 520, 0.7, -0.1); M.stall(1330, 880, 0.9, t); K.check(960, 330, 0.25, pop(lt, 0.8)); R.pill('DIFFERENT BANK, DIFFERENT APP', 960, 190, 48, pop(lt, 0.3)); });

  // ═════════ 3 · A SLOW START ═════════
  sh('S22', A(21), 'host: instant hit? no', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill('AN INSTANT HIT?', 700, 430, 58, pop(lt, 0.2), { hi: true }); }, { chap: [3, 'A SLOW START'] });
  { const st = A(22), tw = Wc('Mumbai', 22);
    sh('S23a', st, '11 April 2016', (lt, d, t) => { R.paper(); wRect(560, 230, 800, 560, 30, C.white, { seed: 651 }); wRect(560, 230, 800, 130, 30, C.green, { seed: 652 }); R.txt('APRIL 2016', 960, 296, 70, C.white, 'center', 3); big('11', 960, 560, 300, C.ink); R.pill('PILOT IN MUMBAI', 960, 850, 50, pop(lt, 0.5)); });
    sh('S23b', tw, '21 banks', (lt, d, t) => { R.paper(); grid21(lt); R.pill('21 BANKS', 960, 850, 54, pop(lt, 1.6), { hi: true }); }); }
  sh('S24', A(23), 'host: would you switch?', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.chin, armL: K.ARM.hip }); M.stall(1400, 880, 0.8, t, false); R.pill('WOULD YOU SWITCH?', 1340, 300, 52, pop(lt, 0.4), { hi: true }); });
  sh('S25', A(24), 'apps arrived in August', (lt, d, t) => { R.paper(); ['APR', 'MAY', 'JUN', 'JUL', 'AUG'].forEach((m, i) => { const on = i === 4; wRect(360 + i * 240, 400, 200, 200, 20, on ? C.orange : C.white, { seed: 660 + i }); R.txt(m, 460 + i * 240, 500, 54, C.ink, 'center', 2); }); R.pill('BANK APPS ARRIVE IN AUGUST', 960, 760, 52, pop(lt, 0.6), { hi: true }); });
  { const st = A(25), wo = Wc('worth', 25);
    sh('S26a', st, '93,000 payments', (lt, d, t) => { R.paper(); big('~93,000', 960, 450, 230, C.ink); R.pill('PAYMENTS IN THE WHOLE MONTH, AUGUST 2016', 960, 720, 44, pop(lt, 0.5)); });
    sh('S26b', wo, '3 crore rupees', (lt, d, t) => { R.paper(); M.coinStack(960, 640, 1.2, 3); R.pill('WORTH ABOUT ₹3 CRORE', 960, 220, 56, pop(lt, 0.4), { hi: true }); }); }
  sh('S27', A(26), 'rounding error', (lt, d, t) => { R.paper(); wRect(360, 220, 1200, 560, 30, C.white, { seed: 671 }); circle(960, 500, 8 + Math.sin(lt * 4) * 1, C.orange); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('A ROUNDING ERROR', 960, 860, 54, pop(lt, 0.5), { hi: true }); });
  sh('S28', A(27), 'seed waiting', (lt, d, t) => { R.studio(880); M.sprout(960, 760, 1.5, 0.3 + 0.25 * eo(seg(lt, 0.2, 4))); R.pill('WAITING FOR ITS MOMENT', 960, 220, 54, pop(lt, 0.4), { hi: true }); });

  // ═════════ 4 · THE PUSH ═════════
  { const st = A(28), gov = Wc('government', 28);
    sh('S29a', st, 'cash hard to find', (lt, d, t) => { R.paper(); M.note(960, 500, 1.4, -0.06); K.redX(1340, 380, 0.35, pop(lt, 1.0)); R.pill('CASH BECOMES HARD TO FIND', 960, 850, 52, pop(lt, 0.3)); }, { chap: [4, 'THE PUSH'] });
    sh('S29b', gov, 'high-value notes withdrawn', (lt, d, t) => { R.paper(); M.note(760, 500, 0.9, -0.12); M.note(1160, 560, 0.9, 0.1); K.redX(960, 380, 0.3, pop(lt, 0.6)); R.pill('HIGH-VALUE NOTES WITHDRAWN, NOVEMBER 2016', 960, 860, 44, pop(lt, 0.3), { hi: true }); }); }
  sh('S30', A(29), 'another way to pay', (lt, d, t) => { R.paper(); M.upiPhone(960, 500, 1.1, 0, eo(seg(lt, 1, 2))); K.mark('?', 1240, 300 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, 0.1); R.pill('ANOTHER WAY TO PAY?', 600, 300, 50, pop(lt, 0.2)); });
  { const st = A(30), ov = Wc('overnight', 30);
    sh('S31a', st, 'quiet for months', (lt, d, t) => { R.paper(); M.growth(960, 500, 1000, 500, [0.04, 0.05, 0.06, 0.07, 0.08, 0.09], eo(seg(lt, 0.2, 3)), C.green); R.pill('QUIET FOR MONTHS', 960, 840, 52, pop(lt, 0.4)); });
    sh('S31b', ov, 'then almost overnight', (lt, d, t) => { R.paper(); M.growth(960, 500, 1000, 500, [0.04, 0.05, 0.06, 0.1, 0.5, 0.95], eo(seg(lt, 0.1, 1.8)), C.green); R.pill('THEN, ALMOST OVERNIGHT', 960, 840, 52, pop(lt, 0.4), { hi: true }); }); }
  sh('S32', A(31), 'BHIM app by NPCI', (lt, d, t) => { R.paper(); M.upiPhone(700, 520, 1.1); R.pill('BHIM APP', 1360, 380, 60, pop(lt, 0.4), { hi: true }); R.pill('LATE DECEMBER 2016', 1360, 520, 44, pop(lt, 0.9)); R.pill('BUILT BY NPCI', 1360, 650, 44, pop(lt, 1.6)); });
  sh('S33', A(32), 'Nov: 90 crore', (lt, d, t) => { R.paper(); bars([0.09], ['NOVEMBER 2016'], 760, 520, eo(seg(lt, 0.2, 1.2)), 0, 960, 300, 220); R.pill('~₹90 CRORE', 960, 570, 56, pop(lt, 1.0), { hi: true }); });
  { const st = A(33), rough = Wc("that's", 33);
    sh('S34a', st, 'Jan: 990 crore', (lt, d, t) => { R.paper(); bars([0.09, 0.99], ['NOV 2016', 'JAN 2017'], 760, 520, 1, 1, 660, 600, 220); R.pill('~₹90 CRORE', 660, 650, 44, 1); R.pill('~₹990 CRORE, FIRST 19 DAYS', 1260, 200, 44, pop(lt, 0.5), { hi: true }); });
    sh('S34b', rough, 'ten times', (lt, d, t) => { R.paper(); K.burst(960, 480, 2.8, 1, C.yellow, lt * 0.1); big('10x', 960, 480, 320, C.ink); R.pill('ROUGHLY TEN TIMES MORE', 960, 850, 52, pop(lt, 0.4), { hi: true }); }); }
  sh('S35', A(34), 'host: lesson', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.point, mouth: 'talk' }); K.bulb(1260, 420, 1.6, 1); R.pill('GOOD TOOL + SUDDEN NEED', 1260, 760, 50, pop(lt, 0.5), { hi: true }); });

  // ═════════ 5 · THE STICKER ═════════
  sh('S36', A(35), 'the sticker', (lt, d, t) => { R.paper(); M.qr(960, 480, 1.7, Math.sin(lt) * 0.04); R.pill('THE STICKER', 960, 880, 52, pop(lt, 0.4), { hi: true }); }, { chap: [5, 'THE STICKER'] });
  sh('S37', A(36), 'one QR works with any app', (lt, d, t) => { R.paper(); [[520, 360, -0.2], [520, 700, -0.1], [1400, 360, 0.2], [1400, 700, 0.1]].forEach(([x, y, r], i) => { if (lt > 0.6 + i * 0.3) { line([[x, y], [960, 500]], C.ink, 5); mini(x, y, 0.32, r); } }); M.qr(960, 500, 1.0); R.pill('ONE QR  ·  ANY APP', 960, 880, 50, pop(lt, 0.3), { hi: true }); });
  { const st = A(37), pr = Wc('using', 37);
    sh('S38a', st, 'chaiwala, vendors', (lt, d, t) => { R.studio(880); M.stall(960, 880, 1.5, t); R.pill('SMALL SHOPS, STREET VENDORS', 960, 190, 50, pop(lt, 0.4)); });
    sh('S38b', pr, 'printed square of paper', (lt, d, t) => { R.paper(); M.qr(960, 480, 1.6, 0.03); R.pill('A PRINTED SQUARE OF PAPER', 960, 880, 52, pop(lt, 0.4), { hi: true }); }); }
  sh('S39', A(38), 'host: shop does not care which app', (lt, d, t) => { R.studio(880); host(660, lt, { arm: K.ARM.hold, armL: K.ARM.hip, mouth: 'grin', holding: (x, y) => { M.qr(x + 30, y - 40, 0.28, 0.08); } }); R.pill('ANY APP, SAME STICKER', 1300, 400, 50, pop(lt, 0.5), { hi: true }); });
  sh('S40', A(39), 'one billion in a month', (lt, d, t) => { R.paper(); const n = Math.floor(lerp(0, 1000, eo(seg(lt, 0.2, 2.2)))); big(n.toLocaleString('en-US') + ' MILLION', 960, 450, 150, C.ink); R.pill('OCTOBER 2019  ·  ONE BILLION IN A MONTH', 960, 700, 46, pop(lt, 1.8), { hi: true }); });
  { const st = A(40), by = Wc('twenty', 41);
    sh('S41', st, '2017 bar tiny', (lt, d, t) => { R.paper(); bars([0.002], ['2017'], 760, 520, 1, 0, 960, 300, 200); R.pill('2017: ABOUT 40 CRORE PAYMENTS', 960, 300, 52, pop(lt, 0.5), { hi: true }); });
    sh('S42', A(41), 'bars grow to 2025', (lt, d, t) => { R.paper(); const v = [0.002, 0.052, 0.185, 0.563, 1.0]; bars(v, ['2017', '2019', '2021', '2023', '2025'], 800, 560, eo(seg(lt, 0.2, 2.6)), 4, 360, 300, 180); R.pill('2025: MORE THAN 20,000 CRORE', 1250, 190, 46, pop(lt, 2.2), { hi: true }); }); }
  sh('S43', A(42), 'about 500x', (lt, d, t) => { R.paper(); K.burst(960, 470, 3.0, 1, C.yellow, lt * 0.1); big('~500x', 960, 470, 300, C.ink); R.pill('IN EIGHT YEARS  ·  OUR OWN MATHS', 960, 850, 48, pop(lt, 0.4)); });

  // ═════════ 6 · HOW BIG IS IT? ═════════
  sh('S44', A(43), 'FY 2024-25', (lt, d, t) => { R.paper(); wRect(460, 300, 1000, 300, 30, C.white, { seed: 681 }); R.txt('APR 2024  →  MAR 2025', 960, 380, 64, C.ink, 'center', 2); big('FY 2024-25', 960, 500, 130, C.orange); R.pill('ONE FULL YEAR', 960, 800, 52, pop(lt, 0.4)); }, { chap: [6, 'HOW BIG IS IT?'] });
  { const st = A(44), wo = Wc('worth', 44);
    sh('S45a', st, '186 billion', (lt, d, t) => { R.paper(); const n = Math.floor(lerp(0, 186, eo(seg(lt, 0.2, 2.0)))); big(n + ' BILLION', 960, 450, 230, C.ink); R.pill('PAYMENTS IN ONE YEAR', 960, 720, 56, pop(lt, 1.6), { hi: true }); });
    sh('S45b', wo, '260 lakh crore', (lt, d, t) => { R.paper(); M.coinStack(960, 680, 1.4, 5); R.pill('WORTH ABOUT ₹260 LAKH CRORE', 960, 210, 54, pop(lt, 0.4), { hi: true }); }); }
  sh('S46', A(45), '84% of retail payments', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.84, color: C.orange }, { v: 0.16, color: C.grayLight }], eo(seg(lt, 0.2, 1.6)), 0); R.pill('ABOUT 84% OF RETAIL PAYMENTS', 960, 880, 50, pop(lt, 1.6)); });
  sh('S47', A(46), '6000 per second', (lt, d, t) => { R.paper(); K.clock(540, 480, 1.1, lt * 6.28); big('~6,000', 1230, 440, 230, C.ink); R.pill('PAYMENTS EVERY SECOND  ·  OUR MATHS', 1230, 640, 42, pop(lt, 0.8)); });
  sh('S48', A(47), 'host: pause on that', (lt, d, t) => { R.studio(880); host(960, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('STRANGERS PAYING STRANGERS', 960, 170, 54, pop(lt, 0.4), { hi: true }); });
  sh('S49', A(48), 'average 1,400 rupees', (lt, d, t) => { R.paper(); M.note(960, 460, 1.5, -0.04, C.green, '₹'); R.pill('AVERAGE: ABOUT ₹1,400  ·  OUR MATHS', 960, 850, 50, pop(lt, 0.6), { hi: true }); });
  sh('S50', A(49), '15 billion in Nov 2024', (lt, d, t) => { R.paper(); const n = Math.floor(lerp(0, 15, eo(seg(lt, 0.2, 2.0)))); big(n + '+ BILLION', 960, 450, 230, C.ink); R.pill('NOVEMBER 2024  ·  ONE MONTH', 960, 720, 54, pop(lt, 1.6), { hi: true }); });

  // ═════════ 7 · THE WORLD NOTICES ═════════
  sh('S51', A(50), 'the world noticed', (lt, d, t) => { R.space(t, false); G.globe(960, 520, 250, lt * 0.3); R.pill('THE WORLD NOTICED', 960, 160, 58, pop(lt, 0.3), { hi: true }); }, { chap: [7, 'THE WORLD NOTICES'] });
  { const st = A(51), nu = Wc('largest', 51);
    sh('S52a', st, 'IMF June 2025', (lt, d, t) => { R.paper(); K.crown(960, 560, 1.7); R.pill('IMF  ·  JUNE 2025', 960, 760, 56, pop(lt, 0.4), { hi: true }); });
    sh('S52b', nu, 'largest by number of transactions', (lt, d, t) => { R.paper(); K.crown(960, 520, 1.4); R.pill('WORLD\'S LARGEST FAST-PAYMENT SYSTEM', 960, 740, 46, pop(lt, 0.3)); R.pill('BY NUMBER OF TRANSACTIONS', 960, 840, 40, pop(lt, 0.9)); }); }
  { const st = A(52), fo = Wc('forty-nine', 52);
    sh('S53a', st, 'ACI Worldwide report', (lt, d, t) => { R.paper(); M.page(960, 480, 1.5, -0.04, 'ACI'); R.pill('ACI WORLDWIDE  ·  2024 REPORT', 960, 850, 52, pop(lt, 0.4)); });
    sh('S53b', fo, '49% of real-time payments', (lt, d, t) => { R.paper(); R.pie(960, 500, 270, [{ v: 0.49, color: C.orange }, { v: 0.51, color: C.grayLight }], eo(seg(lt, 0.2, 1.4)), 0); R.pill('ABOUT 49% OF REAL-TIME PAYMENTS', 960, 880, 46, pop(lt, 1.2), { hi: true }); }); }
  { const st = A(53), uae = Wc('UAE', 53);
    const wm = (lt, labs) => { R.space(0, false); G.globe(960, 500, 270, 0.4); labs(); };
    sh('S54a', st, 'Bhutan 2021', (lt, d, t) => { wm(lt, () => R.pill('BHUTAN  ·  2021', 960, 880, 54, pop(lt, 0.4), { hi: true })); });
    sh('S54b', uae, 'UAE 2022', (lt, d, t) => { wm(lt, () => R.pill('UAE  ·  2022  ·  SINGAPORE LINK', 960, 880, 54, pop(lt, 0.2), { hi: true })); }); }
  { const st = A(54), pil = Wc('pilot', 54);
    sh('S55a', st, 'Eiffel Tower 2024', (lt, d, t) => { R.sky(t); M.tower(960, 880, 1.1); R.pill('EIFFEL TOWER  ·  2024', 960, 170, 56, pop(lt, 0.4), { hi: true }); });
    sh('S55b', pil, 'from 21 banks', (lt, d, t) => { R.paper(); M.bank(960, 520, 1.2); R.pill('IT ALL STARTED WITH 21 BANKS', 960, 850, 52, pop(lt, 0.4), { hi: true }); }); }

  // ═════════ RECAP ═════════
  sh('S56', A(55), 'host: recap', (lt, d, t) => { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('QUICK RECAP', 700, 450, 56, pop(lt, 0.3), { hi: true }); }, { chap: [8, 'RECAP'] });
  sh('S57', A(56), 'address + PIN on an open road', (lt, d, t) => { R.paper(); hub(t, lt); R.pill('AN ADDRESS + A PIN, ON AN OPEN ROAD', 960, 880, 44, pop(lt, 2.0), { hi: true }); });
  sh('S58', A(57), 'slow start, push, sticker', (lt, d, t) => { R.paper(); [[480, 'SLOW START'], [960, 'A PUSH'], [1440, 'THE STICKER']].forEach(([x, lab], i) => { const p = pop(lt, 0.3 + i * 1.5); if (p > 0) { ctx.save(); ctx.translate(x, 480); ctx.scale(p, p); if (i === 0) M.sprout(0, 80, 0.9, 0.4); else if (i === 1) M.upiPhone(0, 0, 0.6); else M.qr(0, 0, 0.9); ctx.restore(); R.pill(lab, x, 780, 40, p); } }); });
  { const st = A(58), two = Wc('Two', 58), three = Wc('Three', 58);
    sh('S59', st, 'three ideas: road, simple, timing', (lt, d, t) => { R.paper(); R.pill('1  A SHARED ROAD BEATS MANY PRIVATE ONES', 960, 330, 46, pop(lt, 0.4), { hi: lt < two - st + 0.0 }); if (lt > two - st) R.pill('2  SIMPLE WINS', 960, 500, 46, pop(lt, two - st), { hi: lt < three - st }); if (lt > three - st) R.pill('3  TIMING MATTERS', 960, 670, 46, pop(lt, three - st), { hi: true }); }); }
  sh('S60', A(59), 'loop: the chai sticker', (lt, d, t) => { R.studio(880); M.stall(960, 880, 1.6, t); mini(1480 - Math.min(lt / 1.5, 1) * 220, 600, 0.6, -0.25); R.pill('NOT AN APP. A SHARED ROAD.', 960, 190, 56, pop(lt, 3.0), { hi: true }); });

  return { shots: S, cues: CUES };
}
