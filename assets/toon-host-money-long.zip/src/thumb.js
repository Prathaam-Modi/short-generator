// THUMBNAIL scene (QS='&thumb=1'): dark deep green, ONE big focal object: a QR sticker inside gold scanner brackets. Text is added afterwards (PIL).
import { ctx, C, W, H, fillAll, circle, line, poly } from './core/lib.js';
import * as M from './core/money.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#0B3C32');
  for (let i = 0; i < 26; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y > 150 && y < 850) continue; circle(x, y, 3 + (i % 3), 'rgba(247,183,51,0.28)'); }
  ctx.save(); ctx.globalAlpha = 0.18; circle(1500, 430, 400, C.orange); ctx.restore();
  M.qr(1500, 430, 2.1, 0.05);
  // scanner brackets
  const cx = 1500, cy = 430, r = 360, l = 100, c = C.orange;
  for (const [sx, sy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { const x = cx + sx * r * 0.82, y = cy + sy * r * 0.82; line([[x, y - sy * l], [x, y], [x - sx * l, y]], C.ink, 40); line([[x, y - sy * l], [x, y], [x - sx * l, y]], c, 26); }
}
