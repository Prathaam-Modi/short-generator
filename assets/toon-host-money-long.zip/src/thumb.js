// THUMBNAIL scene (QS='&thumb=1'): dark deep green, ONE big focal object: two rate bars with a gold GAP. Text is added afterwards (PIL).
import { ctx, C, W, H, fillAll, circle, line, wRect } from './core/lib.js';
import * as R from './core/space.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#0B3C32');
  for (let i = 0; i < 26; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y > 150 && y < 850) continue; circle(x, y, 3 + (i % 3), 'rgba(247,183,51,0.28)'); }
  ctx.save(); ctx.globalAlpha = 0.16; circle(1560, 470, 400, C.orange); ctx.restore();
  const base = 930, k = 78;
  line([[1190, base], [1880, base]], C.ink, 10);
  wRect(1230, base - 7 * k, 260, 7 * k, 14, C.green, { seed: 3, lw: 10, wob: 1 });
  wRect(1580, base - 7 * k, 260, 7 * k, 14, C.green, { seed: 4, lw: 10, wob: 1 });
  wRect(1580, base - 9.87 * k, 260, (9.87 - 7) * k, 14, C.orange, { seed: 5, lw: 10, wob: 1 });
  R.txt('7%', 1360, base - 3.5 * k, 130, C.white, 'center', 2);
  R.txt('10%', 1710, base - 3.5 * k, 130, C.white, 'center', 2);
}
