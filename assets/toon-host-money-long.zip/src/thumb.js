// THUMBNAIL scene (QS='&thumb=1'): dark deep green, ONE big focal object: an overloaded cargo ship tipping, one gold container on top. Text is added afterwards (PIL).
import { ctx, C, W, H, fillAll, circle, line, wRect, poly } from './core/lib.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#0B3C32');
  for (let i = 0; i < 24; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 900 || y > 800) continue; circle(x, y, 3 + (i % 3), 'rgba(247,183,51,0.25)'); }
  ctx.save(); ctx.globalAlpha = 0.14; circle(1490, 520, 380, C.orange); ctx.restore();
  ctx.save(); ctx.translate(1490, 740); ctx.rotate(-0.08); ctx.scale(1.65, 1.65);
  const cols = [C.green, C.blue, C.red, C.paper, C.green, C.blue];
  for (let r = 0; r < 4; r++) for (let i = 0; i < 6; i++) { if (r === 3 && i !== 2) continue; const gold = r === 3; wRect(-200 + i * 64, -62 - r * 56, 60, 52, 6, gold ? C.orange : cols[(i + r * 2) % cols.length], { seed: 721 + i + r * 9, lw: 5, wob: 0.8 }); }
  wRect(190, -130, 70, 110, 8, C.paper, { seed: 731, lw: 6 }); wRect(200, -118, 50, 24, 4, C.blue, { seed: 732, lw: 4, wob: 0.5 });
  poly([[-240, -10], [250, -10], [210, 70], [-200, 70]], C.sweater, { seed: 733, wob: 1.5, lw: 8 });
  ctx.restore();
  ctx.lineWidth = 12; ctx.strokeStyle = C.ink; ctx.lineCap = 'round';
  for (let i = 0; i < 6; i++) { const x = 900 + i * 220; ctx.beginPath(); ctx.moveTo(x, 930); ctx.quadraticCurveTo(x + 55, 900, x + 110, 930); ctx.strokeStyle = '#2C8F78'; ctx.stroke(); }
}
