// The STYLE SHEET: the whole look in one 1080x1920 image, drawn by this style's own kit.
// Render it with:  QS='&sheet=1' node tools/capture.mjs frames review/sheet "0"   (then convert the JPG/PNG to style-sheet.png)
import { ctx, C, W, H, fillAll, rr, circle, line, wRect } from './core/lib.js';
import * as K from './core/kit.js';

function label(text, x, y, size = 34, color = C.ink, align = 'center') {
  ctx.save(); ctx.font = `900 ${size}px Inter`; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.letterSpacing = '2px'; ctx.fillText(text, x, y); ctx.restore();
}

export function drawSheet() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.letterSpacing = '0px';
  fillAll(C.bg);
  // title
  label('TOON HOST', 540, 96, 118);
  label('FLAT CARTOON  ·  THICK WOBBLY INK  ·  ONE ORANGE ACCENT', 540, 178, 26, C.gray);

  // hero, full body (left)
  ctx.fillStyle = C.floor; ctx.fillRect(40, 1236, 500, 6);
  K.shadow(290, 1236, 330);
  K.host({ x: 290, y: 780, s: 0.7, arm: K.ARM.cross, mouth: 'smile', eyes: 'n' });
  label('THE HOST', 290, 1290, 30, C.gray);

  // pose grid (right): 2 columns x 3 rows
  const poses = [
    ['CROSSED', { arm: K.ARM.cross, mouth: 'smirk' }],
    ['POINT', { arm: K.ARM.point, mouth: 'grin', eyes: 'wide', brow: 0.6 }],
    ['SHRUG', { arm: K.ARM.shrug, armL: K.ARM.shrug, mouth: 'flat', brow: 0.8, eyes: 'n' }],
    ['THINK', { arm: K.ARM.chin, mouth: 'flat', eyes: 'squint', look: -1, lookY: -1 }],
    ['EXPLAIN', { arm: K.ARM.open, armL: K.ARM.hip, mouth: 'talk', talk: 0.8 }],
    ['WAVE', { arm: K.ARM.wave, mouth: 'grin', eyes: 'happy' }],
  ];
  poses.forEach(([name, o], i) => {
    const cx = 700 + (i % 2) * 280, cy = 500 + Math.floor(i / 2) * 330;
    K.host({ x: cx, y: cy, s: 0.23, ...o });
    label(name, cx, cy + 178, 24, C.gray);
  });

  // expressions row
  label('FACES', 540, 1352, 30, C.gray);
  const faces = [
    ['n', 'smile'], ['wide', 'o'], ['happy', 'grin'], ['squint', 'smirk'], ['wide', 'sad', 1],
  ];
  // head() draws its centre at y = -340 in its own space, so lift the origin by 340 * scale to put the face centre at y 1490
  faces.forEach(([eyes, mouth, sw], i) => {
    const cx = 130 + i * 205;
    ctx.save(); ctx.translate(cx, 1528 + 340 * 0.52); ctx.scale(0.52, 0.52);
    K.head({ eyes, mouth, sweat: !!sw, brow: eyes === 'wide' ? 0.8 : 0, frown: eyes === 'squint' ? 0.6 : 0 });
    ctx.restore();
  });

  // props + marks row
  label('PROPS + MARKS', 540, 1668, 30, C.gray);
  K.phone(110, 1790, 0.3, -0.12, C.white, (w, h) => { ctx.fillStyle = C.orange; ctx.fillRect(-w / 2, -h / 2, w, 120); });
  K.brickPhone(215, 1790, 0.3, 0.1);
  K.chip(330, 1790, 0.3);
  K.bars(400, 1830, 130, 110, [0.4, 0.7, 0.55, 1], 1, 3);
  K.coin(600, 1790, 0.5, '$', 0.2);
  K.bulb(690, 1792, 0.36, 1);
  K.burst(800, 1790, 0.55, 1);
  K.mark('?', 800, 1792, 0.42, -0.1, C.orange);
  K.check(912, 1790, 0.22, 1);
  K.redX(992, 1790, 0.2, 1);

  // palette strip
  const sw = [C.ink, C.bg, C.skin, C.hair, C.jeans, C.orange, C.yellow, C.red, C.green, C.blue];
  sw.forEach((c, i) => { rr(60 + i * 96, 1866, 78, 28, 8); ctx.fillStyle = c; ctx.fill(); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); });

  // caption sample (top right corner area, under the title)
  ctx.save(); ctx.translate(540, 232); ctx.font = '900 56px Inter'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.lineWidth = 12; ctx.strokeStyle = C.ink;
  const parts = [['ONE ', C.white], ['ORANGE', C.orange], [' WORD', C.white]]; let tw = 0; for (const [t] of parts) tw += ctx.measureText(t).width;
  let x = -tw / 2; ctx.textAlign = 'left';
  for (const [t, c] of parts) { ctx.strokeText(t, x, 0); ctx.fillStyle = c; ctx.fillText(t, x, 0); x += ctx.measureText(t).width; }
  ctx.restore();
}
