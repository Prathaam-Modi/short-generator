// WHY IS IT CALLED BLUETOOTH?: the shot list (the only file that changes per video, with script.json).
// A shot: { id, at, cam: [cx, cy], zoom, note, draw(lt, d, t) }  · lt = time in shot, d = shot length, t = film time.
// It runs until the next shot's `at`; the last one ends at T.dur. Cut = L(i) - 0.08 (picture changes just before the line);
// cut inside a line with wcut('word', i). A whoosh cue is added for every cut automatically.
import { ctx, C, W, H, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, circle, line } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';

const mix = (a, b, t) => { const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(lerp(v, B[i], t)).toString(16).padStart(2, '0')).join(''); };
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));      // lip-flap while he speaks
const HOST = { x: 540, y: 738, s: 0.8 };                              // full-body framing: head ≈ 290, feet ≈ 1250

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => (S.push(o), cue(o.at, 'whoosh', { gain: 0.7 }), o);
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const wcut = (word, i) => Wd(word, i) - 0.08;

  // ── 1 · HOOK: arms crossed, question marks, a phone with radio waves ────
  {
    const st = cut(0), vik = Wd('viking', 0) - st;
    add({ id: 'S01', at: st, cam: [540, 760], note: 'host arms crossed, ? marks, phone waves, VIKING? sticker',
      draw(lt, d, t) {
        K.studio(); K.shadow(540, 1290, 430);
        K.host({ ...HOST, mouth: 'talk', talk: talk(lt), brow: 0.4 });
        K.phone(880, 760 + Math.sin(lt * 3) * 10, 0.7, 0.15, C.white, (w, h) => { ctx.fillStyle = C.orange; ctx.fillRect(-w / 2, -h / 2, w, 110); });
        K.waves(900, 560, 0.7, -1.2, t, seg(lt, 0.3, 0.6));
        K.mark('?', 170, 560 + Math.sin(lt * 3) * 12, eob(seg(lt, 0.15, 0.45)), -0.15);
        K.mark('?', 300, 380 + Math.sin(lt * 3 + 1) * 12, eob(seg(lt, 0.3, 0.6)) * 0.7, 0.2);
        if (lt > vik) K.sticker('A VIKING?', 540, 200, 92, C.orange, C.white, eob(seg(lt, vik, vik + 0.25)), -0.04);
      } });
    cue(st + 0.15, 'pop', { gain: 0.5 }); cue(st + vik, 'boing', { gain: 0.6 });
  }

  // ── 2 · a Danish king named Harald (958) ───────────────────────────────
  {
    const st = cut(1), yr = Wd('fifty', 1) - st, d1 = wcut('united', 1) - st;
    add({ id: 'S02', at: st, cam: [540, 700], note: 'host with a crown on a blue wall, 958 sticker on "fifty-eight"',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(540, 1290, 430);
        const hy = HOST.y + Math.sin(lt * 2.4) * 4;
        K.host({ ...HOST, y: hy, arm: K.armPose(K.ARM.cross, K.ARM.open, eio(seg(lt, 0.1, 0.5))), armL: K.armPose(K.ARM.crossBack, K.ARM.hip, eio(seg(lt, 0.1, 0.5))), mouth: 'talk', talk: talk(lt) });
        const cp = eob(seg(lt, 0.15, 0.5)); K.crown(540, hy - 440 * HOST.s - (1 - cp) * 300, 0.5 * cp, -0.05);
        if (lt > yr) K.sticker('958', 820, 380, 120, C.yellow, C.ink, eob(seg(lt, yr, yr + 0.25)), 0.06);
      } });
    cue(st + 0.35, 'thud', { gain: 0.5 }); cue(st + yr, 'pop');
  }

  // ── 3 · he united Denmark and Norway ───────────────────────────────────
  {
    const st = wcut('united', 1), jn = Wd('norway', 1) - st;
    add({ id: 'S03', at: st, cam: [540, 800], note: 'two paper countries slide together and join',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t);
        const p = eio(seg(lt, jn - 0.1, jn + 0.35)), gap = lerp(150, 0, p);
        ctx.save(); ctx.translate(540, 760);
        blob([[-140, -300 - gap], [0, -380 - gap], [150, -320 - gap], [170, -120 - gap], [90, 20], [-40, 30], [-120, -80 - gap]], C.jeansLight, { seed: 300 });
        blob([[-100, 40 + gap], [20, 20 + gap], [110, 60 + gap], [100, 160 + gap], [0, 200 + gap], [-100, 150 + gap]], C.orange, { seed: 301 });
        ctx.restore();
        K.sticker('NORWAY', 540, 470 - gap, 54, C.white, C.ink, eob(seg(lt, 0.1, 0.35)));
        K.sticker('DENMARK', 540, 960 + gap, 54, C.white, C.ink, eob(seg(lt, 0.25, 0.5)));
        K.arrow(300, 640 - gap * 0.5, 160, Math.PI / 2, 1 - p, C.white); K.arrow(780, 880 + gap * 0.5, 160, -Math.PI / 2, 1 - p, C.white);
        K.check(540, 720, 0.55 * eob(seg(lt, jn + 0.3, jn + 0.55)), 1);
      } });
    cue(st + jn + 0.15, 'thud', { gain: 0.6 }); cue(st + jn + 0.4, 'sparkle', { dur: 0.5, gain: 0.5 });
  }

  // ── 4 · his nickname was Bluetooth ─────────────────────────────────────
  {
    const st = cut(2), bt = Wd('bluetooth', 2) - st;
    add({ id: 'S04', at: st, cam: [540, 640], zoom: 0.14, note: 'close-up smiling, BLUETOOTH sticker lands',
      draw(lt, d, t) {
        K.studio(); K.shadow(540, 1900, 0);
        K.host({ x: 540, y: 1330, s: 1.7, arm: K.ARM.hip, armL: K.ARM.hip, mouth: lt > bt ? 'grin' : 'talk', talk: talk(lt), eyes: lt > bt ? 'happy' : 'n' });
        K.sticker('HIS NICKNAME', 540, 150, 58, C.white, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > bt) K.sticker('BLUETOOTH', 540, 270, 84, C.orange, C.white, eob(seg(lt, bt, bt + 0.25)), 0.03);
      } });
    cue(st + 0.1, 'pop', { gain: 0.5 }); cue(st + bt, 'slam', { gain: 0.6 });
  }

  // ── 5 · a dead tooth that turned dark blue ─────────────────────────────
  {
    const st = wcut('dead', 2), bl = Wd('blue', 2) - st;
    add({ id: 'S05', at: st, cam: [540, 800], zoom: 0.12, note: 'big tooth fades white to blue, DEAD TOOTH sticker',
      draw(lt, d, t) {
        K.grid(t);
        const k = seg(lt, bl - 0.2, bl + 0.5);
        K.tooth(540, 820 + Math.sin(lt * 2.5) * 10, 3.4 * eob(seg(lt, 0, 0.35)), mix(C.white, C.blue, eio(k)), Math.sin(lt * 2) * 0.05);
        K.sticker('A DEAD TOOTH', 540, 330, 84, C.white, C.ink, eob(seg(lt, 0.2, 0.5)), -0.04);
        if (k > 0.5) K.burst(740, 600, 0.9 * eo(seg(lt, bl + 0.2, bl + 0.45)), 1 - seg(lt, bl + 0.5, bl + 0.9), C.yellow, lt);
      } });
    cue(st + 0.05, 'pop'); cue(st + bl + 0.2, 'sparkle', { dur: 0.6, gain: 0.5 });
  }

  // ── 6 · 1996: Intel, Ericsson, Nokia ───────────────────────────────────
  {
    // entrances land on their words but never later than 0.6 / 1.4 / 2.2 s into the shot (keeps the screen busy if timing is loose)
    const st = cut(3), a = Math.min(Wd('intel', 3) - st, 0.6), b = Math.min(Wd('ericsson', 3) - st, 1.4), c = Math.min(Wd('nokia', 3) - st, 2.2);
    add({ id: 'S06', at: st, cam: [540, 800], note: 'three companies drop in as stickers with their gadgets',
      draw(lt, d, t) {
        K.grid(t);
        const drop = (t0) => eob(seg(lt, t0, t0 + 0.3));
        K.sticker('1996', 540, 280, 110, C.yellow, C.ink, eob(seg(lt, 0, 0.3)), -0.03);
        K.chip(250, 800 + (1 - drop(a)) * -500, 0.85 * drop(a) + 0.001);        K.sticker('INTEL', 250, 1000, 58, C.white, C.ink, drop(a));
        K.phone(540, 800 + (1 - drop(b)) * -500, 0.62 * drop(b) + 0.001, 0.06); K.sticker('ERICSSON', 540, 1060, 58, C.white, C.ink, drop(b));
        K.brickPhone(830, 800 + (1 - drop(c)) * -500, 0.7 * drop(c) + 0.001);   K.sticker('NOKIA', 830, 1030, 58, C.white, C.ink, drop(c));
      } });
    cue(st, 'pop', { gain: 0.4 }); cue(st + a + 0.15, 'thud', { gain: 0.5 }); cue(st + b + 0.15, 'thud', { gain: 0.5 }); cue(st + c + 0.15, 'thud', { gain: 0.5 });
  }

  // ── 7 · ...wanted to talk by short-range radio ─────────────────────────
  {
    const st = wcut('short', 3), rd = Wd('radio', 3) - st;
    add({ id: 'S07', at: st, cam: [540, 780], note: 'gadgets slide together, radio waves between them',
      draw(lt, d, t) {
        K.grid(t);
        const p = eio(seg(lt, 0, 0.7));
        K.chip(lerp(250, 330, p), 800, 0.85); K.phone(540, 800, 0.62, 0.06); K.brickPhone(lerp(830, 750, p), 800, 0.7);
        K.waves(lerp(250, 330, p) + 130, 800, 0.8, 0, t, p); K.waves(lerp(830, 750, p) - 120, 800, 0.8, Math.PI, t, p);
        if (lt > rd - 0.1) K.sticker('SHORT-RANGE RADIO', 540, 1060, 70, C.orange, C.white, eob(seg(lt, rd - 0.1, rd + 0.15)), 0.02);
      } });
    cue(st + 0.1, 'slide', { dur: 0.6, gain: 0.5 }); cue(st + rd, 'pop');
  }

  // ── 8 · an Intel engineer suggested the name ───────────────────────────
  {
    const st = cut(4), nm = Wd('name', 4) - st;
    add({ id: 'S08', at: st, cam: [540, 700], note: 'host points up, light bulb pops, NAME IDEA',
      draw(lt, d, t) {
        K.studio(); K.shadow(540, 1290, 430);
        K.host({ ...HOST, arm: K.armPose(K.ARM.down, K.ARM.point, eio(seg(lt, 0, 0.4))), armL: K.ARM.hip, finger: Math.sin(lt * 10) * 0.12, mouth: 'talk', talk: talk(lt), brow: 0.5, eyes: 'wide' });
        K.bulb(790, 330 + Math.sin(lt * 4) * 8, 0.8 * eob(seg(lt, 0.3, 0.6)), 1);
        if (lt > nm) K.sticker('NAME IDEA', 380, 250, 78, C.yellow, C.ink, eob(seg(lt, nm, nm + 0.25)), -0.05);
      } });
    cue(st + 0.35, 'pop'); cue(st + nm, 'boing', { gain: 0.5 });
  }

  // ── 9 · because Harald united Scandinavia ──────────────────────────────
  {
    const st = wcut('harald', 4), un = Wd('united', 4) - st;
    add({ id: 'S09', at: st, cam: [540, 760], note: 'crown over the joined map, SCANDINAVIA sticker',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t);
        ctx.save(); ctx.translate(540, 820);
        blob([[-140, -300], [0, -380], [150, -320], [170, -120], [90, 20], [-40, 30], [-120, -80]], C.jeansLight, { seed: 300 });
        blob([[-100, 40], [20, 20], [110, 60], [100, 160], [0, 200], [-100, 150]], C.orange, { seed: 301 });
        ctx.restore();
        const cp = eob(seg(lt, 0.05, 0.4)); K.crown(540, 420 - (1 - cp) * 300 + Math.sin(lt * 3) * 6, 0.9 * cp + 0.001, 0.04);
        if (lt > un) K.sticker('SCANDINAVIA', 540, 1130, 72, C.white, C.ink, eob(seg(lt, un, un + 0.25)), -0.03);
      } });
    cue(st + 0.1, 'thud', { gain: 0.5 }); cue(st + un, 'pop');
  }

  // ── 10 · ...and they wanted to unite phones and PCs ────────────────────
  {
    const st = wcut('they', 4), ph = Math.min(Wd('phones', 4) - st, 0.5), pc = Math.min(Wd('pcs', 4) - st, 1.3);
    add({ id: 'S10', at: st, cam: [540, 800], note: 'phone and laptop pulled together, check mark',
      draw(lt, d, t) {
        K.grid(t);
        const p = eio(seg(lt, pc - 0.1, pc + 0.5)), gap = lerp(190, 40, p);
        K.phone(540 - gap - 60, 800, 0.75 * eob(seg(lt, ph - 0.2, ph + 0.15)) + 0.001, -0.08);
        K.laptop(540 + gap + 80, 830, 0.8 * eob(seg(lt, pc - 0.2, pc + 0.15)) + 0.001, C.white, (w2, h2) => { ctx.fillStyle = C.jeansLight; ctx.fillRect(-w2 / 2, -h2 / 2, w2, h2); });
        K.arrow(540, 1060, 200 * (1 - p) + 0.001, 0, 1 - p); K.arrow(540, 1060, 200 * (1 - p) + 0.001, Math.PI, 1 - p);
        K.sticker('PHONES + PCS', 540, 330, 84, C.white, C.ink, eob(seg(lt, 0.1, 0.4)), 0.02);
        K.check(540, 1010, 0.6 * eob(seg(lt, pc + 0.4, pc + 0.65)), 1);
      } });
    cue(st + ph, 'pop', { gain: 0.5 }); cue(st + pc, 'pop', { gain: 0.5 }); cue(st + pc + 0.45, 'sparkle', { dur: 0.5, gain: 0.5 });
  }

  // ── 11 · only a placeholder, but it stuck ──────────────────────────────
  {
    const st = cut(5), stk = Math.min(Wd('stuck', 5) - st, 1.3);
    add({ id: 'S11', at: st, cam: [540, 760], note: 'sticky note PLACEHOLDER slaps onto a big phone on "stuck"',
      draw(lt, d, t) {
        K.studio(); K.shadow(540, 1290, 330);
        const shake = lt > stk ? Math.sin(lt * 60) * 6 * Math.max(0, 1 - (lt - stk) * 3) : 0;
        K.phone(540 + shake, 740, 1.55, 0, C.white, (w2, h2) => { ctx.fillStyle = C.orange; ctx.fillRect(-w2 / 2, -h2 / 2, w2, 130); });
        const fall = eo(seg(lt, stk - 0.25, stk));
        const nx = lerp(780, 560, fall), ny = lerp(240, 760, fall), nr = lerp(0.6, -0.08, fall);
        K.note('PLACEHOLDER', nx, ny, 1.25 * (lt > 0.1 ? 1 : eob(seg(lt, 0, 0.1))), nr, 46);
        if (lt > stk) K.burst(560, 760, 1.4 * eo(seg(lt, stk, stk + 0.2)), 1 - seg(lt, stk + 0.2, stk + 0.5));
      } });
    cue(st + 0.2, 'pop', { gain: 0.5 }); cue(st + stk, 'slam');
  }

  // ── 12 · and the logo? ─────────────────────────────────────────────────
  {
    const st = cut(6), lg = Wd('logo', 6) - st;
    add({ id: 'S12', at: st, cam: [540, 700], note: 'host shrugs, ? marks',
      draw(lt, d, t) {
        K.studio(); K.shadow(540, 1290, 430);
        const p = eio(seg(lt, 0, 0.4));
        K.host({ ...HOST, arm: K.armPose(K.ARM.down, K.ARM.shrug, p), armL: K.armPose(K.ARM.down, K.ARM.shrug, p), mouth: 'talk', talk: talk(lt), brow: 0.8 });
        K.mark('?', 200, 520 + Math.sin(lt * 3) * 12, eob(seg(lt, lg - 0.1, lg + 0.2)), -0.15);
        K.mark('?', 880, 440 + Math.sin(lt * 3 + 1) * 12, eob(seg(lt, lg, lg + 0.3)), 0.2);
        K.sticker('THE LOGO?', 540, 200, 96, C.yellow, C.ink, eob(seg(lt, lg - 0.05, lg + 0.25)), -0.03);
      } });
    cue(st + lg, 'pop');
  }

  // ── 13 · it merges the runes for his initials, H and B ─────────────────
  {
    const st = wcut('merges', 6), ru = Wd('runes', 6) - st, ini = Wd('initials', 6) - st;
    add({ id: 'S13', at: st, cam: [540, 800], note: 'two stone tablets with runes slide together, H and B stickers',
      draw(lt, d, t) {
        K.wall(C.hair, C.hairDark, t);
        const p = eio(seg(lt, ini - 0.2, ini + 0.5)), gx = lerp(190, 80, p);
        const tab = (x, kind, s0) => K.stone(x, 780, 1.5 * eob(seg(lt, s0, s0 + 0.3)) + 0.001, 0, () => K.rune(kind, 0, 0, 1.2, C.ink));
        tab(540 - gx, 'hagall', 0); tab(540 + gx, 'bjarkan', 0.15);
        if (lt > ru) { K.sticker('H', 540 - gx, 1110, 80, C.white, C.ink, eob(seg(lt, ru, ru + 0.2))); K.sticker('B', 540 + gx, 1110, 80, C.white, C.ink, eob(seg(lt, ru + 0.1, ru + 0.3))); }
        if (lt > ini) K.sticker('HIS INITIALS', 540, 330, 84, C.orange, C.white, eob(seg(lt, ini, ini + 0.25)), -0.03);
      } });
    cue(st + 0.1, 'thud', { gain: 0.5 }); cue(st + 0.25, 'thud', { gain: 0.5 }); cue(st + ini, 'pop');
  }

  // ── 14 · every time you pair your earbuds ──────────────────────────────
  {
    const st = cut(7), pr = Wd('pair', 7) - st;
    add({ id: 'S14', at: st, cam: [540, 700], note: 'host holds up a phone, waves, check on "pair"',
      draw(lt, d, t) {
        K.studio(); K.shadow(540, 1290, 430);
        const p = eio(seg(lt, 0, 0.35));
        K.host({ ...HOST, arm: K.armPose(K.ARM.down, K.ARM.hold, p), armL: K.ARM.hip, mouth: 'talk', talk: talk(lt), eyes: lt > pr ? 'happy' : 'n',
          holding: (x, y) => K.phone(x + 60, y - 50, 0.38, 0.12, C.white, (w2, h2) => { ctx.fillStyle = C.orange; ctx.fillRect(-w2 / 2, -h2 / 2, w2, 90); }) });
        K.waves(HOST.x + 330, 470, 0.7, -0.8, t, seg(lt, 0.3, 0.6));
        if (lt > pr) K.check(260, 450, 0.55 * eob(seg(lt, pr, pr + 0.25)), 1);
      } });
    cue(st + 0.3, 'pop', { gain: 0.5 }); cue(st + pr, 'sparkle', { dur: 0.5, gain: 0.6 });
  }

  // ── 15 · you're using a Viking's nickname (loops to the hook) ──────────
  {
    const st = wcut('using', 7), vk = Wd('viking', 7) - st;
    add({ id: 'S15', at: st, cam: [540, 640], zoom: 0.12, note: 'close-up smirk, crown drops on his head on "Viking\'s"',
      draw(lt, d, t) {
        K.studio();
        K.host({ x: 540, y: 1330, s: 1.7, arm: K.ARM.cross, mouth: 'smirk', eyes: lt > vk ? 'happy' : 'n', brow: 0.3 });
        const cp = eo(seg(lt, vk - 0.1, vk + 0.15)); if (cp > 0) K.crown(540, 1330 - 440 * 1.7 - (1 - cp) * 400 + 40, 0.95 * cp, -0.05);
        if (lt > vk + 0.1) K.sticker('BLUE-TOOTH', 540, 120, 80, C.orange, C.white, eob(seg(lt, vk + 0.1, vk + 0.35)), 0.03);
      } });
    cue(st + vk, 'thud', { gain: 0.6 }); cue(st + vk + 0.1, 'pop', { gain: 0.5 });
  }

  return { shots: S, cues: CUES };
}
