# Toon Host: flat cartoon explainers with a recurring host, 9:16

Friendly, witty, quick. A scruffy bearded host (black sweater, light jeans, orange sneakers) reacts, points and explains
over simple props, paper maps and comic stickers. Everything is a flat fill with a thick, slightly wobbly ink outline,
like a hand-drawn cartoon. Best for tech, company and "why is it called X?" explainers.
Example to study and copy: `example/` = **WHY IS IT CALLED BLUETOOTH?** (43 s, 15 shots). Style sheet: `style-sheet.png`.

## 1. The look (rules from the sheet: do not break them)
- **Ink outline on everything.** Every shape = flat fill + `INK` (8 px) dark outline, drawn with `blob / wEll / wRect / poly /
  inkLine` from `lib.js`. Their points are nudged a few px (seeded: stable between frames), which is the hand-drawn wobble.
  Never draw a bare, unoutlined shape except tiny details (highlights, hair strands, fold lines).
- **Flat only.** No gradients, blur or glow. Depth = one darker shade + one lighter highlight of the same colour.
- **Palette:** ink `#1B1A1A` · studio grey `#CDC8C3` · skin `#F2B891` · hair `#A85B2C` · sweater `#232323` · jeans `#A8C8E4` ·
  **orange `#F57C28` (THE accent)** · yellow `#FFD23F` · red `#D8392B` · green `#5DB36F` · blue `#4A7FB5`. Derived shades live in `lib.js` `C`.
- **Orange** = the caption keyword, the key prop, headline stickers. **Yellow** = bursts, coins, sticky notes, "date" stickers.
  **Red** = wrong / danger (redX). **Green** = right / done (check). Don't add other bright colours.
- **The host is the constant.** He appears in about half the shots; the other shots are prop / map / diagram cutaways (graph
  paper, coloured wall) in the same inked look. He keeps his outfit and proportions in every shot.
- No logos or brand marks: use plain sticker text ("NOKIA") and generic props (`phone`, `brickPhone`, `chip`, `laptop`).
- No violence or gore. Keep real people as the generic host plus crown / props, never a likeness.

## 2. Format
- **1080x1920, 30 fps, 25-45 s.** Lead silence 0.4 s, outro 0.9 s (in `script.json`).
- **Story shape:** hook question (host, arms crossed, `?` marks) → the origin / setup → the twist or surprise → the explanation
  in 2-3 prop shots → the payoff line, host to camera (loops to the hook).
- **One line = 1-2 shots**, 1.5-3.5 s each. A cut inside a line: `wcut('word', i)`. Every cut gets a punch-in, a brief white flash
  and a whoosh (flash + punch automatic in `main.js`, the whoosh is added by `add()` in `shots.js`).
- **Framing:** full-body host `HOST = { x: 540, y: 738, s: 0.8 }` (head ≈ y 290, feet ≈ 1250, floor line at 1290). Close-up:
  `s: 1.7, y: 1290` (face centred ≈ y 710). Keep hero and key props between y 250 and 1250; captions own y 1250-1550.
- **Narration:** conversational, flowing sentences with connecting words, never a list of caption-like fragments. Kokoro
  `am_michael` x1.0 (or `am_puck` for more playful). Numbers spelled as said. ~100-105 words for 40 s.

## 3. Captions
`script.json` line: `{ "text": "Why is your wireless tech named after a Viking king?", "caps": "WHY *WIRELESS | NAMED AFTER | A *VIKING KING?" }`
- `|` splits the line into chunks; `*` marks the ONE **orange** word of each chunk. 1-3 words per chunk.
- A chunk appears when its first word is spoken (matched by spelling, else by word count). Inter Black 150 px, white,
  ink outline 30 px, centred at y 1400 (`CAP` in captions.js). Caps may differ from the spoken words ("958" for "nine
  fifty-eight") but should start with the same word as the spoken chunk.

## 4. Engine map (`example/`)
| file | gives you |
|---|---|
| `script.json` | title, voice, speed, lead, outro, gap, music (`bed`·`none`·`audio/x.mp3`), sources, lines `{text, caps, gap}` |
| `src/shots.js` | **the per-video file**: the shot list + sound cues |
| `src/core/kit.js` | the component zoo (below) |
| `src/core/lib.js` | `W H FPS`, palette `C`, `INK`, math `clamp lerp seg eo eio eob rnd`, drawing `rr circle ell line fillAll bigText`, inked shapes `blob poly wEll wRect inkLine smooth` |
| `src/core/timing.js` | `L(i)` line start, `Le(i)` line end, `Wd(word, line)` word start (prefix match, throws if missing), `T.dur` |
| `src/core/captions.js` | caption chunking + drawing (`CAP` = position/size) |
| `src/sheet.js` | draws the style sheet: `QS='&sheet=1' node tools/capture.mjs frames review/sheet "0"` |
| `src/main.js` | boot, camera (punch-in + slow push), cut flash, fades, `window.OP` for capture |
| `tools/capture.mjs` | `check` · `cues` · `sheet` · `frames` · `video [start end] [--draft]` · `preview` |
| `tools/mix.py` | voice + music bed (ducked) + procedural effects → `data/mix.wav` |

## 5. The component zoo (`kit.js`, `import * as K`)
**Host** `K.host({ x, y, s, rot, flip, arm, armL, finger, eyes, mouth, talk, brow, frown, look, lookY, sweat, holding, holdingL })`
- origin = chest centre; at `s: 1` he is ~1125 px tall (hair top ≈ -562, feet ≈ +640).
- `arm` = RIGHT arm pose, `armL` = left. Default: crossed arms (`K.ARM.cross` + `K.ARM.crossBack`); any other `arm` leaves the left
  arm down unless you pass `armL`. Poses: `K.ARM.down | cross | crossBack | point | wave | hip | shrug | chin | hold | open`.
  Blend with `K.armPose(a, b, t)`. `finger`: extra wobble (rad) for the raised finger of `point`.
- `eyes`: `'n' | 'wide' | 'happy' | 'closed' | 'squint'` · `mouth`: `'smile' | 'grin' | 'o' | 'flat' | 'smirk' | 'talk' | 'sad'`
  (`talk` 0..1 = how open: animate with `Math.abs(Math.sin(lt * 13))`) · `brow` 0..1 raise · `frown` 0..1 · `look` / `lookY` -1..1 · `sweat: true`.
- `holding: (x, y) => K.phone(x + 60, y - 50, 0.38)` draws a prop AT THE HAND (it follows the arm).
- `K.head(o)` draws the head alone (origin = head centre + 340 px down; see `sheet.js`).
**Props** `K.phone(x, y, s, rot, screen, inner)` · `K.brickPhone` · `K.chip(x, y, s, core)` · `K.laptop` · `K.bars(x, y, w, h, values, p, hi)`
· `K.coin` · `K.bulb(x, y, s, on)` · `K.clock` · `K.crown` · `K.tooth(x, y, s, colour)` · `K.waves(x, y, s, ang, t, alpha)` (radio) ·
`K.note(text, x, y, s, rot)` (sticky) · `K.stone(x, y, s, rot, inner)` + `K.rune('hagall' | 'bjarkan' | 'fehu', ...)`.
**Graphics** `K.sticker(text, x, y, size, bg, fg, sc, rot)` (the label workhorse; `sc` animates the pop) · `K.tag(...)` (sticker with pointer) ·
`K.bubble(text, x, y, w, h, tx, ty, size, sc)` (`*word` = orange) · `K.redX` · `K.check` · `K.arrow(x, y, len, ang, a, colour)` · `K.burst` ·
`K.mark('?' | '!', ...)` · `K.speedLines` · `K.shockLines` · `K.sweat` · `bigText` ("BOOM!").
`K.flame(x, y, s, t)` (flickering fire, origin bottom centre) · `K.platform(x, y, w)` (plank, y = top surface) · `K.gear(x, y, s, rot)` (cog).
**Backgrounds** `K.studio(floorY)` (default plain grey, the host's home) · `K.wall(colour, accent, t)` (coloured place) · `K.grid(t)`
(graph paper for diagrams) · `K.dark(t)` (serious / glitchy) · `K.shadow(x, y, w)` flat ground shadow under the host.
Maps: draw paper blobs with `blob(points, fill)` in `shots.js` (see S03 / S09 of the example).
New topic = new components: add them to `kit.js` in the same look (flat fill, ink outline, one shade), document them here, check them full size.

## 6. A shot
```js
const st = wcut('stuck', 5), stk = Math.min(Wd('stuck', 5) - st, 1.3);   // cut mid-line; the slap lands on "stuck" (capped if timing is loose)
add({ id: 'S11', at: st, cam: [540, 760], zoom: 0.06, note: 'sticky note slaps onto a big phone',
  draw(lt, d, t) {                                  // pure function of time: no state between frames
    K.studio(); K.shadow(540, 1290, 330);
    K.phone(540, 740, 1.55);
    const fall = eo(seg(lt, stk - 0.25, stk));
    K.note('PLACEHOLDER', lerp(780, 560, fall), lerp(240, 760, fall), 1.25, lerp(0.6, -0.08, fall), 46);
    if (lt > stk) K.burst(560, 760, 1.4 * eo(seg(lt, stk, stk + 0.2)), 1 - seg(lt, stk + 0.2, stk + 0.5));
  } });
cue(st + stk, 'slam');
```
`cam` = the point the camera pushes toward; `zoom` = how much it pushes over the shot (0.06 default, 0.12-0.3 for close-ups).
**Sound cues** `cue(t, type, { gain, dur })`: `whoosh` (every cut, automatic) · `pop` (a sticker appears) · `boing` (comic beat) ·
`thud` (something lands) · `slam` (big impact) · `slide` (dur, travelling) · `sparkle` (dur, magic / success) · `tock` · `zip` · `alarm` (dur) · `plop` · `bubbles`.

## 7. QA pitfalls we've hit (check these first)
- **Empty screen waiting for a word.** If a prop enters on a word that is late, the picture sits empty. With loose word timing
  (no Whisper) cap entrances: `Math.min(Wd('word', i) - st, 1.4)`.
- **Anything starting off-screen** (a note flying in from the corner gets cut off): start entrances inside x 100-980.
- **Stickers hidden by the caption:** keep them above y 1250 (or use the top area y 150-400).
- **Arms:** only `cross` has the back arm raised across the chest. For any other pose pass `armL` (or leave it down); raised arms
  on both sides read as "hands up".
- **Brand logos:** never recreate a real logo (the Bluetooth symbol, Nokia wordmark art). Use plain sticker text or runes.
- **One orange accent:** if three things on screen are orange, the keyword stops being special. Make secondary stickers white or yellow.
- **Timing without Whisper:** `words.py` falls back to spreading words inside each line's exact voice time, so word-level
  entrances can drift by up to ~1 s on long lines. Fine for drafts; re-run `words.py` where Whisper can load for the final.

## 9. Cassette variant (music-production Reels for @cassettebydimo)
Same Toon Host rules, but the host stands behind DJ decks and the cutaways use music props from `src/core/music.js`:
`M.deck(x,y,s,t)` turntable (platter spins with t), `M.mixer(x,y,s,fade)`, `M.headphones`, `M.speaker(x,y,s,beat)`, `M.cassette(x,y,s,t,rot,label)`,
`M.keys(x,y,s,lit)`, `M.pads(x,y,s,[lit])`, `M.waveform(x,y,w,h,values,hi)`, `M.knob(x,y,s,ang,color)`, `M.noteIcon`.
Import with `import * as M from './core/music.js'`. Topics: DJ facts, production tips and tricks, music history. Voice and captions as above.
Set `"badge": ""` in script.json for no corner badge, or other initials. Style sheet: `style-sheet-cassette.jpg`.
