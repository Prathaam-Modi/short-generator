// WHY YOUR PHONE BATTERY DIES FASTER EVERY YEAR  (long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as M from './core/moon.js';
import * as Z from './core/sea.js';
import * as B from './core/batt.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
const big = (txt, x, y, size, color = C.orange) => R.txt(txt, x, y, size, color, 'center', 2);
const pill = (s, y, lt, a = 0.3, size = 52, hi = true, x = 960) => R.pill(s, x, y, size, pop(lt, a), hi ? { hi: true } : {});
const pillAt = (s, x, y, lt, a = 0.3, size = 44, hi = false) => R.pill(s, x, y, size, pop(lt, a), hi ? { hi: true } : {});
const batt = (x, y, s, lvl, o = {}) => B.battery(x, y, s, lvl, o);
// phone with a battery percentage on its screen
const phoneP = (x, y, s, pct, rot = 0, col) => K.phone(x, y, s, rot, C.white, () => { B.battery(0, -50, 0.38, pct / 100, col ? { color: col } : {}); R.txt(pct + '%', 0, 50, 58, C.ink, 'center', 1); });
const CELL = (t, o = {}, y = 560, s = 0.95) => B.cell(960, y, s, t, o);
const ZOOM = (t, o = {}, y = 540, s = 1) => B.zoom(960, y, s, t, o);
// bar chart of N bars (values in px heights at full growth)
function chart(items, lt, base = 800, w = 200) {
  R.paper(); line([[260, base], [1660, base]], C.ink, 8);
  const gap = 1400 / items.length;
  items.forEach((it, i) => {
    const p = eo(seg(lt, it.at ?? 0.2, (it.at ?? 0.2) + 0.9)); if (p <= 0) return;
    const x = 260 + gap * (i + 0.5);
    R.bar(x, base, w, it.h, it.hi ? C.orange : C.grayLight, p, 10 + i);
    R.txt(it.lab, x, base + 52, 40, C.ink, 'center', 1);
    if (it.pill) R.pill(it.pill, x, base - it.h * p - 56, 40, pop(lt, (it.at ?? 0.2) + 0.7), it.hi ? { hi: true } : {});
  });
}

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;
  const cam = [960, 520];
  const sh = (id, at, note, draw, o = {}) => add({ id, at, cam: o.cam || cam, zoom: o.zoom ?? 0.04, note, chap: o.chap, draw });
  const hostShot = (id, at, note, label, o = {}) => sh(id, at, note, (lt, d, t) => { R.studio(880); host(o.x ?? 1330, lt, o.pose || { arm: K.ARM.open, armL: K.ARM.hip }); if (o.q) K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill(label, o.px ?? 700, 450, o.size ?? 52, pop(lt, 0.3), o.hi === false ? {} : { hi: true }); }, { cam: [(o.x ?? 1330) > 1000 ? 1200 : 700, 540], zoom: 0.05, chap: o.chap });
  const shrug = { arm: K.ARM.shrug, armL: K.ARM.shrug };
  const P = (...a) => sh(...a);

  // ═════════ HOOK ═════════
  sh('S01', A(0), 'phone 100 two years ago', (lt) => { R.paper(); phoneP(960, 470, 1.35, 100); pill('2 YEARS AGO: ALL DAY', 880, lt, 0.4, 52); });
  sh('S01b', Wc('today', 0), 'today 40 percent', (lt) => { R.paper(); phoneP(960, 470, 1.35, 40, 0, C.red); pill('TODAY: 40% BY LUNCH', 880, lt, 0.4, 52); });
  sh('S01d', Wc('nothing', 0), 'what got used up', (lt) => { R.paper(); big('?', 960, 430, 560, C.orange); pill('WHAT GOT USED UP?', 860, lt, 0.3, 56, false); });

  hostShot('S02', A(1), 'host: what you get', 'WHAT YOU WILL GET');
  sh('S02b', Wc('wear', 1), 'three things', (lt) => { R.paper(); big('3', 960, 430, 560); pill('THINGS THAT WEAR IT OUT', 860, lt, 0.3, 54, false); });
  sh('S02c', Wc('eighty', 1), 'eighty', (lt) => { R.paper(); big('80%', 960, 420, 380); pill('WHAT DOES IT MEAN?', 800, lt, 0.3, 54, false); });
  sh('S02d', Wc('tradeoff', 1), 'trade-off', (lt) => { R.paper(); const [a, b] = B.seesaw(960, 600, 1, Math.sin(lt * 2) * 0.12); pillAt('LIFE', a[0] + 20, a[1] - 90, lt, 0.2, 46); pillAt('RUNTIME', b[0] - 20, b[1] - 90, lt, 0.5, 46); pill('ONE TRADE-OFF', 230, lt, 0.2, 54); });

  hostShot('S03', A(2), 'host: a trick?', 'A TRICK TO SELL PHONES?', { pose: { ...shrug, brow: 0.6 }, q: 1, hi: false, size: 46 });
  sh('S03b', Wc('real', 2), 'real chemistry', (lt) => { R.paper(); K.check(960, 430, 1.1, pop(lt, 0.2)); pill('REAL CHEMISTRY', 790, lt, 0.5, 56); });
  sh('S03c', Wc('every', 2), 'pages I opened', (lt) => { R.paper(); M.pages(900, 480, 1.2); K.check(1380, 640, 0.6, pop(lt, 0.8)); pill('PAGES I ACTUALLY OPENED', 850, lt, 0.4, 48); });
  sh('S03d', Wc('like', 2), 'battery university and apple', (lt) => { R.paper(); K.laptop(960, 520, 1.5, C.white, () => { for (let i = 0; i < 5; i++) wRect(-150, -60 + i * 40, i % 2 ? 220 : 300, 14, 7, C.paperLine, { seed: i, lw: 3 }); }); pillAt('BATTERY UNIVERSITY', 700, 880, lt, 0.2, 40); pillAt('APPLE SUPPORT', 1330, 880, lt, 0.9, 40); });

  sh('S04', A(3), '500 vs 1000', (lt) => { chart([{ h: 220, lab: 'IPHONE 14 AND EARLIER', pill: '500 CYCLES' }, { h: 440, lab: 'IPHONE 15', pill: '1,000 CYCLES', hi: true, at: 1.4 }], lt, 800, 240); });
  hostShot('S04b', Wc('so', 3), 'host: cycle cost', 'WHAT DOES A CYCLE COST?', { x: 640, px: 1260, q: 1, hi: false, pose: shrug });

  // ═════════ 1 · WHAT IS INSIDE ═════════
  sh('S05', A(4), 'battery cutaway', (lt, d, t) => { R.paper(); CELL(t, {}); pill('TWO LAYERS', 850, lt, 0.3, 52, false); }, { chap: [1, 'WHAT IS INSIDE'] });
  sh('S05c', Wc('thin', 4), 'a thin sheet', (lt, d, t) => { R.paper(); CELL(t, { hi: 'sep' }); pill('A THIN SHEET BETWEEN', 850, lt, 0.2, 52, false); });
  sh('S05d', Wc('liquid', 4), 'a liquid', (lt, d, t) => { R.paper(); CELL(t, { hi: 'liq' }); pill('AND A LIQUID', 850, lt, 0.2, 52, false); });

  sh('S06', A(5), 'graphite', (lt, d, t) => { R.paper(); CELL(t, { hi: 'anode' }); pill('GRAPHITE: PENCIL LEAD', 850, lt, 0.3, 52, false); });
  sh('S06b', Wc('other', 5), 'metal oxide', (lt, d, t) => { R.paper(); CELL(t, { hi: 'cathode' }); pill('A METAL OXIDE', 850, lt, 0.2, 52, false); });

  sh('S07', A(6), 'lithium ions', (lt, d, t) => { R.paper(); CELL(t, { nc: 12 }); pill('LITHIUM IONS: THE PASSENGERS', 850, lt, 0.3, 50, false); });
  sh('S07b', Wc('charge', 6), 'charging flow', (lt, d, t) => { R.paper(); CELL(t, { nc: 6, flow: 6, dir: -1 }); pill('CHARGING: IONS MOVE TO THE GRAPHITE', 850, lt, 0.3, 46, false); });
  sh('S07c', Wc('parked', 6), 'parked', (lt, d, t) => { R.paper(); CELL(t, { na: 12 }); pill('PARKED BETWEEN THE LAYERS', 850, lt, 0.3, 50, false); });

  sh('S08', A(7), 'discharge flow', (lt, d, t) => { R.paper(); CELL(t, { na: 6, flow: 6, dir: 1 }); pill('USING THE PHONE: IONS RIDE BACK', 850, lt, 0.3, 46, false); });
  sh('S08b', Wc('electrons', 7), 'electrons outside', (lt, d, t) => { R.paper(); CELL(t, { na: 6, flow: 6, dir: 1, wire: 1, edir: 1 }, 640, 0.8); pill('ELECTRONS TAKE THE LONG WAY', 880, lt, 0.3, 46, false); });

  sh('S09', A(8), 'nothing burns', (lt, d, t) => { R.paper(); CELL(t, { na: 4, nc: 4, flow: 6, dir: -1 }); pill('NOTHING BURNS: JUST BACK AND FORTH', 850, lt, 0.3, 48, false); });
  sh('S09c', Wc('sony', 8), '1991', (lt) => { R.paper(); big('1991', 960, 430, 330); pill('SONY SELLS THE FIRST ONE', 700, lt, 0.4, 52, false); });
  sh('S09d', Wc('nobel', 8), '2019 nobel', (lt) => { R.paper(); big('2019', 960, 430, 330); pill('NOBEL PRIZE IN CHEMISTRY', 700, lt, 0.4, 52, false); });

  hostShot('S10', A(9), 'host: why does it wear out', 'WHY DOES IT WEAR OUT?', { pose: shrug, q: 1, hi: false });
  sh('S10c', Wc('practice', 9), 'three things', (lt) => { R.paper(); big('3', 960, 430, 520); pill('THINGS GET IN THE WAY', 850, lt, 0.3, 54, false); });

  // ═════════ 2 · THE PROMISE ═════════
  sh('S11', A(10), 'the promise', (lt) => { R.paper(); phoneP(960, 470, 1.3, 100); pill('THE PROMISE', 860, lt, 0.3, 56); }, { chap: [2, 'THE PROMISE'] });
  sh('S11b', Wc('eighty', 10), '80 percent kept', (lt) => { R.paper(); batt(960, 460, 2.0, 0.8, { text: '80%' }); pill('APPLE: 80% STILL THERE', 860, lt, 0.3, 52); });
  sh('S11c', Wc('five', 10), '500', (lt) => { R.paper(); big('500', 960, 420, 380); pill('CYCLES: IPHONE 14 AND EARLIER', 760, lt, 0.4, 48, false); });
  sh('S11d', Wc('fifteen', 10), '1000', (lt) => { R.paper(); big('1,000', 960, 420, 380); pill('CYCLES: IPHONE 15', 760, lt, 0.4, 52, false); });

  sh('S12', A(11), 'eighty not a hundred', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8, { text: '80%' }); K.mark('?', 1560, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.3) * 0.7, 0.1); pill('EIGHTY, NOT A HUNDRED', 860, lt, 0.3, 52, false); });
  sh('S12b', Wc('wikipedia', 11), 'worn out at 80', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8, { color: C.orange }); pill('USUALLY "WORN OUT" AT 80%', 860, lt, 0.3, 50); });

  sh('S13', A(12), 'a cycle isnt one plug-in', (lt) => { R.paper(); batt(960, 440, 2.0, 1 - 0.0); pill('A CYCLE IS NOT ONE PLUG-IN', 860, lt, 0.3, 52, false); });
  sh('S13b', Wc('counts', 12), '100 percent used', (lt) => { R.paper(); const p = eo(seg(lt, 0.3, 3.0)); batt(960, 440, 2.0, 1 - p); pill('ONE CYCLE = 100% USED', 860, lt, 0.3, 52); });
  sh('S13c', Wc('fifty', 12), '50 + 50', (lt) => { R.paper(); batt(620, 460, 1.1, 0.5); R.txt('+', 960, 470, 130, C.ink, 'center', 1); batt(1300, 460, 1.1, 0.5); pill('50% + 50% = ONE CYCLE', 860, lt, 0.3, 52); });

  hostShot('S14', A(13), 'host: takeaway', 'NEVER MEANT TO STAY AT 100%', { x: 640, px: 1260, size: 46, pose: { arm: K.ARM.point, mouth: 'grin' } });
  sh('S14b', Wc('eighty', 13), 'eighty is the plan', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8, { text: '80%' }); K.check(1560, 330, 0.5, pop(lt, 0.3)); pill('EIGHTY PERCENT IS THE PLAN', 860, lt, 0.3, 52); });

  // ═════════ 3 · THE CRUST ═════════
  sh('S15', A(14), 'graphite zoom', (lt, d, t) => { R.paper(); ZOOM(t, { flow: 7, crust: 0 }); pill('THE GRAPHITE SIDE, ZOOMED IN', 190, lt, 0.4, 48, false); }, { chap: [3, 'THE CRUST'] });
  sh('S15b', Wc('first', 14), 'first charge', (lt, d, t) => { R.paper(); ZOOM(t, { flow: 7, crust: 0 }); pill('THE VERY FIRST CHARGE', 190, lt, 0.2, 52); });
  sh('S15d', Wc('leftovers', 14), 'thin film', (lt, d, t) => { R.paper(); ZOOM(t, { flow: 8, crust: 0.2, hiCrust: 1 }); pill('A THIN SOLID FILM', 190, lt, 0.2, 54); });
  sh('S15e', Wc('called', 14), 'SEI', (lt, d, t) => { R.paper(); ZOOM(t, { flow: 8, crust: 0.2, hiCrust: 1 }); pill('THE "S E I" LAYER', 190, lt, 0.2, 56); });

  sh('S16', A(15), 'blocks electrons', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.25, elec: 1 }); pill('BLOCKS ELECTRONS', 190, lt, 0.3, 54); });
  sh('S16b', Wc('lets', 15), 'lets ions through', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.25, flow: 7 }); pill('LETS LITHIUM IONS THROUGH', 190, lt, 0.3, 52, false); });
  sh('S16c', Wc('so', 15), 'liquid stops', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.25, flow: 4 }); K.check(1460, 330, 0.4, pop(lt, 0.3)); pill('THE LIQUID STOPS BREAKING DOWN', 190, lt, 0.3, 48, false); });

  sh('S17', A(16), 'uses up lithium', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, flow: 6, stuck: Math.floor(eo(seg(lt, 0.5, 3)) * 5) }); pill('BUILDING IT USES UP LITHIUM', 190, lt, 0.3, 52, false); });
  sh('S17b', Wc('never', 16), 'never comes back', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, stuck: 5 }); K.redX(1180, 500, 0.4, pop(lt, 0.3)); pill('IT NEVER COMES BACK', 190, lt, 0.3, 54); });
  sh('S17c', Wc('locked', 16), 'locked in crust', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, stuck: 6, hiCrust: 1 }); pill('LOCKED IN THE CRUST', 190, lt, 0.3, 54, false); });

  hostShot('S18', A(17), 'host: twist', "HERE'S THE TWIST", { x: 640, px: 1260, pose: { arm: K.ARM.point, mouth: 'grin' } });
  sh('S18b', Wc('never', 17), 'crust keeps growing', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3 + 0.6 * eo(seg(lt, 0.2, 3.2)), flow: 4, stuck: 6 }); pill('THE CRUST NEVER STOPS GROWING', 190, lt, 0.3, 50); });
  sh('S18c', Wc('trapping', 17), 'more lithium trapped', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.9, flow: 6, stuck: 12 }); pill('MORE LITHIUM TRAPPED', 190, lt, 0.3, 54, false); });
  sh('S18d', Wc('battery', 17), 'capacity loss', (lt) => { R.paper(); batt(960, 440, 2.0, 1 - 0.25 * eo(seg(lt, 0.3, 2.5)), { text: '' }); pill('A MAJOR CAUSE OF CAPACITY LOSS', 860, lt, 0.3, 50); });

  sh('S19', A(18), 'limescale', (lt) => { R.paper(); B.kettle(960, 480, 1.7, eo(seg(lt, 0.3, 2.5))); pill('LIKE LIMESCALE IN A KETTLE', 860, lt, 0.3, 52); });
  sh('S20', A(19), 'locked away every day', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.7, stuck: 9, hiCrust: 1 }); pill('SOME LITHIUM LOCKED AWAY EVERY DAY', 190, lt, 0.3, 48, false); });
  sh('S20b', Wc('now', 19), 'now make it worse', (lt) => { R.paper(); B.thermo(960, 470, 1.4, 0.4 + 0.5 * eo(seg(lt, 0.2, 2)), C.red); pill("NOW LET'S MAKE IT WORSE", 860, lt, 0.3, 54, false); });

  // ═════════ 4 · HEAT PLUS FULL ═════════
  sh('S21', A(20), 'stored for a year', (lt) => { R.paper(); batt(640, 460, 1.3, 0.4, { color: C.green }); batt(1280, 460, 1.3, 1); pillAt('40% CHARGE', 640, 640, lt, 0.3, 42); pillAt('100% CHARGE', 1280, 640, lt, 0.5, 42); pill('STORED FOR A YEAR', 230, lt, 0.2, 52, false); }, { chap: [4, 'HEAT PLUS FULL'] });
  sh('S21b', Wc('degrees', 20), '25 C', (lt) => { R.paper(); B.thermo(960, 440, 1.4, 0.4, C.red); pill('IN A 25 °C ROOM', 860, lt, 0.3, 54, false); });
  sh('S21c', Wc('forty', 20), '40 percent charge', (lt) => { R.paper(); batt(960, 440, 2.0, 0.4, { text: '40%' }); pill('KEPT AT 40% CHARGE', 860, lt, 0.3, 54, false); });
  sh('S21d', Wc('ninetysix', 20), '96', (lt) => { R.paper(); big('96%', 960, 420, 400); pill('OF ITS CAPACITY LEFT', 760, lt, 0.4, 52, false); });

  sh('S22', A(21), 'kept at 100', (lt) => { R.paper(); batt(960, 440, 2.0, 1, { text: '100%' }); pill('KEPT AT 100% CHARGE', 860, lt, 0.3, 54, false); });
  sh('S22b', Wc('about', 21), '80', (lt) => { R.paper(); big('80%', 960, 420, 400); pill('OF ITS CAPACITY LEFT', 760, lt, 0.4, 52, false); });
  sh('S22c', Wc('fifth', 21), 'a fifth gone', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8 + 0.2 * (1 - eo(seg(lt, 0.2, 1.8))), { color: C.orange }); pill('A FIFTH GONE JUST FROM SITTING FULL', 860, lt, 0.3, 46, false); });

  hostShot('S23', A(22), 'host: add heat', 'NOW ADD HEAT: 40 °C', { pose: { arm: K.ARM.open, armL: K.ARM.hip } });
  sh('S23b', Wc('eightyfive', 22), '85', (lt) => { R.paper(); big('85%', 960, 400, 400); pill('40 °C, KEPT AT 40% CHARGE', 740, lt, 0.4, 48, false); });
  sh('S23c', Wc('full', 22), '65', (lt) => { R.paper(); big('65%', 960, 400, 400); pill('40 °C, KEPT FULL', 740, lt, 0.4, 52, false); });

  sh('S24', A(23), 'phone in sun', (lt) => { R.paper(); B.sun(560, 420, 1.0, lt); phoneP(1180, 500, 1.2, 100); K.sweat(1350, 330, 1, 1); pill('A PHONE LEFT IN DIRECT SUN', 880, lt, 0.3, 50, false); });
  sh('S24b', Wc('apple', 23), 'apple warns hot', (lt) => { R.paper(); K.laptop(960, 520, 1.5, C.white, () => { for (let i = 0; i < 5; i++) wRect(-150, -60 + i * 40, i % 2 ? 220 : 300, 14, 7, C.paperLine, { seed: i, lw: 3 }); }); pill('APPLE: AVOID HOT ENVIRONMENTS', 880, lt, 0.3, 48, false); });
  sh('S24c', Wc('full', 23), 'full and hot harder than cycling', (lt) => { R.paper(); batt(700, 450, 1.4, 1); B.thermo(1330, 450, 1.1, 0.9, C.red); pill('FULL + HOT: HARDER THAN CYCLING', 860, lt, 0.3, 46); });

  hostShot('S25', A(24), 'host: phones know', 'PHONES KNOW THIS', { x: 640, px: 1260, pose: { arm: K.ARM.point, mouth: 'grin' } });
  sh('S25b', Wc('pause', 24), 'pause at 80', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8, { text: '80%' }); wRect(1480, 360, 34, 110, 8, C.orange, { seed: 6 }); wRect(1540, 360, 34, 110, 8, C.orange, { seed: 7 }); pill('PAUSES AT 80%', 860, lt, 0.3, 56, false); });
  sh('S26', A(25), 'full and warm', (lt) => { R.paper(); batt(700, 450, 1.4, 1); B.thermo(1330, 450, 1.1, 0.7, C.red); pill('SITTING FULL, SITTING WARM', 860, lt, 0.3, 50); });

  // ═════════ 5 · THE TRAFFIC JAM ═════════
  sh('S27', A(26), 'speed limit', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, flow: 4, speed: 0.15 }); pill('THERE IS A SPEED LIMIT FOR IONS', 190, lt, 0.3, 50, false); }, { chap: [5, 'THE TRAFFIC JAM'] });
  sh('S28', A(27), 'charge too fast', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, flow: 12, speed: 0.6 }); pill('CHARGE TOO FAST', 190, lt, 0.3, 56); });
  sh('S28b', Wc('cold', 27), 'in the cold', (lt) => { R.paper(); B.thermo(960, 460, 1.4, 0.12, C.blue); pill('OR IN THE COLD', 860, lt, 0.3, 56, false); });
  sh('S28c', Wc('pile', 27), 'pile up as metal', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, flow: 8, speed: 0.4, spikes: 0.4 * eo(seg(lt, 0.2, 2)) }); pill('THEY PILE UP AS PLAIN METAL', 190, lt, 0.3, 50, false); });
  sh('S28d', Wc('called', 27), 'lithium plating', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, spikes: 0.6 }); pill('LITHIUM PLATING', 190, lt, 0.3, 58); });

  sh('S29', A(28), 'three promoters', (lt) => { R.paper(); B.thermo(430, 450, 1.0, 0.12, C.blue); Z.bolt(960, 440, 1.9); batt(1500, 450, 1.1, 1); pillAt('LOW TEMPERATURE', 430, 780, lt, 0.3, 36); pillAt('HIGH CURRENT', 960, 780, lt, 0.7, 36); pillAt('HIGH CHARGE', 1500, 780, lt, 1.1, 36); });
  sh('S29b', Wc('plated', 28), 'wasted metal', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, spikes: 0.6 }); pill('THE PLATED METAL GETS WASTED', 190, lt, 0.3, 50, false); });
  sh('S29c', Wc('worst', 28), 'spikes short the cell', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, spikes: 0.5 + 0.5 * eo(seg(lt, 0.2, 2.5)) }); pill('SPIKES CAN SHORT THE CELL', 190, lt, 0.3, 54); });

  sh('S30', A(29), 'five to forty-five C', (lt) => { R.paper(); B.thermo(960, 470, 1.4, 0.55, C.green); pill('CHARGE AT ABOUT 5 TO 45 °C', 860, lt, 0.3, 52, false); });
  sh('S30b', Wc('less', 29), 'less current in cold', (lt) => { R.paper(); Z.bolt(960, 440, 1.3); pill('LESS CURRENT WHEN IT IS COLD', 860, lt, 0.3, 50, false); });

  sh('S31', A(30), 'cold temporary', (lt) => { R.paper(); phoneP(960, 470, 1.35, 60); pill('COLD: A TEMPORARY EFFECT', 880, lt, 0.3, 52, false); });
  sh('S31b', Wc('shut', 30), 'shuts off', (lt) => { R.paper(); K.phone(960, 470, 1.35, 0, C.ink); pill('CAN SHUT OFF UNEXPECTEDLY', 880, lt, 0.3, 50, false); });
  sh('S31c', Wc('warm', 30), 'warm it up', (lt) => { R.paper(); phoneP(960, 470, 1.35, 60); K.check(1300, 360, 0.5, pop(lt, 0.3)); pill('WARM IT UP: IT GOES AWAY', 880, lt, 0.3, 50, false); });

  hostShot('S32', A(31), 'host: takeaway villains', 'DIFFERENT VILLAINS', { pose: { arm: K.ARM.open, armL: K.ARM.hip }, hi: false });
  sh('S32b', Wc('different', 31), 'same result', (lt) => { R.paper(); Z.bolt(520, 440, 1.5); batt(1380, 450, 1.2, 1); pillAt('FAST + COLD: THE GRAPHITE', 520, 780, lt, 0.3, 38); pillAt('WARM + FULL: THE WHOLE CELL', 1380, 780, lt, 0.8, 38); });

  // ═════════ 6 · THE TRADE-OFF ═════════
  sh('S33', A(32), 'full cell 4.2 V', (lt) => { R.paper(); batt(960, 440, 2.0, 1, { text: '4.2 V' }); pill('THE TRADE-OFF NOBODY MENTIONS', 860, lt, 0.3, 50, false); }, { chap: [6, 'THE TRADE-OFF'] });
  sh('S33b', Wc('tested', 32), 'stop a little lower', (lt) => { R.paper(); batt(960, 440, 2.0, 1 - 0.18 * eo(seg(lt, 0.3, 2)), { text: '' }); R.arrowV(1560, 300, 160, PI / 2, C.orange); pill('STOP A LITTLE LOWER', 860, lt, 0.3, 54, false); });

  sh('S34', A(33), 'bar 4.20 V', (lt) => chart([{ h: 150, lab: '4.20 V', pill: '300 TO 500 CYCLES', at: 0.2 }], lt, 800, 220));
  sh('S34b', Wc('eight', 33), 'bar 4.00 V', (lt) => chart([{ h: 150, lab: '4.20 V', pill: '300 TO 500', at: 0 }, { h: 420, lab: '4.00 V', pill: '850 TO 1,500', at: 0.2, hi: true }], lt, 800, 220));
  sh('S34c', Wc('twelve', 33), 'bar 3.92 V', (lt) => chart([{ h: 150, lab: '4.20 V', pill: '300 TO 500', at: 0 }, { h: 420, lab: '4.00 V', pill: '850 TO 1,500', at: 0 }, { h: 560, lab: '3.92 V', pill: '1,200 TO 2,000', at: 0.2, hi: true }], lt, 800, 200));

  hostShot('S35', A(34), 'host: a price', "BUT THERE'S A PRICE", { x: 640, px: 1260, pose: { arm: K.ARM.point, mouth: 'grin' } });
  sh('S35b', Wc('seventythree', 34), 'energy bars', (lt) => chart([{ h: 400, lab: '4.20 V', pill: '100%', at: 0 }, { h: 292, lab: '4.00 V', pill: '73% ENERGY', at: 0.2, hi: true }, { h: 260, lab: '3.92 V', pill: '65%', at: 2.4 }], lt, 800, 200));

  sh('S36', A(35), 'chalmers 3 years', (lt) => { R.paper(); B.cell(960, 520, 0.6, lt, {}); pill('CHALMERS UNIVERSITY: ABOUT 3 YEARS OF TESTS', 860, lt, 0.3, 40, false); });
  sh('S36b', Wc('electric', 35), 'electric car model', (lt) => { R.paper(); B.car(960, 470, 1.6); pill('A MODEL OF AN ELECTRIC CAR', 860, lt, 0.3, 52, false); });
  sh('S36c', Wc('fifty', 35), 'near 50 percent', (lt) => { R.paper(); batt(960, 440, 2.0, 0.5, { text: '50%' }); pill('KEPT NEAR 50% CHARGE', 860, lt, 0.3, 54, false); });
  sh('S36d', Wc('fortyfour', 35), '44-130', (lt) => { R.paper(); big('44 to 130%', 960, 420, 260); pill('LONGER LIFE (DRIVING WEAR ONLY)', 700, lt, 0.4, 48, false); });

  sh('S37', A(36), 'hold more', (lt) => { R.paper(); batt(960, 440, 2.0, 1, { text: '100%' }); pill('ASK IT TO HOLD MORE', 860, lt, 0.3, 54, false); });
  sh('S37b', Wc('faster', 36), 'ages faster', (lt) => { R.paper(); K.clock(960, 440, 1.6, lt * 6); pill('IT AGES FASTER', 860, lt, 0.3, 56); });
  sh('S37c', Wc('long', 36), 'opposite directions', (lt) => { R.paper(); const [a, b] = B.seesaw(960, 620, 1, Math.sin(lt * 2) * 0.12); pillAt('LONG LIFE', a[0] + 30, a[1] - 90, lt, 0.2, 42); pillAt('BIG NUMBER', b[0] - 30, b[1] - 90, lt, 0.5, 42); });

  sh('S38b', A(37), '80 to 100', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8, { text: '80%' }); pill('CHARGE LIMIT: 80% TO 100%', 860, lt, 0.3, 50, false); });
  sh('S38c', Wc('give', 37), 'less runtime longer life', (lt) => { R.paper(); const [a, b] = B.seesaw(960, 620, 1, 0.1); pillAt('A LITTLE RUNTIME', a[0] + 60, a[1] - 90, lt, 0.2, 40); pillAt('LONGER LIFE', b[0] - 30, b[1] - 90, lt, 0.5, 40, true); });
  hostShot('S39', A(38), 'host: choose', 'CHOOSE YOUR TRADE-OFF', { x: 640, px: 1260, pose: { arm: K.ARM.point, mouth: 'grin' } });

  // ═════════ 7 · MYTHS ═════════
  sh('S40', A(39), 'drain to zero?', (lt) => { R.paper(); batt(960, 440, 2.0, 0.03, { text: '0%' }); pill('DRAIN IT TO ZERO?', 860, lt, 0.3, 56, false); }, { chap: [7, 'MYTHS'] });
  sh('S40b', Wc('says', 39), 'no memory', (lt) => { R.paper(); batt(960, 440, 2.0, 0.7); K.check(1560, 330, 0.5, pop(lt, 0.3)); pill('LITHIUM-ION HAS NO MEMORY', 860, lt, 0.3, 50, false); });
  sh('S40c', Wc('shallower', 39), 'shallow cycles gentler', (lt) => { R.paper(); const p = Math.abs(Math.sin(lt * 1.2)); batt(960, 440, 2.0, 0.7 + 0.3 * p); pill('SHALLOWER CYCLES ARE GENTLER', 860, lt, 0.3, 50, false); });

  sh('S41', A(40), 'drain all the way 300', (lt) => { R.paper(); big('~300', 960, 420, 380); pill('DRAINED ALL THE WAY: CYCLES', 760, lt, 0.4, 50, false); });
  sh('S41b', Wc('only', 40), 'drain 40 percent 1000', (lt) => { R.paper(); big('~1,000', 960, 420, 380); pill('DRAIN ONLY 40% EACH TIME: CYCLES', 760, lt, 0.4, 48, false); });

  hostShot('S42', A(41), 'host: the trick theory', 'AND THE TRICK THEORY?', { pose: shrug, q: 1, hi: false });
  sh('S42b', Wc('temperature', 41), 'temperature and pattern', (lt) => { R.paper(); B.thermo(640, 450, 1.1, 0.6, C.red); batt(1300, 450, 1.2, 0.9); pill('TEMPERATURE + CHARGING PATTERN', 860, lt, 0.3, 46, false); });
  sh('S42c', Wc('battery', 41), 'battery health', (lt) => { R.paper(); K.phone(960, 470, 1.35, 0, C.white, () => { R.txt('MAX', 0, -90, 44, C.ink, 'center', 1); B.battery(0, -10, 0.38, 0.9); R.txt('CAPACITY', 0, 80, 34, C.ink, 'center', 1); }); pill('BATTERY HEALTH SHOWS IT', 880, lt, 0.3, 52, false); });

  // ═════════ RECAP ═════════
  hostShot('S43', A(42), 'host: recap', 'QUICK RECAP', { chap: [8, 'RECAP'] });
  sh('S43b', Wc('crust', 42), 'crust', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.6, stuck: 8, hiCrust: 1 }); pill('1  A CRUST GROWS EVERY DAY', 190, lt, 0.3, 50, false); });
  sh('S43c', Wc('two', 42), 'full and warm', (lt) => { R.paper(); batt(700, 450, 1.4, 1); B.thermo(1330, 450, 1.1, 0.8, C.red); pill('2  FULL + WARM = FASTER WEAR', 860, lt, 0.3, 48, false); });
  sh('S43d', Wc('three', 42), 'fast or cold plating', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.3, spikes: 0.7 }); pill('3  FAST OR COLD CHARGING PLATES METAL', 190, lt, 0.3, 44, false); });
  sh('S44', A(43), 'trade-off seesaw', (lt) => { R.paper(); const [a, b] = B.seesaw(960, 620, 1, Math.sin(lt * 2) * 0.12); pillAt('CHARGE LESS', a[0] + 40, a[1] - 90, lt, 0.2, 42); pillAt('LASTS LONGER', b[0] - 40, b[1] - 90, lt, 0.5, 42); });
  sh('S44b', Wc('but', 43), 'holds less', (lt) => { R.paper(); batt(960, 440, 2.0, 0.8, { text: '80%' }); pill('BUT HOLDS LESS EACH DAY', 860, lt, 0.3, 52, false); });
  sh('S45', A(44), 'not a flaw, the plan', (lt) => { R.paper(); phoneP(960, 470, 1.35, 80); pill('NOT A FLAW. THE PLAN.', 880, lt, 0.3, 56); });
  sh('S46', A(45), 'two years ago', (lt) => { R.paper(); phoneP(960, 470, 1.35, 100); pill('TWO YEARS AGO: ALL DAY', 880, lt, 0.3, 52, false); });
  sh('S46b', Wc('now', 45), 'locked in a crust', (lt, d, t) => { R.paper(); ZOOM(t, { crust: 0.7, stuck: 10, hiCrust: 1 }); pill('A LITTLE LITHIUM, LOCKED IN A CRUST', 190, lt, 0.3, 48, false); });
  sh('S46c', Wc('not', 45), 'chemistry', (lt) => { R.paper(); big('NOT A TRICK', 960, 380, 200, C.ink); big('CHEMISTRY', 960, 600, 200, C.orange); });

  return { shots: S, cues: CUES };
}
