// YOUR INTERNET IS A GARDEN HOSE ON THE OCEAN FLOOR  (long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as G from './core/gps.js';
import * as M from './core/moon.js';
import * as Z from './core/sea.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
function dim(x0, y0, x1, y1, label, sc = 1, size = 40) {
  if (sc <= 0) return; ctx.save(); ctx.globalAlpha = clamp(sc);
  const an = Math.atan2(y1 - y0, x1 - x0), nx = -Math.sin(an) * 18, ny = Math.cos(an) * 18;
  line([[x0, y0], [x1, y1]], C.ink, 5); line([[x0 - nx, y0 - ny], [x0 + nx, y0 + ny]], C.ink, 5); line([[x1 - nx, y1 - ny], [x1 + nx, y1 + ny]], C.ink, 5); ctx.restore();
  if (label) R.pill(label, (x0 + x1) / 2, (y0 + y1) / 2 - 50, size, sc);
}
const big = (txt, x, y, size, color = C.orange) => R.txt(txt, x, y, size, color, 'center', 2);
const under = (t) => Z.seabed(780, t);
const pill = (s, y, lt, a = 0.3, size = 52, hi = true, x = 960) => R.pill(s, x, y, size, pop(lt, a), hi ? { hi: true } : {});
// ocean scene: sky + sea; draw things between ocean() and wave()
const ocean = (t) => { R.sky(t); R.sea(700, t); };
const wave = (t) => R.surf(752, t);
function cableTrail(sx, sy) { Z.cable([[sx, sy], [sx - 30, sy + 40], [sx - 110, sy + 120]], 16); }
// a ship at sea laying cable
function shipScene(t, o = {}) {
  ocean(t); const x = o.x ?? 960, w = o.w ?? 640; Z.cableShip(x, 690, w, t, o); cableTrail(x - w / 2 + 14, 700); wave(t);
}
// bar chart pair (paper)
function bars2(a, b, la, lb, lt) {
  R.paper(); line([[300, 800], [1620, 800]], C.ink, 8);
  const pa = eo(seg(lt, 0.2, 1.0)), pb = eo(seg(lt, 0.8, 1.9));
  wRect(480, 800 - a * pa, 220, a * pa + 2, 8, C.grayLight, { seed: 5, lw: 7 }); wRect(1140, 800 - b * pb, 220, b * pb + 2, 8, C.orange, { seed: 6, lw: 7 });
  R.pill(la, 590, 850, 36, pop(lt, 0.9)); R.pill(lb, 1250, 850, 36, pop(lt, 1.7), { hi: true });
}
const CT = Z.CITY;
function highway(lt, t) {
  R.paper(); wRect(120, 330, 1680, 420, 20, C.gray, { seed: 7, lw: 8 });
  for (const y of [470, 610]) { ctx.save(); ctx.setLineDash([60, 40]); line([[140, y], [1780, y]], C.white, 8); ctx.restore(); }
  const cols = Z.LASER;
  for (let i = 0; i < 4; i++) { const y = 400 + i * 80; const x = ((t * (240 + i * 20) + i * 400) % 1900) - 120; wRect(x, y - 28, 150, 56, 18, cols[i], { seed: 20 + i, lw: 6 }); circle(x + 40, y + 28, 12, C.ink); circle(x + 110, y + 28, 12, C.ink); }
}

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;
  const cam = [960, 520];
  const sh = (id, at, note, draw, o = {}) => add({ id, at, cam: o.cam || cam, zoom: o.zoom ?? 0.04, note, chap: o.chap, draw });
  const hostShot = (id, at, note, label, o = {}) => sh(id, at, note, (lt, d, t) => { R.studio(880); host(o.x ?? 1330, lt, o.pose || { arm: K.ARM.open, armL: K.ARM.hip }); if (o.q) K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill(label, o.px ?? 700, 450, o.size ?? 52, pop(lt, 0.3), o.hi === false ? {} : { hi: true }); }, { cam: [(o.x ?? 1330) > 1000 ? 1200 : 700, 540], zoom: 0.05, chap: o.chap });

  // ═════════ HOOK ═════════
  sh('S01', A(0), 'a cable on the ocean floor', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 790, 20, 30); pill('ON THE OCEAN FLOOR', 220, lt, 0.5, 58); });
  sh('S01b', Wc('not', 0), 'not a satellite', (lt, d, t) => { R.space(t, false); G.sat(960, 500, 0.85, 0.2); K.redX(960, 500, 1.6, pop(lt, 0.4)); pill('NOT A SATELLITE', 190, lt, 0.3, 56); });
  sh('S01c', Wc('about', 0), 'garden hose', (lt, d, t) => { R.paper(); Z.hose(960, 470, 210, eo(seg(lt, 0.1, 1.2))); pill('ABOUT AS THICK AS A GARDEN HOSE', 870, lt, 0.5, 48); });

  hostShot('S02', A(1), 'host: what you get', 'WHAT YOU WILL GET');
  sh('S02b', Wc('inside', 1), '1 inside', (lt, d, t) => { R.paper(); Z.cableCross(960, 480, 260, 5, -1, t); pill('1  WHAT IS INSIDE', 880, lt, 0.3, 52); });
  sh('S02c', Wc('laid', 1), '2 laid and repaired', (lt, d, t) => { shipScene(t, {}); pill('2  LAID AND REPAIRED', 230, lt, 0.3, 52); });
  sh('S02d', Wc('anchor', 1), '3 anchor', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 28); Z.anchor(960, 560 + Math.sin(lt * 1.5) * 8, 1.2, 0.25 * Math.sin(lt)); pill('3  ONE ANCHOR, THREE CONTINENTS', 200, lt, 0.3, 50); });

  hostShot('S03', A(2), 'host: fragile?', 'IS IT FRAGILE?', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug, brow: 0.6 }, q: 1, hi: false });
  sh('S03b', Wc('less', 2), 'less than you think', (lt, d, t) => { R.paper(); K.check(960, 450, 1.1, pop(lt, 0.2)); pill('LESS THAN YOU THINK', 790, lt, 0.5, 54); });
  sh('S03c', Wc('every', 2), 'pages I opened', (lt, d, t) => { R.paper(); M.pages(900, 480, 1.2); K.check(1380, 640, 0.6, pop(lt, 0.8)); pill('PAGES I ACTUALLY OPENED', 850, lt, 0.4, 48); });

  sh('S04', A(3), 'red sea cuts', (lt, d, t) => { Z.worldMap(); Z.route(CT.lis, CT.dubai, -40, 1, C.orange, 10); Z.city(CT.dubai); Z.breakMark(CT.dubai[0] - 130, CT.dubai[1] + 90, 1.4); pill('RED SEA CABLE CUTS, 2025', 190, lt, 0.4, 52); });
  sh('S04b', Wc('oldest', 3), 'oldest fiber cable pulled up', (lt, d, t) => { shipScene(t, {}); pill('OLDEST FIBER CABLE: BEING PULLED UP', 230, lt, 0.3, 46); });
  hostShot('S04c', Wc("let's", 3), 'host: start', 'FIRST: WHAT IS INSIDE', { x: 640, px: 1260, pose: { arm: K.ARM.point, mouth: 'grin' } });

  // ═════════ 1 · THE GLASS HOSE ═════════
  sh('S05', A(4), '99 percent', (lt, d, t) => { R.paper(); big('99%', 960, 430, 330); pill('OF DATA CROSSING AN OCEAN', 690, lt, 0.4, 52, false); }, { chap: [1, 'THE GLASS HOSE'] });
  sh('S05b', Wc('calls', 4), 'calls streams messages', (lt, d, t) => { R.paper(); K.phone(700, 480, 1.4, -0.1); K.laptop(1230, 520, 1.1); pill('CALLS, STREAMS, MESSAGES', 860, lt, 0.4, 48); });
  sh('S05c', Wc('satellites', 4), 'satellites small slice', (lt, d, t) => { R.space(t, false); G.sat(960, 480, 0.7, 0.3 + Math.sin(lt) * 0.05); pill('SATELLITES: A SMALL SLICE', 210, lt, 0.4, 52, false); });

  sh('S06', A(5), 'picture the cable', (lt, d, t) => { R.paper(); Z.cableCross(960, 470, 270, 5, -1, t); pill('PICTURE THE CABLE', 880, lt, 0.3, 54); });
  sh('S06b', Wc('twenty-five', 5), '25 mm garden hose', (lt, d, t) => { R.paper(); Z.hose(960, 470, 200, 1); pill('25 mm  =  A GARDEN HOSE', 860, lt, 0.4, 54); });
  sh('S06c', Wc('weighs', 5), '1.4 tonnes per km', (lt, d, t) => { R.paper(); big('1.4 t', 960, 430, 300); pill('PER KILOMETER OF CABLE', 680, lt, 0.4, 54, false); });

  hostShot('S07', A(6), 'host: heavy but thin', 'HEAVY, BUT THIN', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug } });
  sh('S07b', Wc('glass', 6), 'glass strands', (lt, d, t) => { R.paper(); Z.fiber(260, 470, 1660, 470, t, 1, { w: 56 }); pill('GLASS STRANDS CARRY THE DATA', 720, lt, 0.4, 50); });
  sh('S07c', Wc('thick', 6), 'thin as a hair', (lt, d, t) => { R.paper(); line([[360, 520], [640, 440], [900, 520], [1180, 440], [1560, 500]], C.hairDark, 9); R.pill('AS THICK AS A HUMAN HAIR', 960, 760, 52, pop(lt, 0.4), { hi: true }); });

  sh('S08', A(7), 'layers of protection', (lt, d, t) => { R.paper(); Z.cableCross(960, 470, 270, 5, -1, t); pill('LAYERS OF PROTECTION', 880, lt, 0.3, 54); });
  sh('S08b', Wc('jelly', 7), 'jelly', (lt, d, t) => { R.paper(); Z.cableCross(960, 470, 270, 5, 3, t); pill('A LAYER OF JELLY', 880, lt, 0.2, 52); });
  sh('S08c', Wc('steel', 7), 'steel wires', (lt, d, t) => { R.paper(); Z.cableCross(960, 470, 270, 5, 1, t); pill('STEEL WIRES + PLASTIC', 880, lt, 0.2, 52); });
  sh('S08d', Wc('near', 7), 'near the shore: thicker armor', (lt, d, t) => { R.sky(t); R.sea(720, t); Z.station(420, 700, 1.0); Z.cable([[520, 740], [800, 800], [1500, 840]], 44); R.surf(780, t); pill('NEAR THE SHORE: THICKER ARMOR', 230, lt, 0.3, 50); });

  hostShot('S09', A(8), 'host: twist', "HERE'S THE TWIST", { x: 640, px: 1260, pose: { arm: K.ARM.point, mouth: 'grin' } });
  sh('S09b', Wc('five', 8), '500 cables', (lt, d, t) => { Z.worldMap(); const k = Math.floor(eo(seg(lt, 0.2, 2.2)) * 6); const rs = [[CT.ny, CT.lon, -90], [CT.rio, CT.cape, -60], [CT.sf, CT.tok, -120], [CT.lis, CT.mum, -50], [CT.cape, CT.sing, 70], [CT.sing, CT.syd, 60]]; rs.slice(0, k + 1).forEach((r) => Z.route(r[0], r[1], r[2], 1)); pill('500+ CABLES IN SERVICE', 160, lt, 0.3, 54); });
  sh('S09c', Wc('hundreds', 8), 'hundreds of terabits', (lt, d, t) => { R.paper(); big('100s', 960, 400, 320); pill('OF TERABITS EVERY SECOND', 650, lt, 0.4, 54, false); });
  sh('S09d', Wc('cloud', 8), 'a hose on the seabed', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 36); pill('THE CLOUD IS A HOSE ON THE SEABED', 230, lt, 0.3, 50); });

  // ═════════ 2 · LIGHT IN GLASS ═════════
  hostShot('S10', A(9), 'host: how can glass carry a message', 'HOW CAN GLASS CARRY A MESSAGE?', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug }, q: 1, hi: false, size: 44, chap: [2, 'LIGHT IN GLASS'] });
  sh('S10b', Wc('lasers', 9), 'laser pulses', (lt, d, t) => { R.paper(); Z.fiber(260, 470, 1660, 470, t * 1.4, 1, { w: 60 }); pill('LASER PULSES', 720, lt, 0.3, 56); });
  sh('S10c', Wc('billions', 9), 'billions per second', (lt, d, t) => { R.paper(); big('BILLIONS', 960, 430, 260); pill('OF FLASHES EVERY SECOND', 660, lt, 0.4, 54, false); });

  sh('S11', A(10), 'dozens of colors', (lt, d, t) => { R.paper(); Z.fiber(260, 470, 1660, 470, t, 6, { w: 110 }); pill('DOZENS OF COLORS, ONE FIBER', 740, lt, 0.4, 52); });
  sh('S11b', Wc('think', 10), 'highway lanes', (lt, d, t) => { highway(lt, t); pill('EVERY CAR HAS ITS OWN LANE', 850, lt, 0.4, 50); });

  sh('S12', A(11), 'the light fades', (lt, d, t) => { R.paper(); Z.fiber(260, 470, 760, 470, t, 1, { w: 56 }); Z.fiber(760, 470, 1160, 470, t + 0.3, 1, { w: 56, alpha: 0.55 }); Z.fiber(1160, 470, 1660, 470, t + 0.6, 1, { w: 56, alpha: 0.25 }); pill('THE LIGHT FADES', 720, lt, 0.4, 56); });
  sh('S12b', Wc('amplifiers', 11), 'amplifier boosts', (lt, d, t) => { R.paper(); Z.fiber(260, 470, 960, 470, t, 1, { w: 56, alpha: 0.5 }); Z.fiber(960, 470, 1660, 470, t, 1, { w: 56 }); Z.repeater(960, 470, 1.6, 0.9); pill('AN AMPLIFIER BOOSTS THE SIGNAL', 720, lt, 0.3, 50); });
  sh('S12c', Wc('roughly', 11), 'every 100 km', (lt, d, t) => { R.paper(); line([[260, 480], [1660, 480]], C.ink, 14); Z.repeater(460, 480, 1.0); Z.repeater(1460, 480, 1.0); dim(460, 600, 1460, 600, '~100 km', pop(lt, 0.3), 50); });

  sh('S13', A(12), 'need power in the ocean', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 26); Z.repeater(960, 800, 1.6); K.mark('?', 960, 560 + Math.sin(lt * 3) * 8, pop(lt, 0.3) * 1.0, 0); pill('AMPLIFIERS NEED POWER', 220, lt, 0.3, 54); });
  sh('S13b', Wc('power', 12), 'power flows down the cable', (lt, d, t) => { under(t); Z.cableSag(420, 800, 1500, 800, 0, 26); Z.station(280, 830, 0.9); Z.repeater(1500, 800, 1.4, 0.6); for (let i = 0; i < 3; i++) { const u = ((t * 0.35 + i / 3) % 1); Z.bolt(lerp(480, 1440, u), 700, 0.7); } pill('POWER FLOWS DOWN THE CABLE', 200, lt, 0.3, 52); });
  sh('S13c', Wc('thousands', 12), 'thousands of volts', (lt, d, t) => { R.paper(); big('3,000 to 15,000 V', 960, 430, 150); pill('SENT FROM THE SHORE', 640, lt, 0.4, 54, false); Z.bolt(960, 790, 1.2); });

  hostShot('S14', A(13), 'host: why not satellites', 'WHY NOT SATELLITES?', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug }, q: 1, hi: false });
  sh('S14b', Wc('typical', 13), 'satellite 1 gigabit', (lt, d, t) => { R.paper(); line([[300, 800], [1620, 800]], C.ink, 8); const p = eo(seg(lt, 0.2, 1.0)); wRect(830, 800 - 24 * p, 260, 24 * p + 2, 6, C.grayLight, { seed: 5, lw: 6 }); G.sat(960, 640, 0.45, 0.3); pill('SATELLITE LINK: ~1 Gbit/s', 880, lt, 0.5, 44, false); });
  sh('S14c', Wc('cable', 13), 'cable terabits', (lt, d, t) => { R.paper(); line([[300, 800], [1620, 800]], C.ink, 8); const p = eo(seg(lt, 0.2, 1.4)); wRect(830, 800 - 520 * p, 260, 520 * p + 2, 8, C.orange, { seed: 6, lw: 7 }); wRect(560, 770, 90, 32, 6, C.grayLight, { seed: 5, lw: 5 }); pill('A CABLE MOVES TERABITS', 880, lt, 0.5, 46); });
  sh('S14d', Wc('thousand', 13), '1000x', (lt, d, t) => { R.paper(); big('1000x', 960, 430, 330); pill('MORE THAN A THOUSAND TIMES MORE', 690, lt, 0.4, 48, false); });
  sh('S15', A(14), 'light, colors, power in one hose', (lt, d, t) => { R.paper(); Z.cableCross(960, 470, 270, 5, -1, t); pill('LIGHT + COLORS + POWER, ONE HOSE', 880, lt, 0.3, 48); });

  // ═════════ 3 · THE FIRST ONE ═════════
  sh('S16', A(15), 'before fiber: telegraph', (lt, d, t) => { R.paper(); const dots = [1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1]; wRect(220, 380, 1480, 200, 18, C.white, { seed: 31, lw: 8 }); dots.forEach((v, i) => { const x = 280 + i * 94; if (v) wRect(x, 470, 66, 22, 11, C.ink, { seed: i, lw: 0 }); else circle(x + 10, 480, 11, C.ink); }); pill('BEFORE FIBER: THE TELEGRAPH', 750, lt, 0.4, 52); }, { chap: [3, 'THE FIRST ONE'] });
  sh('S16b', Wc('august', 15), '1858', (lt, d, t) => { R.paper(); big('1858', 960, 430, 330); pill('THE FIRST ATLANTIC CABLE', 690, lt, 0.4, 54, false); });
  sh('S16c', Wc('queen', 15), 'a message from Queen Victoria', (lt, d, t) => { R.paper(); K.crown(960, 430, 1.8); pill('A MESSAGE FROM QUEEN VICTORIA', 800, lt, 0.4, 50); });
  sh('S17', A(16), '98 words', (lt, d, t) => { R.paper(); big('98 words', 960, 430, 280); });
  sh('S17b', Wc('sixteen', 16), '16 hours', (lt, d, t) => { R.paper(); K.clock(960, 440, 1.3, lt * 3); pill('16 HOURS TO SEND', 800, lt, 0.2, 56); });
  sh('S18', A(17), 'the cable died', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 900, 800, 0, 26); Z.cableSag(1060, 800, 2020, 800, 0, 26); Z.breakMark(980, 780, 1.6); pill('THEN THE CABLE DIED', 230, lt, 0.4, 56); });
  sh('S18b', Wc('three', 17), 'three weeks', (lt, d, t) => { R.paper(); big('~3 weeks', 960, 430, 280); pill('AND ABOUT 700 MESSAGES', 690, lt, 0.4, 52, false); });
  sh('S19', A(18), '1866', (lt, d, t) => { R.paper(); big('1866', 960, 430, 330); });
  sh('S19b', Wc('giant', 18), 'Great Eastern', (lt, d, t) => { shipScene(t, { old: 1, w: 760 }); pill('THE GREAT EASTERN', 230, lt, 0.3, 56); });
  sh('S19c', Wc('eighty', 18), '80x faster', (lt, d, t) => { R.paper(); big('80x', 960, 430, 330); pill('FASTER', 690, lt, 0.3, 60, false); });
  sh('S20', A(19), '1988', (lt, d, t) => { R.paper(); big('1988', 960, 430, 330); });
  sh('S20b', Wc('tat-8', 19), 'TAT-8 first fiber', (lt, d, t) => { Z.worldMap(); Z.route(CT.ny, CT.lon, -110, eo(seg(lt, 0.2, 2.0)), C.orange, 16); Z.city(CT.ny); Z.city(CT.lon); pill('TAT-8: FIRST FIBER ACROSS THE ATLANTIC', 190, lt, 0.3, 44); });
  sh('S20c', Wc('forty', 19), '40,000 calls', (lt, d, t) => { R.paper(); K.phone(960, 440, 1.5, 0.05); K.phone(640, 480, 1.0, -0.15); K.phone(1280, 480, 1.0, 0.15); pill('40,000 CALLS AT ONCE', 850, lt, 0.4, 56); });
  sh('S20d', Wc('cost', 19), '$335M', (lt, d, t) => { R.paper(); big('$335M', 960, 430, 300); pill('WHAT IT COST IN 1988', 690, lt, 0.4, 54, false); });
  sh('S21', A(20), '2002 retired', (lt, d, t) => { R.paper(); big('2002', 960, 430, 330); pill('RETIRED', 690, lt, 0.3, 60, false); });
  sh('S21b', Wc('since', 20), 'since 2025 hauled up', (lt, d, t) => { ocean(t); const x = 960, w = 640; Z.cableShip(x, 690, w, t); Z.cable([[x - w / 2 + 14, 700], [x - w / 2 - 60, 760], [x - w / 2 - 200, 780]], 16); wave(t); pill('SINCE 2025: HAULED BACK UP', 230, lt, 0.3, 52); });
  sh('S21c', Wc('over', 20), '1012 km', (lt, d, t) => { R.paper(); big('1,012 km', 960, 430, 280); pill('RECOVERED BY AUGUST 2025', 690, lt, 0.4, 52, false); });
  sh('S22', A(21), 'three weeks vs fourteen years', (lt, d, t) => { bars2(40, 520, '3 WEEKS', '14 YEARS', lt); });

  // ═════════ 4 · LAYING IT ═════════
  hostShot('S23', A(22), 'host: how do you lay one', 'HOW DO YOU LAY ONE?', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug }, q: 1, hi: false, chap: [4, 'LAYING IT'] });
  sh('S23b', Wc('plan', 22), 'plan the route', (lt, d, t) => { under(t); for (const [x, y, r] of [[500, 790, 90], [1000, 830, 120], [1450, 780, 80]]) blob([[x - r, y + 40], [x - r * 0.5, y - r * 0.7], [x + r * 0.5, y - r * 0.8], [x + r, y + 40]], C.grayLight, { seed: x, lw: 7 }); const p = eo(seg(lt, 0.3, 2.6)); const pts = []; for (let i = 0; i <= 40 * p; i++) { const u = i / 40; const x = lerp(-60, 2000, u); pts.push([x, 700 + Math.sin(u * 9) * 40]); } if (pts.length > 1) Z.cable(pts, 24); pill('PLAN THE ROUTE', 220, lt, 0.3, 58); });

  sh('S24', A(23), 'then comes the ship', (lt, d, t) => { shipScene(t, {}); pill('THEN COMES THE SHIP', 230, lt, 0.3, 58); });
  sh('S24b', Wc('coiled', 23), 'coiled into tanks', (lt, d, t) => { R.paper(); Z.coil(960, 470, 270, eo(seg(lt, 0.2, 2.0))); pill('COILED INTO HUGE TANKS', 880, lt, 0.3, 52); });
  sh('S24c', Wc('loading', 23), 'about a month', (lt, d, t) => { R.paper(); big('~1 month', 960, 430, 280); pill('JUST TO LOAD IT', 690, lt, 0.3, 54, false); });

  sh('S25', A(24), 'crawls along', (lt, d, t) => { shipScene(t, {}); pill('THE SHIP CRAWLS ALONG', 230, lt, 0.3, 54); });
  sh('S25b', Wc('months', 24), 'months at sea', (lt, d, t) => { R.paper(); K.clock(960, 440, 1.3, lt * 1.2); pill('OFTEN MONTHS AT SEA', 800, lt, 0.3, 54); });
  sh('S25c', Wc('rough', 24), 'buoy in rough weather', (lt, d, t) => { ocean(t); Z.buoy(960, 700, 1.8, t); wave(t); pill('ROUGH WEATHER: TIE IT TO A BUOY', 220, lt, 0.3, 48); });

  sh('S26', A(25), 'near the coast buried', (lt, d, t) => { R.sky(t); R.sea(700, t); ctx.fillStyle = C.floor; ctx.fillRect(-300, 760, W + 600, 400); ctx.fillStyle = C.ink; ctx.fillRect(-300, 757, W + 600, 6); Z.station(420, 760, 1.0); Z.cable([[520, 880], [1000, 900], [1700, 880]], 26); pill('NEAR THE COAST: BURIED', 230, lt, 0.3, 54); });
  sh('S26b', Wc('faults', 25), '3.7 faults', (lt, d, t) => { R.paper(); big('3.7', 960, 430, 330, C.gray); pill('FAULTS PER 1,000 km PER YEAR', 690, lt, 0.4, 48, false); });
  sh('S26c', Wc('less', 25), '0.44 faults', (lt, d, t) => { R.paper(); big('0.44', 960, 430, 330); pill('AFTER BURIAL BECAME COMMON', 690, lt, 0.4, 48, false); K.check(1560, 330, 0.6, pop(lt, 0.9)); });

  sh('S27', A(26), 'deep ocean no burying', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 30); pill('DEEP OCEAN: NO BURYING', 230, lt, 0.3, 56); });
  sh('S27b', Wc('roughly', 26), '25 years', (lt, d, t) => { R.paper(); big('~25 years', 960, 430, 260); pill('ON THE BOTTOM', 680, lt, 0.3, 56, false); });

  // ═════════ 5 · WHEN IT BREAKS ═════════
  hostShot('S28', A(27), 'host: what breaks a cable', 'WHAT BREAKS A CABLE?', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug }, q: 1, hi: false, chap: [5, 'WHEN IT BREAKS'] });
  sh('S28b', Wc('about', 27), '80 percent human', (lt, d, t) => { R.paper(); R.pie(960, 470, 260, [{ v: 0.8, color: C.orange }, { v: 0.2, color: C.grayLight }], eo(seg(lt, 0.2, 1.3)), 0); pill('~80% COME FROM HUMAN ACTIVITY', 850, lt, 0.5, 48); });
  sh('S28c', Wc('usually', 27), 'anchors and nets', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 24); Z.anchor(640, 640, 1.1, 0.2); Z.net(1300, 380, 1300, 760, 300); pill('SHIP ANCHORS + FISHING NETS', 200, lt, 0.3, 50); });

  sh('S29', A(28), 'nature: quakes', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 24); K.shockLines(960, 790, 220, 0.6 + 0.4 * Math.sin(lt * 9)); pill('NATURE: QUAKES + LANDSLIDES', 220, lt, 0.3, 52); });
  sh('S29b', Wc('shark', 28), 'shark bites', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 24); Z.shark(960 + Math.sin(lt) * 60, 560, 1.4, 1, t); pill('EVEN SHARK BITES', 220, lt, 0.3, 56); });
  sh('S29c', Wc('fewer', 28), 'under 9 percent natural', (lt, d, t) => { R.paper(); R.pie(960, 470, 260, [{ v: 0.09, color: C.orange }, { v: 0.91, color: C.grayLight }], eo(seg(lt, 0.2, 1.3)), 0); pill('UNDER 9% WERE NATURAL', 850, lt, 0.5, 50); });

  sh('S30', A(29), 'shark famous suspect', (lt, d, t) => { under(t); Z.shark(960, 560, 1.7, 1, t); pill('THE FAMOUS SUSPECT: SHARK', 220, lt, 0.3, 52, false); });
  sh('S30b', Wc('anchor', 29), 'real culprit anchor', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 24); Z.anchor(960, 610 + Math.sin(lt * 2) * 10, 1.5, 0.15); pill('THE REAL CULPRIT: THE ANCHOR', 200, lt, 0.3, 52); });

  sh('S31', A(30), 'red sea Sept 2025', (lt, d, t) => { Z.worldMap(); Z.route(CT.lis, CT.dubai, -40, 1, C.orange, 10); Z.route(CT.cape, CT.dubai, 40, 1, C.orange, 10); Z.city(CT.dubai); Z.breakMark(1135, 590, 1.2); pill('RED SEA, SEPTEMBER 2025', 170, lt, 0.4, 54); });
  sh('S31b', Wc('several', 30), 'several cables cut', (lt, d, t) => { under(t); for (let i = 0; i < 4; i++) { const y = 700 + i * 50; Z.cableSag(-100, y, 880, y, 0, 18); Z.cableSag(1040, y, 2020, y, 0, 18); } Z.breakMark(960, 760, 1.9); pill('AT LEAST 4 CABLE SYSTEMS CUT', 200, lt, 0.3, 50); });
  const drag = (lt, d, t, q) => { R.sky(t); R.sea(330, t); R.ship(900, 320, 520, t, ''); Z.seabed(900, t, { floorOnly: 1 }); Z.cableSag(-100, 900, 2020, 900, 0, 22); line([[820 + Math.sin(t) * 6, 360], [800, 640], [760, 800]], C.ink, 8); Z.anchor(760 + lt * 20, 840, 0.9, 0.5); if (q) K.mark('?', 1450, 640 + Math.sin(lt * 3) * 8, 1.0, 0.1); };
  sh('S31c', Wc('industry', 30), 'dragging anchor likely', (lt, d, t) => { drag(lt, d, t, 0); pill('LIKELY CAUSE: A DRAGGING ANCHOR', 170, lt, 0.3, 50); });
  sh('S31d', Wc('not', 30), 'not confirmed', (lt, d, t) => { drag(lt, d, t, 1); pill('NOT CONFIRMED', 170, lt, 0.3, 60, false); });

  sh('S32', A(31), 'slower in India, Pakistan, Gulf, Africa', (lt, d, t) => { Z.worldMap(); for (const c of [CT.mum, [1270, 470], [1000, 600]]) { K.clock(c[0], c[1] - 40, 0.35, lt * 2); } pill('SLOWER: INDIA, PAKISTAN, THE GULF, AFRICA', 170, lt, 0.3, 42); });
  sh('S32b', Wc('microsoft', 31), 'traffic rerouted', (lt, d, t) => { Z.worldMap(); const p = eo(seg(lt, 0.2, 2.0)); Z.route(CT.lis, CT.dubai, -40, 1, C.grayLight, 10); Z.route(CT.lis, CT.mum, 130, p, C.orange, 14); pill('TRAFFIC REROUTED', 170, lt, 0.3, 58); });
  sh('S32c', Wc('nothing', 31), 'slower not dark', (lt, d, t) => { R.paper(); K.clock(960, 440, 1.3, lt * 0.8); pill('NOT DARK, JUST SLOWER', 800, lt, 0.3, 56); });

  sh('S33', A(32), 'Tonga 2022', (lt, d, t) => { ocean(t); Z.volcano(960, 700, 1.1, t); wave(t); pill('TONGA, 2022', 150, lt, 0.4, 60); });
  sh('S33b', Wc('tore', 32), 'only cable torn', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 900, 800, 0, 26); Z.cableSag(1060, 800, 2020, 800, 0, 26); Z.breakMark(980, 780, 1.7); pill("THE ISLAND'S ONLY CABLE, TORN UP", 220, lt, 0.3, 48); });
  sh('S33c', Wc('five', 32), '5 weeks', (lt, d, t) => { R.paper(); big('~5 weeks', 960, 430, 280); pill('TO REPAIR IT', 690, lt, 0.3, 56, false); });
  sh('S33d', Wc('backup', 32), 'backup route', (lt, d, t) => { Z.worldMap(); Z.route(CT.ny, CT.lon, -110, 1, C.grayLight, 12); K.redX(770, 228, 0.3, 1); Z.route(CT.ny, CT.lon, 90, 1, C.orange, 14); pill('BACKUP ROUTE: DATA FINDS ANOTHER WAY', 110, lt, 0.3, 44); });
  sh('S33e', Wc('not', 32), 'no backup', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 900, 800, 0, 26); Z.cableSag(1060, 800, 2020, 800, 0, 26); K.redX(980, 700, 1.7, pop(lt, 0.2)); pill('NO BACKUP: NOTHING GETS THROUGH', 220, lt, 0.3, 46); });

  sh('S34', A(33), 'who fixes a break', (lt, d, t) => { shipScene(t, {}); pill('WHO FIXES A BREAK?', 230, lt, 0.3, 58); });
  sh('S34b', Wc('first', 33), 'test signal and echo', (lt, d, t) => { under(t); ctx.fillStyle = C.floor; ctx.fillRect(-300, 720, 640, 500); Z.station(200, 720, 0.8); Z.cableSag(250, 830, 2020, 830, 0, 24); Z.breakMark(1400, 800, 1.2); const u = (lt * 0.4) % 1, f = u < 0.5 ? u * 2 : 2 - u * 2; circle(lerp(300, 1400, f), 830, 20, C.orange); pill('SEND A TEST SIGNAL, TIME THE ECHO', 190, lt, 0.3, 46); });
  sh('S34c', Wc('which', 33), 'the echo shows where', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 24); Z.breakMark(1100, 780, 1.7); R.arrowV(1100, 600, 150, PI * 0.5, C.orange, 34); pill('THE ECHO SHOWS WHERE', 200, lt, 0.3, 54); });

  sh('S35', A(34), 'drop a marker buoy', (lt, d, t) => { ocean(t); Z.cableShip(700, 690, 560, t); Z.buoy(1300, 700, 1.6, t); wave(t); pill('DROP A MARKER BUOY', 230, lt, 0.3, 56); });
  sh('S35b', Wc('hooks', 34), 'grapple', (lt, d, t) => { under(t); Z.cableSag(-100, 860, 2020, 860, 0, 24); Z.grapple(960, 600 + eo(seg(lt, 0.2, 2.2)) * 120, 1.4, 0); pill('HOOK IT WITH A GRAPPLE', 200, lt, 0.3, 54); });

  sh('S36', A(35), 'splice new cable', (lt, d, t) => { R.paper(); Z.cable([[200, 520], [700, 520]], 36); Z.cable([[1220, 520], [1720, 520]], 36); const p = eo(seg(lt, 0.4, 2.2)); Z.cable([[700, 520], [lerp(700, 1220, p), 520]], 36, { color: C.orange }); pill('CUT OUT THE DAMAGE, SPLICE IN NEW CABLE', 780, lt, 0.3, 46); });
  sh('S36b', Wc('repaired', 35), 'extra cable in a U shape', (lt, d, t) => { under(t); Z.cable([[-100, 800], [700, 800], [760, 700], [960, 640], [1160, 700], [1220, 800], [2020, 800]], 26); pill('THE EXTRA IS LAID IN A U SHAPE', 220, lt, 0.3, 50); });

  sh('S37', A(36), '50 repairs a year', (lt, d, t) => { R.paper(); big('50+', 960, 430, 330); pill('REPAIRS A YEAR IN THE ATLANTIC ALONE', 690, lt, 0.4, 46, false); });
  sh('S37b', Wc('how', 36), 'depends on ship and permits', (lt, d, t) => { shipScene(t, { x: lerp(1500, 960, eo(seg(lt, 0, 3.0))), w: 520 }); pill('DEPENDS ON A SHIP + PERMITS', 230, lt, 0.3, 52); });

  // ═════════ 6 · WHO OWNS THEM ═════════
  hostShot('S38', A(37), 'host: who owns all this', 'WHO OWNS ALL THIS?', { pose: { arm: K.ARM.shrug, armL: K.ARM.shrug }, q: 1, hi: false, chap: [6, 'WHO OWNS THEM'] });
  sh('S38b', Wc('groups', 37), 'phone companies', (lt, d, t) => { R.paper(); K.brickPhone(960, 460, 1.4, 0.05); pill('ONCE: GROUPS OF PHONE COMPANIES', 850, lt, 0.3, 46); });
  sh('S38c', Wc('today', 37), 'big tech', (lt, d, t) => { R.paper(); big('BIG TECH', 960, 420, 240); pill('OWNS OR SHARES A GROWING PORTION', 650, lt, 0.4, 48, false); });

  sh('S39', A(38), 'MAREA US-Spain', (lt, d, t) => { Z.worldMap(); Z.route(CT.ny, [880, 400], -100, eo(seg(lt, 0.2, 2.2)), C.orange, 16); Z.city(CT.ny); Z.city([880, 400]); pill('MAREA: UNITED STATES TO SPAIN', 170, lt, 0.3, 50); });
  sh('S39b', Wc("google's", 38), 'Nuvem', (lt, d, t) => { Z.worldMap(); const p = eo(seg(lt, 0.2, 2.4)); Z.route(CT.ny, [770, 480], -20, Math.min(1, p * 2), C.orange, 14); Z.route([770, 480], CT.lis, -40, clamp(p * 2 - 1), C.orange, 14); Z.city(CT.ny); Z.city(CT.lis); pill('NUVEM: US, BERMUDA, PORTUGAL', 170, lt, 0.3, 50); });
  sh('S39c', Wc('expected', 38), 'expected 2026', (lt, d, t) => { R.paper(); big('2026', 960, 430, 330); pill('EXPECTED TO START UP', 690, lt, 0.3, 54, false); });

  sh('S40', A(39), 'video buffers', (lt, d, t) => { R.paper(); K.phone(960, 460, 1.5, 0.05); ctx.save(); ctx.translate(960, 440); ctx.rotate(lt * 6); ctx.beginPath(); ctx.arc(0, 0, 60, 0, TAU * 0.75); ctx.lineWidth = 16; ctx.strokeStyle = C.orange; ctx.lineCap = 'round'; ctx.stroke(); ctx.restore(); pill('A VIDEO BUFFERS...', 880, lt, 0.3, 52, false); });
  sh('S40b', Wc('bottom', 39), 'look at the bottom of the sea', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 30); pill('LOOK AT THE BOTTOM OF THE SEA', 230, lt, 0.3, 52); });

  // ═════════ RECAP ═════════
  hostShot('S41', A(40), 'host: recap', 'PUTTING IT TOGETHER', { chap: [7, 'THE RECAP'] });
  sh('S41b', Wc('ninety-nine', 40), '99 percent', (lt, d, t) => { R.paper(); big('99%', 960, 430, 330); pill('OF OCEAN-CROSSING DATA', 690, lt, 0.3, 52, false); });
  sh('S41c', Wc('thick', 40), 'garden hose', (lt, d, t) => { R.paper(); Z.hose(960, 470, 210, 1); pill('ABOUT AS THICK AS A GARDEN HOSE', 870, lt, 0.3, 46); });
  sh('S42', A(41), 'glass, light, colors', (lt, d, t) => { R.paper(); Z.fiber(260, 470, 1660, 470, t, 6, { w: 110 }); pill('LASER LIGHT IN MANY COLORS', 740, lt, 0.3, 52); });
  sh('S42b', Wc('boosted', 41), 'boosted and powered', (lt, d, t) => { under(t); Z.cableSag(420, 800, 1500, 800, 0, 26); Z.station(280, 830, 0.9); Z.repeater(960, 800, 1.4, 0.6); Z.bolt(700 + ((t * 300) % 500), 700, 0.7); pill('BOOSTED + POWERED FROM THE SHORE', 200, lt, 0.3, 46); });
  sh('S43', A(42), '98 words in 16 hours', (lt, d, t) => { R.paper(); big('98 words', 960, 400, 260); pill('IN 16 HOURS (1858)', 650, lt, 0.3, 54, false); });
  sh('S43b', Wc('hundreds', 42), 'hundreds of terabits', (lt, d, t) => { R.paper(); big('100s', 960, 400, 320); pill('OF TERABITS EVERY SECOND', 650, lt, 0.3, 54, false); });
  sh('S44', A(43), 'anchors more than sharks', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 800, 0, 24); Z.anchor(960, 610, 1.5, 0.15); Z.shark(380, 520, 0.7, 1, t); pill('ANCHORS BEAT SHARKS', 200, lt, 0.3, 54); });
  sh('S44b', Wc('repair', 43), 'repair ships fix them', (lt, d, t) => { shipScene(t, {}); pill('REPAIR SHIPS: HOOK, SPLICE, SET DOWN', 230, lt, 0.3, 48); });
  sh('S45', A(44), 'loop back: cable on the ocean floor', (lt, d, t) => { under(t); Z.cableSag(-100, 800, 2020, 790, 20, 30); pill('YOU WERE READING THROUGH THIS', 230, lt, 0.5, 52); });
  hostShot('S45b', Wc('now', 44), 'now you know', 'NOW YOU KNOW WHAT IS INSIDE', { size: 46 });

  return { shots: S, cues: CUES };
}
