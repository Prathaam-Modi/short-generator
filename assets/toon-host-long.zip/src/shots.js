// THE MACHINE THAT BLASTS TIN 50,000 TIMES A SECOND  (long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine, fillAll } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as M from './core/moon.js';
import * as G from './core/gps.js';
import * as E from './core/euv.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
const big = (txt, x, y, size, color = C.orange) => R.txt(txt, x, y, size, color, 'center', 2);
const pill = (s, y, lt, a = 0.3, size = 52, hi = true, x = 960) => R.pill(s, x, y, size, pop(lt, a), hi ? { hi: true } : {});
const pillAt = (s, x, y, lt, a = 0.3, size = 44, hi = false) => R.pill(s, x, y, size, pop(lt, a), hi ? { hi: true } : {});
const dark = () => fillAll('#1B2740');
const lightD = (x, y0, y1, w0, w1) => poly([[x - w0, y0], [x + w0, y0], [x + w1, y1], [x - w1, y1]], C.yellow, { seed: 801, wob: 1, lw: 6 });
// a stream of tin drops moving along a line
function stream(x0, y0, x1, y1, lt, n = 5, r = 16, speed = 0.9) {
  for (let i = 0; i < n; i++) { const u = (((lt * speed) + i / n) % 1); E.droplet(lerp(x0, x1, u), lerp(y0, y1, u), r, 0, false); }
}
function chart(items, lt, base = 800, w = 200) {
  R.paper(); line([[260, base], [1660, base]], C.ink, 8);
  const gap = 1400 / items.length;
  items.forEach((it, i) => {
    const p = eo(seg(lt, it.at ?? 0.2, (it.at ?? 0.2) + 0.9)); if (p <= 0) return;
    const x = 260 + gap * (i + 0.5);
    R.bar(x, base, w, it.h, it.hi ? C.orange : C.grayLight, p, 10 + i);
    R.txt(it.lab, x, base + 52, 40, C.ink, 'center', 1);
    if (it.pill) R.pill(it.pill, x, base - it.h * p - 56, 40, pop(lt, (it.at ?? 0.2) + 0.7), it.hi ? { hi: true } : {});
  });
}

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;
  const cam = [960, 520];
  const sh = (id, at, note, draw, o = {}) => add({ id, at, cam: o.cam || cam, zoom: o.zoom ?? 0.04, note, chap: o.chap, draw });
  const hostShot = (id, at, note, label, o = {}) => sh(id, at, note, (lt, d, t) => { R.studio(880); host(o.x ?? 1330, lt, o.pose || { arm: K.ARM.open, armL: K.ARM.hip }); if (o.q) K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill(label, o.px ?? 700, 450, o.size ?? 52, pop(lt, 0.3), o.hi === false ? {} : { hi: true }); }, { cam: [(o.x ?? 1330) > 1000 ? 1200 : 700, 540], zoom: 0.05, chap: o.chap });
  const shrug = { arm: K.ARM.shrug, armL: K.ARM.shrug };
  const point = { arm: K.ARM.point, mouth: 'grin' };

  // ═════════ HOOK ═════════
  sh('S01', A(0), 'tin drop flying', (lt) => { dark(); E.droplet(lerp(420, 1500, seg(lt, 0, 5.2)), 470, 90, 0, true); K.speedLines(lerp(420, 1500, seg(lt, 0, 5.2)) - 40, 470, 0.8); pill('A DROP OF MOLTEN TIN', 850, lt, 0.4, 52, false); });
  sh('S01b', Wd('seventy', 0) - 0.06, '70 m/s', (lt) => { dark(); E.droplet(1000 + Math.sin(lt * 9) * 6, 470, 90, 0, true); K.speedLines(960, 470, 0.9); pill('ABOUT 70 METRES A SECOND', 850, lt, 0.2, 52, false); });
  sh('S01c', Wc('laser', 0), 'laser about to hit', (lt) => { dark(); E.droplet(1240, 470, 88, 0, true); E.beam(160, 470, lerp(160, 1180, eo(seg(lt, 0, 1.6))), 470, 30, 1); pill('A LASER IS ABOUT TO HIT IT', 850, lt, 0.3, 52, false); });
  sh('S01d', Wc('twice', 0), 'twice', (lt) => { dark(); E.plasma(960, 470, 1.4, lt < 0.9 ? Math.abs(Math.sin(lt * 4.4)) : 0, lt); big('TWICE', 960, 470, 300, C.white); pill('TWO SHOTS PER DROP', 850, lt, 0.3, 52, false); });
  sh('S01e', Wc('tiny', 0), 'that blast makes chips', (lt) => { dark(); K.chip(960, 460, 1.9); pill('HOW THE MOST ADVANCED CHIPS ARE MADE', 850, lt, 0.3, 50, false); });

  hostShot('S02', A(1), 'host: what you get', 'WHAT YOU WILL GET');
  sh('S02b', Wc('tin', 1), 'tin to chip', (lt) => { R.paper(); E.droplet(620, 470, 96, 0, true); R.arrowV(780, 470, 220, 0); K.chip(1280, 470, 1.4); pill('TIN DROP TO COMPUTER CHIP', 850, lt, 0.3, 50, false); });
  sh('S02c', Wc('only', 1), 'only one machine', (lt) => { R.paper(); E.machine(960, 480, 1.5, true); pill('ONLY ONE MACHINE CAN DO IT', 860, lt, 0.3, 52, false); });
  sh('S02d', Wc('ai', 1), 'AI boom', (lt) => { R.paper(); K.chip(960, 450, 2.0, C.orange); big('AI', 960, 450, 120, C.white); pill('THE AI BOOM NEEDS IT', 860, lt, 0.3, 54, false); });

  hostShot('S03', A(2), 'host: sci-fi?', 'IS THIS SCI-FI?', { pose: { ...shrug, brow: 0.6 }, q: 1, hi: false });
  sh('S03b', Wc('about', 2), '50,000 per second', (lt) => { R.paper(); big('50,000', 960, 400, 360); pill('TIMES EVERY SECOND, FOR REAL', 760, lt, 0.4, 52, false); });
  sh('S03c', Wc('number', 2), 'pages opened', (lt) => { R.paper(); M.pages(900, 480, 1.2); K.check(1380, 640, 0.6, pop(lt, 0.8)); pill('PAGES I ACTUALLY OPENED', 850, lt, 0.4, 48, false); });
  sh('S03d', Wc('like', 2), 'zeiss trumpf intel', (lt) => { R.paper(); K.laptop(960, 520, 1.5, C.white, () => { for (let i = 0; i < 5; i++) wRect(-150, -60 + i * 40, i % 2 ? 220 : 300, 14, 7, C.paperLine, { seed: i, lw: 3 }); }); pillAt('ZEISS', 520, 880, lt, 0.2, 40); pillAt('TRUMPF', 960, 880, lt, 0.8, 40); pillAt('INTEL', 1400, 880, lt, 1.4, 40); });

  sh('S04', A(3), 'why now', (lt) => { R.paper(); big('NOW', 960, 400, 380); pill('WHY NOW?', 760, lt, 0.3, 56, false); });
  sh('S04a', Wc('next', 3), 'High-NA', (lt) => { R.paper(); big('HIGH-NA', 960, 400, 300); pill('THE NEXT VERSION OF THE MACHINE', 760, lt, 0.4, 48, false); });
  sh('S04c', Wc('started', 3), 'in production at Intel', (lt) => { R.paper(); K.chip(960, 440, 1.8); pill('REAL CHIP PRODUCTION AT INTEL', 860, lt, 0.3, 50, false); });
  hostShot('S04b', Wc('but', 3), 'host: why tin', 'WHY SHOOT TIN WITH A LASER?', { x: 640, px: 1260, q: 1, hi: false, pose: shrug, size: 44 });

  // ═════════ 1 · PRINTING WITH LIGHT ═════════
  sh('S05', A(4), 'a chip', (lt) => { R.paper(); K.chip(960, 440, 1.8); pill('EVERY CHIP STARTS HERE', 860, lt, 0.3, 54, false); }, { chap: [1, 'PRINTING WITH LIGHT'] });
  sh('S05a', Wc('shiny', 4), 'wafer', (lt) => { R.paper(); E.wafer(960, 470, 250); pill('A SILICON WAFER', 860, lt, 0.3, 54, false); });
  sh('S05b', Wc('coat', 4), 'coating', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT }); pill('A LIGHT-SENSITIVE COATING', 860, lt, 0.3, 52, true); });
  sh('S05c', Wc('old', 4), 'old film', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT }); pill('A BIT LIKE OLD CAMERA FILM', 860, lt, 0.3, 50, false); });

  sh('S06', A(5), 'light through a mask', (lt) => { R.paper(); lightD(960, 110, 280, 130, 130); E.mask(960, 250, 0.55); lightD(960, 350, 530, 110, 170); E.wafer(960, 670, 150, { coat: E.COAT }); pill('LIGHT THROUGH A MASK', 880, lt, 0.3, 46, false); }, { zoom: 0.02 });
  sh('S06b', Wc('where', 5), 'coating changes', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT, pat: eo(seg(lt, 0.2, 2.5)) }); pill('WHERE LIGHT HITS, IT CHANGES', 860, lt, 0.3, 50, false); });
  sh('S06c', Wc('chemicals', 5), 'wash away', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT, pat: 1, patColor: '#F3F0EA' }); pill('CHEMICALS WASH IT AWAY', 860, lt, 0.3, 52, true); });

  hostShot('S07', A(6), 'host: the catch', "HERE'S THE CATCH", { x: 640, px: 1260, pose: point });
  sh('S07b', Wc('light', 6), 'light is a wave', (lt) => { R.paper(); E.wave(300, 480, 1320, 90, 300, C.orange, 18, eo(seg(lt, 0, 1.2)), -lt * 4); pill('LIGHT IS A WAVE', 860, lt, 0.3, 56, false); });
  sh('S07c', Wc('like', 6), 'fat marker', (lt) => { R.paper(); R.txt('tiny letters', 960, 470, 90, C.ink, 'center', 1); line([[420, 450], [1500, 490]], 'rgba(245,124,42,0.9)', 120); pill('A FAT MARKER, TINY LETTERS', 860, lt, 0.3, 52, false); });

  sh('S08', A(7), '193 nm', (lt) => { R.paper(); E.wave(260, 450, 1400, 100, 420, C.blue, 18, eo(seg(lt, 0, 1.2)), -lt * 3); pill('DEEP ULTRAVIOLET LIGHT', 860, lt, 0.3, 52, false); });
  sh('S08a', Wc('one', 7), '193 nm', (lt) => { R.paper(); E.wave(260, 600, 1400, 100, 420, C.blue, 18, 1, -lt * 3); big('193 nm', 960, 330, 260, C.orange); pill('DEEP ULTRAVIOLET LIGHT', 860, lt, 0.3, 52, false); });
  sh('S08b', Wc('stretched', 7), 'water trick', (lt) => { R.paper(); E.wafer(960, 560, 250, { coat: E.COAT }); wRect(700, 270, 520, 80, 30, 'rgba(74,127,181,0.55)', { seed: 820, lw: 7 }); pill('TRICK 1: WATER OVER THE WAFER', 860, lt, 0.3, 44, false); }, { zoom: 0.02 });
  sh('S08c', Wc('printing', 7), 'several passes', (lt) => { R.paper(); big('x3', 960, 420, 400); pill('TRICK 2: SAME LAYER, SEVERAL PASSES', 780, lt, 0.3, 44, false); });

  sh('S09', A(8), 'tricks ran out', (lt) => { R.paper(); E.wave(260, 450, 1400, 100, 420, C.blue, 18, 1, -lt * 3); K.redX(960, 450, 0.4, pop(lt, 0.4)); pill('THE TRICKS RAN OUT', 860, lt, 0.3, 56, false); });
  sh('S09b', Wc('fix', 8), 'shorter wave', (lt) => { R.paper(); E.wave(260, 330, 1400, 80, 420, C.blue, 16, 1, -lt * 3); E.wave(260, 640, 1400, 60, 70, C.orange, 16, eo(seg(lt, 0.3, 1.6)), -lt * 6); pillAt('193 nm', 1560, 250, lt, 0.2, 44); pillAt('13.5 nm', 1560, 740, lt, 0.9, 44, true); });
  sh('S09c', Wc('extreme', 8), 'EUV', (lt) => { R.paper(); big('EUV', 960, 400, 420); pill('EXTREME ULTRAVIOLET', 760, lt, 0.4, 56, false); });
  sh('S09d', Wc('visible', 8), '30 to 60 times longer', (lt) => { R.paper(); E.wave(260, 330, 1400, 90, 440, '#8FA8C0', 16, 1, -lt * 3); E.wave(260, 640, 1400, 60, 40, C.orange, 16, 1, -lt * 6); pill('VISIBLE LIGHT: ROUGHLY 30 TO 60x LONGER', 860, lt, 0.3, 44, false); });

  sh('S10', A(9), 'shorter = finer', (lt) => { R.paper(); E.wave(300, 470, 1320, 50, 60, C.orange, 14, eo(seg(lt, 0, 1.2)), -lt * 6); pill('SHORTER LIGHT = FINER LINES', 860, lt, 0.3, 54, false); });
  sh('S10b', Wc('hard', 9), 'where to get it', (lt) => { R.paper(); big('?', 960, 430, 560, C.orange); pill('WHERE DO YOU GET IT?', 860, lt, 0.3, 54, false); });

  // ═════════ 2 · THE LIGHT NOBODY HAS ═════════
  sh('S11', A(10), 'EUV ray', (lt) => { dark(); E.beam(200, 470, lerp(200, 1100, eo(seg(lt, 0, 1.5))), 470, 34, 1, C.yellow); pill('EXTREME ULTRAVIOLET LIGHT', 850, lt, 0.3, 50, false); }, { chap: [2, 'THE LIGHT NOBODY HAS'] });
  sh('S11b', Wc('swallowed', 10), 'swallowed', (lt) => { dark(); wRect(1000, 300, 110, 340, 20, C.grayLight, { seed: 830 }); E.beam(200, 470, 1000, 470, 34, 1, C.yellow); K.redX(1380, 470, 0.22, pop(lt, 0.5)); pill('SWALLOWED BY ALMOST EVERYTHING', 850, lt, 0.3, 48, false); });
  sh('S11c', Wc('glass', 10), 'glass and air absorb', (lt) => { dark(); E.lens(1020, 470, 220); E.beam(200, 470, 960, 470, 34, 1, C.yellow); pill('GLASS AND EVEN AIR ABSORB IT', 850, lt, 0.3, 50, false); });

  sh('S12', A(11), 'vacuum', (lt) => { dark(); E.chamber(960, 460, 1200, 520, '#243556'); E.beam(260, 460, 1660, 460, 34, 1, C.yellow); pill('THE WHOLE MACHINE RUNS IN A VACUUM', 850, lt, 0.3, 46, false); });
  sh('S12b', Wc('lenses', 11), 'no lenses', (lt) => { R.paper(); E.lens(960, 440, 220); K.redX(960, 440, 0.55, pop(lt, 0.4)); pill('NO LENSES', 860, lt, 0.3, 58, false); });
  sh('S12c', Wc('everything', 11), 'mirrors only', (lt) => { R.paper(); E.mirror(960, 450, 220); K.check(1300, 330, 0.5, pop(lt, 0.4)); pill('MIRRORS ONLY', 860, lt, 0.3, 58, true); });

  sh('S13', A(12), 'no EUV bulb', (lt) => { R.paper(); K.bulb(960, 440, 1.5, 1); K.redX(960, 440, 0.6, pop(lt, 0.5)); pill("YOU CAN'T BUY AN EUV BULB", 860, lt, 0.3, 52, false); });
  sh('S13b', Wc('turning', 12), 'tin into plasma', (lt) => { dark(); E.droplet(620, 470, 96, 0, false); R.arrowV(780, 470, 220, 0); E.plasma(1300, 470, 1.4, 1, lt * 0.5); pill('TIN INTO PLASMA', 850, lt, 0.3, 56, true); });
  sh('S13c', Wc('hotter', 12), 'hotter than the sun', (lt) => { dark(); E.sunDisc(640, 470, 130); R.txt('THE SUN', 640, 640, 40, C.white, 'center', 1); E.plasma(1280, 470, 1.4, 1, lt * 0.5); pill("HOTTER THAN THE SUN'S SURFACE", 850, lt, 0.3, 48, false); });
  sh('S13d', Wc('so', 12), 'make it', (lt) => { dark(); E.droplet(960, 450, 110, 0, true); pill('MAKE THE LIGHT YOURSELF', 850, lt, 0.3, 54, false); });
  hostShot('S14', A(13), 'host: cook it', 'COOK THE LIGHT YOURSELF', { x: 640, px: 1260, size: 46, pose: point });
  sh('S14b', Wc('one', 13), 'one drop at a time', (lt) => { dark(); E.droplet(960, 450, 110, 0, true); pill('ONE DROP AT A TIME', 850, lt, 0.3, 56, false); });

  // ═════════ 3 · THE TIN DANCE ═════════
  sh('S15', A(14), 'generator', (lt) => { dark(); E.generator(960, 250, 1.1); stream(960, 270, 960, 800, lt, 4, 26, 0.6); pill('A DROPLET GENERATOR', 880, lt, 0.3, 50, false); }, { chap: [3, 'THE TIN DANCE'] });
  sh('S15a', Wc('droplets', 14), 'molten tin drops', (lt) => { dark(); stream(520, 470, 1400, 470, lt, 5, 30, 0.8); pill('DROPLETS OF MOLTEN TIN', 850, lt, 0.3, 52, false); });
  sh('S15b', Wc('twenty', 14), 'tiny drop', (lt) => { dark(); E.droplet(960, 450, 120, 0, true); pill('ABOUT 25 MILLIONTHS OF A METRE', 850, lt, 0.3, 46, false); });
  sh('S15c', Wc('seventy', 14), '70 m/s', (lt) => { dark(); stream(300, 470, 1620, 470, lt, 6, 30, 1.4); K.speedLines(520, 470, 0.5); pill('ABOUT 70 METRES A SECOND', 850, lt, 0.3, 50, false); });
  sh('S16', A(15), '250 km/h', (lt) => { R.paper(); big('~250 km/h', 960, 400, 250); pill('MY OWN ARITHMETIC', 760, lt, 0.5, 52, false); });
  sh('S16b', Wc('fires', 15), '50,000 per second', (lt) => { dark(); stream(300, 440, 1620, 440, lt, 8, 26, 2.6); big('50,000', 960, 640, 180, C.white); pill('DROPS EVERY SINGLE SECOND', 850, lt, 0.3, 50, false); });

  sh('S17', A(16), 'now the laser', (lt) => { dark(); E.droplet(1200, 470, 88, 0, true); E.beam(160, 470, 1120, 470, 14, 0.5, C.red); pill('NOW THE LASER', 850, lt, 0.3, 56, false); });
  sh('S17b', Wc('first', 16), 'pulse 1', (lt) => { dark(); const p = eo(seg(lt, 0.6, 2.4)); E.beam(160, 470, 1100, 470, 16, 1, C.red); E.droplet(1200 + p * 40, 470, 88, p, true); pill('PULSE 1: A WEAKER SHOT', 850, lt, 0.3, 52, false); });
  sh('S17c', Wc('split', 16), 'pulse 2', (lt) => { dark(); E.droplet(1200, 470, 88, 1, true); E.beam(160, 470, lerp(160, 1020, eo(seg(lt, 0, 0.5))), 470, 40, 1, C.red); pill('PULSE 2: MUCH STRONGER', 850, lt, 0.3, 52, true); });
  sh('S18', A(17), 'plasma every direction', (lt) => { dark(); for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU + 0.26, r0 = 150, r1 = 150 + 190 * eo(seg(lt, 0.2, 1.2)); line([[960 + Math.cos(a) * r0, 470 + Math.sin(a) * r0], [960 + Math.cos(a) * r1, 470 + Math.sin(a) * r1]], C.yellow, 12); } E.plasma(960, 470, 1.0, 1, lt * 0.6); pill('EUV LIGHT IN EVERY DIRECTION', 850, lt, 0.3, 50, false); });
  sh('S18a', Wc('thirteen', 17), '13.5', (lt) => { dark(); big('13.5 nm', 960, 430, 340, C.yellow); pill('THE LIGHT WE NEED', 850, lt, 0.3, 54, false); });
  sh('S18b', Wc('two', 17), 'two shots per drop', (lt) => { R.paper(); big('2', 960, 400, 520); pill('SHOTS PER DROP', 800, lt, 0.3, 54, false); });
  sh('S18c', Wc('hundred', 17), '100,000 pulses', (lt) => { R.paper(); big('100,000', 960, 400, 340); pill('LASER PULSES EVERY SECOND', 760, lt, 0.4, 52, false); });

  hostShot('S19', A(18), 'host: how strong', 'HOW STRONG IS THAT LASER?', { pose: shrug, q: 1, hi: false });
  sh('S19b', Wc('carbon', 18), 'CO2 laser', (lt) => { R.paper(); wRect(560, 330, 800, 260, 40, C.grayLight, { seed: 840, lw: 9 }); wRect(600, 370, 300, 180, 20, '#CFE8F7', { seed: 841 }); E.beam(1360, 460, 1760, 460, 30, 1); pill('A CO2 LASER BUILT BY TRUMPF', 860, lt, 0.3, 48, false); });
  sh('S19c', Wc('starts', 18), 'few watts', (lt) => { R.paper(); E.beam(300, 450, 1620, 450, 10, 1); pill('STARTS AT A FEW WATTS', 860, lt, 0.3, 54, false); });
  sh('S19d', Wc('boosts', 18), 'five stages', (lt) => { R.paper(); for (let i = 0; i < 5; i++) { const on = seg(lt, 0.2 + i * 0.45, 0.6 + i * 0.45); wRect(250 + i * 280, 330, 190, 260, 24, on > 0 ? C.grayLight : C.paperLine, { seed: 850 + i, lw: 8 }); E.beam(150 + i * 280, 460, 250 + i * 280, 460, 10 + i * 8, on); } pill('10,000x BIGGER IN FIVE STAGES', 860, lt, 0.3, 48, true); });
  sh('S20', A(19), 'hit twice, 50,000 times', (lt) => { dark(); E.droplet(lerp(500, 1400, (lt * 0.7) % 1), 470, 72, 0, true); big('x2', 960, 250, 120, C.white); pill('HIT TWICE, 50,000 TIMES A SECOND', 850, lt, 0.3, 46, false); });
  hostShot('S20b', Wc('payoff', 19), 'host: fresh light', 'LIGHT MADE FRESH, ONE BLAST AT A TIME', { x: 640, px: 1260, size: 38, pose: point });

  // ═════════ 4 · THE PERFECT MIRRORS ═════════
  sh('S21', A(20), 'collector mirror', (lt) => { dark(); E.collector(520, 470, 560, 230); for (let i = 0; i < 7; i++) { const a = -0.9 + i * 0.3; line([[1000, 470], [1000 - Math.cos(a) * 330, 470 + Math.sin(a) * 330]], C.yellow, 10); } E.plasma(1030, 470, 0.7, 1, lt * 0.5); pill('THE COLLECTOR MIRROR', 880, lt, 0.3, 50, false); }, { chap: [4, 'THE PERFECT MIRRORS'] });
  sh('S21b', Wc('bundles', 20), 'bundled beam', (lt) => { dark(); E.collector(420, 470, 560, 230); E.plasma(700, 470, 0.5, 1, lt * 0.5); poly([[430, 270], [1500, 420], [1500, 520], [430, 670]], 'rgba(255,210,63,0.55)', { seed: 860, wob: 1, lw: 6 }); pill('BUNDLES IT TOWARD THE MACHINE', 880, lt, 0.3, 48, false); });
  sh('S22', A(21), 'not bathroom mirrors', (lt) => { R.paper(); E.mirror(960, 450, 240); pill('NOT A BATHROOM MIRROR', 860, lt, 0.3, 54, false); });
  sh('S22b', Wc('built', 21), 'layers', (lt) => { R.paper(); E.layers(960, 220, 900, 16, 34); pill('UP TO ABOUT 100 THIN LAYERS', 880, lt, 0.3, 50, false); }, { zoom: 0.02 });
  sh('S22c', Wc('molybdenum', 21), 'two materials', (lt) => { R.paper(); E.layers(960, 220, 700, 16, 34); pillAt('MOLYBDENUM', 360, 480, lt, 0.2, 40); pillAt('SILICON', 1560, 480, lt, 0.9, 40); }, { zoom: 0.02 });

  sh('S23', A(22), 'interference', (lt) => { R.paper(); E.layers(960, 330, 800, 12, 30, { rays: eo(seg(lt, 0.2, 2.4)) }); pill('THE LAYERS WORK BY WAVE INTERFERENCE', 880, lt, 0.3, 44, false); }, { zoom: 0.02 });
  sh('S23b', Wc('seventy', 22), '70 percent', (lt) => { R.paper(); big('~70%', 960, 400, 400); pill('OF THE LIGHT BOUNCES BACK', 760, lt, 0.4, 52, false); });
  sh('S23c', Wc('sounds', 22), 'lose 30', (lt) => { R.paper(); big('-30%', 960, 400, 400, C.red); pill('EVERY BOUNCE LOSES SOME', 760, lt, 0.4, 52, false); });
  sh('S23d', Wc('source', 22), 'powerful source', (lt) => { dark(); E.plasma(960, 450, 1.5, 1, lt * 0.5); pill('SO THE SOURCE MUST BE POWERFUL', 850, lt, 0.3, 50, false); });

  sh('S24', A(23), 'the surface', (lt) => { R.paper(); E.mirror(960, 450, 240); pill('AND THE SURFACE?', 860, lt, 0.3, 56, false); });
  sh('S24b', Wc('polished', 23), 'less than one atom', (lt) => { R.paper(); wRect(200, 520, 1520, 80, 8, E.SILI, { seed: 870, lw: 8 }); for (let i = 0; i < 12; i++) circle(280 + i * 120, 480, 42, i === 5 ? C.orange : E.TIN_D); pill('SMOOTH TO LESS THAN ONE ATOM', 860, lt, 0.3, 50, false); });
  sh('S24c', Wc('zeiss', 23), 'most precise', (lt) => { R.paper(); E.mirror(960, 450, 240); K.check(1300, 330, 0.5, pop(lt, 0.5)); pill('AMONG THE MOST PRECISE SURFACES EVER MADE', 860, lt, 0.3, 40, false); });

  sh('S25', A(24), 'aim at the Moon', (lt) => { R.space(0, false); E.mirror(420, 540, 190); M.moon(1500, 330, 130); line([[500, 540], [1380, 360]], C.red, 10); pill('AIM A LASER AT THE MOON', 850, lt, 0.3, 50, false); });
  sh('S25b', Wc('golf', 24), 'golf ball', (lt) => { R.space(0, false); M.moon(960, 430, 300); circle(1100, 400, 24, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); pill('HIT A GOLF BALL', 850, lt, 0.3, 56, false); });
  hostShot('S25c', Wc('payoff', 24), 'host: perfect mirrors', 'ALMOST PERFECT MIRRORS', { x: 640, px: 1260, pose: point });

  // ═════════ 5 · PRINTING THE CHIP ═════════
  sh('S26', A(25), 'pattern to wafer', (lt) => { dark(); E.mask(560, 450, 0.9); E.beam(760, 450, 1160, 450, 30, 1, C.yellow); E.wafer(1380, 450, 190, { coat: E.COAT }); pill('THE PATTERN HEADS TO THE WAFER', 850, lt, 0.3, 46, false); }, { chap: [5, 'PRINTING THE CHIP'] });
  sh('S26b', Wc('mirrors', 25), 'shrunk', (lt) => { dark(); const s = lerp(0.9, 0.25, eo(seg(lt, 0.3, 2.2))); E.mask(960, 450, s); pill('THE MIRRORS SHRINK IT DOWN', 850, lt, 0.3, 50, false); });
  sh('S27', A(26), 'coating changes', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT, pat: eo(seg(lt, 0.2, 2.5)) }); pill('WHERE LIGHT LANDS, IT CHANGES', 860, lt, 0.3, 50, false); });
  sh('S27b', Wc('chemicals', 26), 'wash away', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT, pat: 1, patColor: '#F3F0EA' }); pill('CHEMICALS WASH PART AWAY', 860, lt, 0.3, 52, false); });
  sh('S27c', Wc('exposed', 26), 'etched', (lt) => { R.paper(); E.wafer(960, 470, 250, { coat: E.COAT, pat: 1, patColor: E.SILI }); pill('THE EXPOSED PARTS ARE ETCHED', 860, lt, 0.3, 50, true); });
  sh('S28', A(27), 'again across the disc', (lt) => { R.paper(); E.wafer(960, 470, 260, { dies: 7, hi: Math.floor(lt * 1.6) % 30 }); pill('AGAIN, ACROSS THE WHOLE DISC', 860, lt, 0.3, 50, false); });
  sh('S28b', Wc('first', 27), '2006 prototype', (lt) => { R.paper(); K.clock(960, 440, 1.6, lt * 3); pill('2006 PROTOTYPE: 23 HOURS PER WAFER', 860, lt, 0.3, 46, false); });
  sh('S29', A(28), 'it led somewhere', (lt) => { R.paper(); K.chip(960, 440, 1.8); pill('BUT IT LED SOMEWHERE', 860, lt, 0.3, 54, false); });
  sh('S29a', Wc('production', 28), '2019', (lt) => { R.paper(); big('2019', 960, 400, 400); pill('PRODUCTION BEGAN', 760, lt, 0.4, 56, false); });
  sh('S29b', Wc('three', 28), '300 billion', (lt) => { R.paper(); big('300 billion', 960, 380, 260); pill('TRANSISTORS IN A TOP GRAPHICS CHIP', 740, lt, 0.4, 46, false); });
  sh('S29c', Wc('seventy', 28), '1970', (lt) => { R.paper(); big('~1,000', 960, 380, 360); pill('A CHIP IN 1970', 740, lt, 0.4, 54, false); });

  // ═════════ 6 · HIGH-NA ═════════
  hostShot('S30', A(29), 'host: the news', 'HIGH-NA: THE NEWS', { chap: [6, 'HIGH-NA'], pose: point });
  sh('S30b', Wc('today', 29), '0.33', (lt) => { R.paper(); big('0.33', 960, 380, 380); pill("TODAY'S MACHINES: NUMERICAL APERTURE", 740, lt, 0.4, 44, false); });
  sh('S31', A(30), '0.55', (lt) => { R.paper(); big('0.55', 960, 380, 380); pill('HIGH-NA MACHINES', 740, lt, 0.4, 54, false); });
  sh('S31b', Wc('print', 30), 'features 40% smaller', (lt) => chart([{ h: 420, lab: 'TODAY', at: 0 }, { h: 250, lab: 'HIGH-NA', hi: true, pill: 'ABOUT 40% SMALLER', at: 0.4 }], lt, 800, 240));
  sh('S32', A(31), 'a million wafers', (lt) => { R.paper(); big('1,000,000+', 960, 380, 300); pill('WAFERS PROCESSED, INTEL SAYS', 740, lt, 0.4, 48, false); });
  sh('S32b', Wc('reports', 31), 'Panther Lake', (lt) => { R.paper(); K.chip(960, 440, 1.8); pill('INTEL PANTHER LAKE (REPORTED)', 860, lt, 0.3, 50, false); });
  sh('S32c', Wc('first', 31), 'first logic', (lt) => { R.paper(); K.chip(960, 440, 1.8); K.check(1320, 330, 0.5, pop(lt, 0.3)); pill('FIRST LOGIC CHIPS IN HIGH VOLUME', 860, lt, 0.3, 48, false); });
  hostShot('S33', A(32), 'host: the price', 'THE PRICE?', { pose: shrug, q: 1, hi: false });
  sh('S33b', Wc('between', 32), '370-400M', (lt) => { R.paper(); big('$370-400M', 960, 380, 280); pill('PER HIGH-NA MACHINE (REPORTS)', 740, lt, 0.4, 48, false); });
  sh('S33c', Wc('roughly', 32), 'twice standard', (lt) => chart([{ h: 220, lab: 'STANDARD EUV', at: 0, pill: '~$200M' }, { h: 420, lab: 'HIGH-NA', hi: true, at: 0.5, pill: 'ROUGHLY TWICE' }], lt, 800, 240));
  sh('S34', A(33), 'TSMC 2030', (lt) => { R.paper(); big('2030', 960, 380, 400); pill('TSMC: HIGH-NA FROM THEN', 740, lt, 0.4, 52, false); });
  sh('S34b', Wc('samsung', 33), 'memory 2028', (lt) => { R.paper(); big('2028', 960, 380, 400); pill('SAMSUNG + SK HYNIX: MEMORY', 740, lt, 0.4, 50, false); });
  hostShot('S35', A(34), 'host: race', "THE RACE ISN'T OVER", { x: 640, px: 1260, pose: point });
  sh('S35b', Wc('just', 34), 'more expensive', (lt) => { R.paper(); K.coin(960, 440, 1.9, '$'); pill('JUST MORE EXPENSIVE', 860, lt, 0.3, 54, false); });

  // ═════════ 7 · ONLY ONE ═════════
  sh('S36', A(35), 'only one', (lt) => { R.paper(); big('1', 960, 400, 560); pill('ONLY ONE', 860, lt, 0.3, 56, false); }, { chap: [7, 'ONLY ONE'] });
  sh('S36a', Wc('company', 35), 'one company', (lt) => { R.paper(); E.machine(960, 480, 1.5, true); pill('ONE COMPANY MAKES THEM', 860, lt, 0.3, 52, false); });
  sh('S36b', Wc('netherlands', 35), 'netherlands', (lt) => { R.paper(); E.machine(960, 480, 1.5, false); pill('A S M L, THE NETHERLANDS', 860, lt, 0.3, 54, true); });
  sh('S36c', Wc('began', 35), '1984', (lt) => { R.paper(); big('1984', 960, 380, 400); pill('A JOINT VENTURE WITH PHILIPS', 740, lt, 0.4, 50, false); });
  sh('S37', A(36), '180 tons', (lt) => { R.paper(); big('~180 tons', 960, 380, 300); pill('ONE MACHINE', 740, lt, 0.4, 54, false); });
  sh('S37b', Wc('three', 36), 'three 747s', (lt) => { R.paper(); G.jet(660, 400, 1.0, 0); G.jet(1260, 400, 1.0, 0); G.jet(960, 600, 1.0, 0); pill('THREE BOEING 747s TO MOVE IT', 860, lt, 0.3, 48, false); });
  sh('S38', A(37), 'zeiss mirrors', (lt) => { R.paper(); E.mirror(960, 450, 230); pill('ZEISS: THE MIRRORS', 860, lt, 0.3, 54, false); });
  sh('S38b', Wc('trumpf', 37), 'trumpf laser', (lt) => { R.paper(); wRect(560, 330, 800, 260, 40, C.grayLight, { seed: 840, lw: 9 }); E.beam(1360, 460, 1760, 460, 30, 1); pill('TRUMPF: THE LASER', 860, lt, 0.3, 54, false); });
  sh('S38c', Wc('puts', 37), 'asml assembles', (lt) => { R.paper(); E.machine(960, 480, 1.5, true); pill('A S M L: PUTS IT ALL TOGETHER', 860, lt, 0.3, 50, true); });
  sh('S39', A(38), 'sold out', (lt) => { R.paper(); big('SOLD OUT', 960, 380, 300); pill('NEARLY, THROUGH 2027', 740, lt, 0.4, 54, false); });
  sh('S39b', Wc('hunger', 38), 'AI chips', (lt) => { R.paper(); K.chip(960, 440, 1.9, C.orange); big('AI', 960, 440, 110, C.white); pill('AI CHIPS: A BIG REASON', 860, lt, 0.3, 52, false); });
  sh('S40', A(39), 'one line one machine', (lt) => { R.paper(); K.phone(300, 560, 0.7, 0, C.white); K.laptop(600, 560, 0.7, C.white); E.machine(1450, 480, 1.0, true); R.arrowV(780, 540, 330, 0); pill('ONE LINE, ONE MACHINE', 860, lt, 0.3, 54, false); });

  // ═════════ RECAP ═════════
  hostShot('S41', A(40), 'host: recap', 'QUICK RECAP', { chap: [8, 'RECAP'] });
  sh('S41b', Wc('finer', 40), 'shorter light', (lt) => { R.paper(); E.wave(300, 470, 1320, 50, 60, C.orange, 14, 1, -lt * 6); pill('1  SHORTER LIGHT, FINER LINES', 860, lt, 0.3, 50, false); });
  sh('S41c', Wc('extreme', 40), '13.5 nm', (lt) => { R.paper(); big('13.5 nm', 960, 400, 340); pill('EXTREME ULTRAVIOLET', 760, lt, 0.4, 52, false); });
  sh('S42', A(41), 'laser hits twice', (lt) => { dark(); E.droplet(1200, 470, 88, 0, true); E.beam(160, 470, 1130, 470, 24, 0.5 + 0.5 * Math.abs(Math.sin(lt * 4)), C.red); pill('2  A LASER HITS A TIN DROP TWICE', 850, lt, 0.3, 48, false); });
  sh('S42b', Wc('fifty', 41), '50,000 per second', (lt) => { dark(); stream(300, 440, 1620, 440, lt, 8, 26, 2.6); big('50,000', 960, 640, 180, C.white); pill('TIMES A SECOND', 850, lt, 0.3, 54, false); });
  sh('S43', A(42), 'near-perfect mirrors', (lt) => { R.paper(); E.mirror(960, 450, 240); pill('3  ALMOST PERFECT MIRRORS', 860, lt, 0.3, 52, false); });
  sh('S43b', Wc('high', 42), 'high-na finer', (lt) => { R.paper(); big('HIGH-NA', 960, 400, 300); pill('EVEN FINER LINES', 760, lt, 0.4, 54, false); });
  sh('S43c', Wc('price', 42), '400M', (lt) => { R.paper(); big('~$400M', 960, 400, 340); pill('PER MACHINE', 760, lt, 0.4, 54, false); });
  sh('S44', A(43), 'phone fast', (lt) => { R.paper(); K.phone(960, 460, 1.35, 0, C.white); pill('YOUR PHONE FEELS FAST', 880, lt, 0.3, 54, false); });
  sh('S44b', Wc('picture', 43), 'drop in the dark', (lt) => { dark(); E.droplet(lerp(400, 1500, (lt * 0.3) % 1), 470, 90, 0, true); pill('A DROP OF TIN, FLYING THROUGH THE DARK', 850, lt, 0.3, 46, false); });
  sh('S45', A(44), 'laser about to hit', (lt) => { dark(); E.droplet(1240, 470, 88, 0, true); E.beam(160, 470, lerp(160, 1180, eo(seg(lt, 0, 1.8))), 470, 30, 1); pill('A LASER IS ABOUT TO HIT IT', 850, lt, 0.3, 52, false); });
  sh('S45b', Wc('twice', 44), 'twice', (lt) => { dark(); E.plasma(960, 470, 1.4, lt < 1.2 ? 1 : 0, lt); big('TWICE', 960, 470, 300, C.white); });
  sh('S45c', Wc('chip', 44), 'how a chip gets made', (lt) => { dark(); K.chip(960, 460, 1.9); pill("THAT'S HOW A CHIP GETS MADE", 850, lt, 0.3, 52, false); });

  return { shots: S, cues: CUES };
}
