// THE MOON IS LEAVING EARTH, AND WE CAN PROVE IT  (long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as G from './core/gps.js';
import * as M from './core/moon.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
function dim(x0, y0, x1, y1, label, sc = 1, size = 40) {
  if (sc <= 0) return; ctx.save(); ctx.globalAlpha = clamp(sc);
  const an = Math.atan2(y1 - y0, x1 - x0), nx = -Math.sin(an) * 18, ny = Math.cos(an) * 18;
  line([[x0, y0], [x1, y1]], C.ink, 5); line([[x0 - nx, y0 - ny], [x0 + nx, y0 + ny]], C.ink, 5); line([[x1 - nx, y1 - ny], [x1 + nx, y1 + ny]], C.ink, 5); ctx.restore();
  if (label) R.pill(label, (x0 + x1) / 2, (y0 + y1) / 2 - 50, size, sc);
}
const big = (txt, x, y, size, color = C.orange) => R.txt(txt, x, y, size, color, 'center', 2);
const space = (t) => R.space(t, false);
// Earth + Moon pair on a navy sky: Earth left, Moon right
function pair(t, o = {}) {
  const { er = 170, mr = 70, ex = 560, mx = 1360, y = 520, tide = null } = o;
  space(t);
  if (tide) M.tideEarth(ex, y, er, { ang: 0, ...tide }); else G.globe(ex, y, er, t * 0.15);
  M.moon(mx, y, mr);
}
const chart = () => { R.paper(); line([[300, 780], [1620, 780]], C.ink, 8); line([[300, 780], [300, 260]], C.ink, 8); };

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;
  const cam = [960, 520];

  // ═════════ HOOK ═════════
  { const st = A(0), ab = Wc('about', 0);
    add({ id: 'S01', at: st, cam, zoom: 0.05, note: 'the Moon is leaving',
      draw(lt, d, t) { space(t); const x = lerp(1100, 1260, eio(seg(lt, 0, 4))); M.moon(x, 520, 230); R.arrowV(x + 280, 520, 200, 0, C.orange, 30); R.pill('THE MOON IS LEAVING', 960, 150, 54, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S01b', at: ab, cam, zoom: 0.04, note: '1.5 inches a year',
      draw(lt, d, t) { R.paper(); big('1.5 in', 960, 430, 300); R.pill('EVERY YEAR', 960, 660, 60, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(1), las = Wc('how', 1), why = Wc('why', 1), days = Wc('days', 1);
    add({ id: 'S02', at: st, cam: [1200, 540], zoom: 0.05, note: 'host: what you get',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('WHAT YOU WILL GET', 700, 450, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S02b', at: las, cam, zoom: 0.04, note: '1 laser proof',
      draw(lt, d, t) { pair(t); M.laser(730, 520, 1290, 520, t, (t * 0.7) % 1); R.pill('1  HOW WE CAUGHT IT', 960, 250, 52, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S02c', at: why, cam, zoom: 0.04, note: '2 why',
      draw(lt, d, t) { space(t); M.tideEarth(960, 520, 190, { ang: 0, b1: 1, b2: 1, rot: t * 0.15 }); R.pill('2  WHY IT HAPPENS', 960, 190, 52, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S02d', at: days, cam, zoom: 0.04, note: '3 days, eclipses, seasons',
      draw(lt, d, t) { R.paper(); K.clock(960, 450, 1.3, lt * 1.2); R.pill('3  DAYS, ECLIPSES, SEASONS', 960, 790, 52, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(2), no = Wc('no', 2), ev = Wc('every', 2);
    add({ id: 'S03', at: st, cam: [1200, 540], zoom: 0.05, note: 'host: dangerous?',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, brow: 0.6 }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('IS IT DANGEROUS?', 700, 450, 52, pop(lt, 0.1)); } });
    add({ id: 'S03b', at: no, cam, zoom: 0.04, note: 'No, too slow',
      draw(lt, d, t) { R.paper(); K.check(960, 450, 1.1, pop(lt, 0.2)); R.pill('NO. TOO SLOW TO NOTICE', 960, 790, 54, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S03c', at: ev, cam, zoom: 0.04, note: 'sources opened',
      draw(lt, d, t) { R.paper(); M.pages(900, 480, 1.2); K.check(1380, 640, 0.6, pop(lt, 0.8)); R.pill('NASA + OTHER PAGES I OPENED', 960, 850, 48, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(3), ind = Wc('india', 3), lets = Wc("let's", 3);
    add({ id: 'S04', at: st, cam, zoom: 0.04, note: 'reflectors still in use',
      draw(lt, d, t) { M.lunarGround(760, t); M.reflector(960, 470, 0.9); R.pill('STILL IN USE TODAY', 960, 190, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S04b', at: ind, cam, zoom: 0.04, note: 'India 2023',
      draw(lt, d, t) { M.lunarGround(760, t); M.reflector(960, 470, 0.9, 1); R.pill('A NEW ONE IN 2023', 960, 190, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S04c', at: lets, cam: [700, 540], zoom: 0.05, note: 'host: the proof',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); R.pill('FIRST: THE PROOF', 1260, 430, 54, pop(lt, 0.4), { hi: true }); } }); }

  // ═════════ 1 · THE LASER PROOF ═════════
  { const st = A(4), pan = Wc('panel', 4), cov = Wc('covered', 4);
    add({ id: 'S05', at: st, cam, zoom: 0.04, chap: [1, 'THE LASER PROOF'], note: 'July 1969 Apollo 11',
      draw(lt, d, t) { M.lunarGround(760, t); M.reflector(960, 470, 0.9); R.pill('JULY 1969  ·  APOLLO 11', 960, 190, 54, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S05b', at: pan, cam, zoom: 0.04, note: '46 cm panel',
      draw(lt, d, t) { M.lunarGround(760, t); M.reflector(960, 470, 0.9); dim(770, 700, 1150, 700, '46 cm', pop(lt, 0.3), 44); } });
    add({ id: 'S05c', at: cov, cam, zoom: 0.04, note: '100 mirrors',
      draw(lt, d, t) { R.paper(); M.reflector(960, 500, 1.15, 1); R.pill('100 LITTLE GLASS MIRRORS', 960, 850, 52, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(5), sends = Wc('sends', 5);
    add({ id: 'S06', at: st, cam, zoom: 0.04, note: 'not normal mirrors: corner cube',
      draw(lt, d, t) { R.paper(); M.cube(960, 470, 1.5); R.pill('A CORNER CUBE', 960, 850, 56, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S06b', at: sends, cam, zoom: 0.04, note: 'light comes straight back',
      draw(lt, d, t) { R.paper(); M.cube(1240, 470, 1.1); const p = (lt * 0.5) % 1; inkLine([[300, 330], [1190, 440]], C.orange, 10, 4); inkLine([[1190, 460], [300, 560]], C.orange, 10, 4); R.pill('LIGHT COMES STRAIGHT BACK', 800, 830, 50, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(6), there = Wc('there', 6);
    add({ id: 'S07', at: st, cam, zoom: 0.04, note: 'fire a laser at the panel',
      draw(lt, d, t) { pair(t, { mr: 70 }); M.laser(740, 520, 1280, 520, t, eio(seg(lt, 0.3, 3.3))); R.pill('FIRE A LASER, TIME THE TRIP', 960, 250, 52, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S07b', at: there, cam, zoom: 0.04, note: 'round trip about 2.5 s',
      draw(lt, d, t) { R.paper(); const n = (2.5 * eo(seg(lt, 0.2, 2.4))).toFixed(1); big(n + ' s', 960, 430, 300); R.pill('THERE AND BACK', 960, 680, 56, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(7), three = Wc('three', 7), only = Wc('only', 7);
    add({ id: 'S08', at: st, cam: [1200, 540], zoom: 0.05, note: 'the catch',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip, brow: 0.6 }); R.pill('HERE IS THE CATCH', 700, 450, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S08b', at: three, cam, zoom: 0.04, note: '300 quadrillion photons sent',
      draw(lt, d, t) { R.paper(); big('300 quadrillion', 960, 430, 190); R.pill('PHOTONS SENT', 960, 650, 56, pop(lt, 0.3)); R.txt('3 × 10^17', 960, 780, 64, C.gray, 'center', 2); } });
    add({ id: 'S08c', at: only, cam, zoom: 0.04, note: 'only 1 to 5 come home',
      draw(lt, d, t) { R.paper(); big('1 to 5', 960, 430, 300); R.pill('COME HOME', 960, 690, 60, pop(lt, 0.3), { hi: true }); K.check(1500, 400, 0.5, pop(lt, 2.0)); } }); }
  { const st = A(8), mm = Wc('down', 8), keep = Wc('keep', 8), three = Wc('three', 8);
    add({ id: 'S09', at: st, cam, zoom: 0.04, note: 'time gives distance',
      draw(lt, d, t) { R.paper(); K.clock(640, 470, 1.1, lt * 0.8); R.arrowV(960, 470, 260, PI * 0.5 - PI * 0.5, C.ink, 22); line([[1100, 560], [1700, 560]], C.ink, 10); line([[1100, 520], [1100, 600]], C.ink, 8); line([[1700, 520], [1700, 600]], C.ink, 8); R.pill('TIME  =  DISTANCE', 960, 250, 56, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S09b', at: mm, cam, zoom: 0.04, note: 'about a millimeter',
      draw(lt, d, t) { R.paper(); big('1 mm', 960, 430, 300); R.pill('PRECISION TODAY', 960, 660, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S09c', at: keep, cam, zoom: 0.04, note: 'the gap grows every year',
      draw(lt, d, t) { chart(); const p = eio(seg(lt, 0.3, d - 0.4)); line([[340, 700], [lerp(340, 1560, p), lerp(700, 420, p)]], C.orange, 14); R.pill('YEARS OF MEASURING', 960, 850, 44, pop(lt, 0.3)); R.pill('THE GAP KEEPS GROWING', 960, 230, 50, pop(lt, 1.0), { hi: true }); } });
    add({ id: 'S09d', at: three, cam, zoom: 0.04, note: '3.8 cm a year',
      draw(lt, d, t) { R.paper(); big('3.8 cm', 960, 430, 300); R.pill('EVERY YEAR', 960, 660, 60, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S10', at: A(9), cam: [1200, 540], zoom: 0.05, note: 'proof, but why',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('BUT WHY IS IT LEAVING?', 700, 450, 48, pop(lt, 0.2)); } });

  // ═════════ 2 · THE TIDE TRICK ═════════
  add({ id: 'S11', at: A(10), cam, zoom: 0.04, chap: [2, 'THE TIDE TRICK'], note: 'blame the ocean',
    draw(lt, d, t) { R.sky(t); R.sea(700, t); R.surf(760, t); R.pill('BLAME THE OCEAN', 960, 300, 64, pop(lt, 0.4), { hi: true }); } });
  { const st = A(11), far = Wc('far', 11), two = Wc('two', 11);
    add({ id: 'S12', at: st, cam, zoom: 0.04, note: 'near side pulled toward the Moon',
      draw(lt, d, t) { space(t); M.tideEarth(620, 540, 210, { ang: 0, b1: eo(seg(lt, 0.3, 1.5)), b2: 0, rot: t * 0.1 }); M.moon(1500, 540, 80); R.pill('NEAR SIDE: PULLED TOWARD THE MOON', 960, 200, 46, pop(lt, 0.3)); } });
    add({ id: 'S12b', at: far, cam, zoom: 0.04, note: 'far side left behind',
      draw(lt, d, t) { space(t); M.tideEarth(620, 540, 210, { ang: 0, b1: 1, b2: eo(seg(lt, 0.3, 1.5)), rot: t * 0.1 }); M.moon(1500, 540, 80); R.pill('FAR SIDE: LEFT BEHIND', 960, 200, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S12c', at: two, cam, zoom: 0.04, note: 'two bulges lined up with the Moon',
      draw(lt, d, t) { space(t); M.tideEarth(620, 540, 210, { ang: 0, b1: 1, b2: 1, rot: t * 0.1 }); M.moon(1500, 540, 80); R.pill('TWO BULGES, LINED UP WITH THE MOON', 960, 200, 46, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(12), earth = Wc('faster', 12), fr = Wc('friction', 12);
    add({ id: 'S13', at: st, cam: [700, 540], zoom: 0.05, note: 'host: twist',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); R.pill('NOW, THE TWIST', 1260, 430, 56, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S13b', at: earth, cam, zoom: 0.04, note: 'Earth spins fast, Moon slow',
      draw(lt, d, t) { space(t); M.tideEarth(620, 540, 210, { ang: 0, b1: 1, b2: 1, rot: t * 1.2 }); M.spin(620, 540, 290, 1.15, 1.9); M.moon(1500, 540, 80); R.pill('EARTH SPINS MUCH FASTER', 960, 190, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S13c', at: fr, cam, zoom: 0.04, note: 'bulges carried ahead of the Moon',
      draw(lt, d, t) { space(t); const sh = lerp(0, 0.45, eo(seg(lt, 0.2, 1.6))); M.tideEarth(620, 540, 210, { ang: 0, b1: 1, b2: 1, shift: sh, rot: t * 0.4, bulge: 0.9 }); M.moon(1500, 540, 80); R.pill('BULGES CARRIED AHEAD OF THE MOON', 960, 190, 46, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(13), tug = Wc('tugs', 13), fast = Wc('faster', 13), get = Wc('orbit', 13);
    const sc = (t, lt) => { space(t); M.tideEarth(620, 540, 210, { ang: 0, b1: 1, b2: 1, shift: 0.45, rot: t * 0.3, bulge: 0.9 }); };
    add({ id: 'S14', at: st, cam, zoom: 0.04, note: 'a bulge has gravity',
      draw(lt, d, t) { sc(t, lt); M.moon(1500, 540, 80); R.pill('A BULGE IS LOTS OF WATER: IT HAS GRAVITY', 960, 190, 44, pop(lt, 0.3)); } });
    add({ id: 'S14b', at: tug, cam, zoom: 0.04, note: 'it tugs the Moon forward',
      draw(lt, d, t) { sc(t, lt); M.moon(1500, 540, 80); R.arrowV(1180, 470, 220, PI * 0.5 - PI * 0.5 + 0.15, C.orange, 30); R.pill('A TUG FORWARD', 960, 190, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S14c', at: fast, cam, zoom: 0.04, note: 'faster Moon, higher orbit',
      draw(lt, d, t) { space(t); G.globe(960, 560, 150, t * 0.1); const r1 = 300, r2 = lerp(300, 400, eo(seg(lt, 0.4, d - 0.2))); ctx.save(); ctx.setLineDash([16, 14]); ctx.beginPath(); ctx.arc(960, 560, r1, 0, TAU); ctx.lineWidth = 5; ctx.strokeStyle = C.white; ctx.stroke(); ctx.beginPath(); ctx.arc(960, 560, 400, 0, TAU); ctx.stroke(); ctx.restore(); const a = -0.6 + lt * 0.35; M.moon(960 + Math.cos(a) * r2, 560 + Math.sin(a) * r2, 60); R.pill('FASTER MOON, HIGHER ORBIT', 960, 130, 48, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S14d', at: get, cam, zoom: 0.04, note: 'the getaway',
      draw(lt, d, t) { space(t); G.globe(520, 520, 150, t * 0.15); const p = eo(seg(lt, 0.2, 2.2)); M.moon(lerp(1200, 1450, p), 520, 60); R.arrowV(1590, 380, 160, 0, C.orange, 28); R.pill('THE GETAWAY', 960, 220, 60, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(14), drag = Wc('drag', 14), heat = Wc('heat', 14), only = Wc('only', 14);
    add({ id: 'S15', at: st, cam, zoom: 0.04, note: 'Earth pays',
      draw(lt, d, t) { space(t); G.globe(960, 520, 230, t * 0.5); R.pill('EARTH PAYS FOR IT', 960, 190, 58, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S15b', at: drag, cam, zoom: 0.04, note: 'slower spin',
      draw(lt, d, t) { space(t); G.globe(960, 520, 230, t * 0.5 * Math.max(0.15, 1 - lt * 0.4)); M.spin(960, 520, 330, 1.15, 1.9); R.pill('THE DRAG SLOWS OUR SPIN', 960, 190, 52, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S15c', at: heat, cam, zoom: 0.04, note: 'energy turns into heat in shallow seas',
      draw(lt, d, t) { R.sky(t); R.sea(640, t); R.surf(700, t); for (let i = 0; i < 4; i++) { const x = 560 + i * 270, y = 560 - ((t * 60 + i * 50) % 160); ctx.save(); ctx.globalAlpha = 1 - ((t * 60 + i * 50) % 160) / 160; line([[x, y], [x + 20, y - 30], [x - 10, y - 60], [x + 15, y - 90]], C.orange, 12); ctx.restore(); } R.pill('MOSTLY HEAT, IN SHALLOW SEAS', 960, 220, 52, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S15d', at: only, cam, zoom: 0.04, note: 'one thirtieth goes to the Moon',
      draw(lt, d, t) { R.paper(); R.pie(620, 520, 250, [{ v: 29 / 30, color: C.grayLight }, { v: 1 / 30, color: C.orange }], eo(seg(lt, 0, 0.8)), 1); R.pill('ABOUT 1/30 GOES TO THE MOON', 1400, 420, 44, pop(lt, 0.5), { hi: true }); R.pill('THE REST: HEAT', 1400, 540, 44, pop(lt, 1.2)); } }); }
  { const st = A(15), ea = Wc('earth', 15);
    add({ id: 'S16', at: st, cam, zoom: 0.04, note: 'high tide 50 min later',
      draw(lt, d, t) { R.sky(t); R.sea(640, t); R.surf(700, t); R.pill('HIGH TIDE: ABOUT 50 MIN LATER EACH DAY', 960, 260, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S16b', at: ea, cam, zoom: 0.04, note: 'Earth has to catch up with the Moon',
      draw(lt, d, t) { space(t); G.globe(620, 520, 190, t * 0.6); M.moon(1360, 520, 70); M.spin(620, 520, 270, 1.15, 1.9); R.pill('EARTH TURNS EXTRA TO CATCH UP', 960, 190, 48, pop(lt, 0.3), { hi: true }); } }); }

  // ═════════ 3 · RUN IT BACKWARDS ═════════
  { const st = A(16), used = Wc('used', 16);
    add({ id: 'S17', at: st, cam: [700, 540], zoom: 0.05, chap: [3, 'RUN IT BACKWARDS'], note: 'rewind',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'talk' }); K.clock(1260, 470, 1.0, -lt * 2); R.pill('RUN THE MOVIE BACKWARDS', 1260, 700, 48, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S17b', at: used, cam, zoom: 0.04, note: 'used to be closer',
      draw(lt, d, t) { pair(t, { ex: 620, mx: lerp(1360, 1000, eo(seg(lt, 0.3, 2.0))) }); R.pill('MUCH CLOSER', 960, 200, 60, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(17), sm = Wc('smashed', 17);
    add({ id: 'S18', at: st, cam, zoom: 0.04, note: '4.5 billion years ago, a Mars-sized planet',
      draw(lt, d, t) { space(t); G.globe(960, 560, 200, t * 0.1); circle(1560, 330, 70, C.orange); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('4.5 BILLION YEARS AGO', 960, 190, 54, pop(lt, 0.3)); R.pill('THEIA', 1560, 460, 42, pop(lt, 2.6), { hi: true }); } });
    add({ id: 'S18b', at: sm, cam, zoom: 0.04, note: 'Theia hits Earth',
      draw(lt, d, t) { space(t); G.globe(1100, 560, 200, t * 0.1); const p = eo(seg(lt, 0.1, 1.0)); const x = lerp(520, 930, p), y = lerp(260, 470, p); circle(x, y, 70, C.orange); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); if (p > 0.95 && lt < 2.4) K.burst(950, 480, 1.0, pop(lt, 1.0), C.yellow, 0.2); for (let i = 0; i < 12; i++) { const a = i / 12 * TAU + t * 0.5, rr = lerp(60, 420, eo(seg(lt, 1.2, 3.0))); circle(1100 + Math.cos(a) * rr * 0.9, 560 + Math.sin(a) * rr * 0.5, 9 + (i % 3) * 5, M.CRATER); } if (lt > 3.2) M.moon(1620, 380, lerp(20, 70, eo(seg(lt, 3.2, 4.4)))); R.pill(lt < 3.2 ? 'A MARS-SIZED PLANET HITS EARTH' : 'THE DEBRIS BECOMES THE MOON', 960, 190, 46, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(18), pic = Wc('picture', 18);
    add({ id: 'S19', at: st, cam, zoom: 0.04, note: '1/10 of today distance',
      draw(lt, d, t) { space(t); G.globe(560, 520, 170, t * 0.2); M.moon(1000, 520, 70); dim(560 + 170, 800, 1000 - 70, 800, 'ONE TENTH', pop(lt, 0.5), 44); R.pill('ABOUT 1/10 OF TODAY\'S DISTANCE', 960, 190, 46, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S19b', at: pic, cam, zoom: 0.03, note: 'a sky full of Moon',
      draw(lt, d, t) { space(t); M.moon(1100, 780, 520); ctx.beginPath(); ctx.moveTo(-50, 860); ctx.bezierCurveTo(500, 800, 1200, 880, 1980, 830); ctx.lineTo(1980, 1100); ctx.lineTo(-50, 1100); ctx.fillStyle = '#161F30'; ctx.fill(); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('A SKY FULL OF MOON', 560, 300, 56, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(19), im = Wc('imagine', 19);
    add({ id: 'S20', at: st, cam, zoom: 0.04, note: 'day under 10 hours',
      draw(lt, d, t) { R.paper(); big('< 10 h', 960, 430, 300); R.pill('THE LENGTH OF A DAY, BACK THEN', 960, 680, 50, pop(lt, 0.4)); } });
    add({ id: 'S20b', at: im, cam: [1200, 540], zoom: 0.05, note: 'host: a day before lunch',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip, mouth: 'grin' }); R.pill('A WHOLE DAY BEFORE LUNCH', 700, 450, 50, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(20), six = Wc('six', 20), cl = Wc('clam', 20), th = Wc('three', 20);
    add({ id: 'S21', at: st, cam, zoom: 0.04, note: 'rocks and fossils',
      draw(lt, d, t) { R.paper(); M.layers(960, 250, 760, 6, 2); R.pill('ROCKS AND FOSSILS BACK IT UP', 960, 850, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S21b', at: six, cam, zoom: 0.04, note: '620 million years ago ~22 h day',
      draw(lt, d, t) { R.paper(); big('22 h', 960, 430, 300); R.pill('620 MILLION YEARS AGO', 960, 660, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S21c', at: cl, cam, zoom: 0.04, note: 'a clam 70 million years ago',
      draw(lt, d, t) { R.paper(); M.clam(960, 440, 1.5); R.pill('A CLAM FROM 70 MILLION YEARS AGO', 960, 850, 48, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S21d', at: th, cam, zoom: 0.04, note: '372 days a year',
      draw(lt, d, t) { R.paper(); big('372', 960, 430, 300); R.pill('DAYS IN ITS YEAR', 960, 660, 56, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(21), one = Wc('one', 21), stuck = Wc('stuck', 21), sun = Wc("sun's", 21);
    add({ id: 'S22', at: st, cam: [700, 540], zoom: 0.05, note: 'host: twist, not steady',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); R.pill('NOT A STEADY SLIDE', 1260, 430, 54, pop(lt, 0.5), { hi: true }); } });
    const day = (p, hi) => { chart(); const pts = [[340, 720], [560, 560], [760, 470], [1240, 470], [1500, 400]]; const n = pts.length; for (let i = 0; i < n - 1; i++) { if (p <= i / (n - 1)) break; const q = clamp((p - i / (n - 1)) * (n - 1)); const [a, b] = [pts[i], pts[i + 1]]; line([a, [lerp(a[0], b[0], q), lerp(a[1], b[1], q)]], hi && i === 2 ? C.orange : C.ink, hi && i === 2 ? 18 : 12); } R.txt('PAST', 340, 840, 36, C.gray, 'center', 2); R.txt('NOW', 1560, 840, 36, C.gray, 'center', 2); R.txt('DAY LENGTH', 300, 220, 36, C.gray, 'center', 2); };
    add({ id: 'S22b', at: one, cam, zoom: 0.04, note: '2023 study chart',
      draw(lt, d, t) { day(eo(seg(lt, 0.2, 3.5)), false); R.pill('A 2023 STUDY', 960, 200, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S22c', at: stuck, cam, zoom: 0.04, note: 'stuck near 19.5 h',
      draw(lt, d, t) { day(1, true); R.pill('STUCK NEAR 19.5 HOURS', 960, 350, 52, pop(lt, 0.3), { hi: true }); R.pill('FOR OVER A BILLION YEARS', 960, 940 - 80, 40, pop(lt, 1.0)); } });
    add({ id: 'S22d', at: sun, cam, zoom: 0.04, note: 'the Sun tides in the air pushed back',
      draw(lt, d, t) { space(t); M.sun(300, 520, 110); circle(1000, 520, 260, '#BAD7EC'); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); G.globe(1000, 520, 200, t * 0.2); R.arrowV(640, 520, 160, PI * 0.5 - PI * 0.5 + 0, C.orange, 28); M.moon(1620, 520, 70); R.pill("THE SUN'S AIR TIDES PUSH BACK", 960, 190, 48, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(22), sixty = Wc('sixty', 22);
    add({ id: 'S23', at: st, cam, zoom: 0.04, note: 'still being tested',
      draw(lt, d, t) { R.paper(); K.mark('?', 960, 420, 1.6 * pop(lt, 0.2, 0.4), 0); R.pill('STILL BEING TESTED', 960, 790, 56, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S23b', at: sixty, cam, zoom: 0.04, note: 'without the pause: 60+ hours',
      draw(lt, d, t) { R.paper(); big('60+ h', 960, 430, 300); R.pill('WITHOUT THE PAUSE, THE DAY COULD BE', 960, 680, 46, pop(lt, 0.3)); } }); }

  // ═════════ 4 · AND NOW? ═════════
  { const st = A(23), one = Wc('one', 23);
    add({ id: 'S24', at: st, cam: [700, 540], zoom: 0.05, chap: [4, 'AND NOW?'], note: 'host: what about now',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('SO, WHAT ABOUT NOW?', 1260, 430, 54, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S24b', at: one, cam, zoom: 0.04, note: '1.7 ms per century',
      draw(lt, d, t) { R.paper(); big('1.7 ms', 960, 430, 300); R.pill('LONGER EVERY 100 YEARS', 960, 660, 54, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(24), keep = Wc('keep', 24), th = Wc("that's", 24);
    add({ id: 'S25', at: st, cam: [1200, 540], zoom: 0.05, note: 'you will never feel that',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill("YOU WON'T FEEL IT", 700, 450, 54, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S25b', at: keep, cam, zoom: 0.04, note: 'a million years: +17 s',
      draw(lt, d, t) { R.paper(); big('+17 s', 960, 430, 300); R.pill('AFTER A MILLION YEARS', 960, 660, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S25c', at: th, cam, zoom: 0.04, note: 'my own arithmetic',
      draw(lt, d, t) { R.paper(); R.txt('1.7 ms × 10,000 centuries', 960, 450, 90, C.ink, 'center', 2); R.pill('MY OWN ARITHMETIC: APPROXIMATE', 960, 700, 48, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(25), tiny = Wc('tiny', 25);
    add({ id: 'S26', at: st, cam, zoom: 0.04, note: 'two meters since 1969',
      draw(lt, d, t) { R.paper(); big('~2 m', 960, 430, 300); R.pill('SINCE THE MIRRORS WERE LEFT IN 1969', 960, 680, 46, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S26b', at: tiny, cam: [700, 540], zoom: 0.05, note: 'tiny numbers, huge timescales',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); R.pill('TINY NUMBERS, HUGE TIMESCALES', 1260, 430, 48, pop(lt, 0.4), { hi: true }); } }); }

  // ═════════ 5 · THE END OF TOTAL ECLIPSES ═════════
  { const st = A(26), bec = Wc('because', 26);
    add({ id: 'S27', at: st, cam, zoom: 0.04, chap: [5, 'THE END OF ECLIPSES'], note: 'a lucky era: total eclipse',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 480, 200, 210, 0); R.pill('YOU LIVE IN A LUCKY ERA', 960, 850, 52, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S27b', at: bec, cam, zoom: 0.04, note: 'Sun and Moon look the same size',
      draw(lt, d, t) { R.paper(); circle(660, 470, 190, C.yellow); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke(); circle(1260, 470, 190, '#2A3040'); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('SUN', 660, 730, 44); R.pill('MOON', 1260, 730, 44); R.pill('ALMOST THE SAME SIZE IN OUR SKY', 960, 190, 50, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(27), but = Wc('but', 27), wait = Wc('wait', 27);
    add({ id: 'S28', at: st, cam, zoom: 0.04, note: 'on average 2% smaller',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 480, 210, 188, 0, { corona: false }); R.pill('ON AVERAGE: ABOUT 2% SMALLER', 960, 850, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S28b', at: but, cam, zoom: 0.04, note: 'closest point: total',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 480, 200, 216, 0); R.pill('CLOSEST POINT: A TOTAL ECLIPSE', 960, 850, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S28c', at: wait, cam, zoom: 0.04, note: 'farther: a ring',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 480, 210, 176, 0, { corona: false }); R.pill('A BIT FARTHER: A BRIGHT RING', 960, 850, 50, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(28), now = Wc('now', 28), fade = Wc('shrinks', 28);
    add({ id: 'S29', at: st, cam, zoom: 0.04, note: '60 percent ring-shaped',
      draw(lt, d, t) { R.paper(); R.pie(620, 520, 250, [{ v: 0.6, color: C.orange }, { v: 0.4, color: C.grayLight }], eo(seg(lt, 0, 0.8)), 0); R.pill('ABOUT 60% ARE ALREADY RINGS', 1400, 440, 44, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S29b', at: now, cam, zoom: 0.04, note: 'push the Moon away, it shrinks',
      draw(lt, d, t) { R.paper(); const p = eo(seg(lt, 0.3, 3.0)); circle(960, 470, 200, C.yellow); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke(); circle(960, 470, lerp(216, 120, p), '#2A3040'); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('FARTHER MOON, SMALLER MOON', 960, 850, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S29c', at: fade, cam, zoom: 0.04, note: 'total eclipses fade out',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 480, 210, 140, 0, { corona: false }); R.pill('TOTAL ECLIPSES FADE OUT', 960, 850, 54, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(29), bet = Wc('between', 29);
    add({ id: 'S30', at: st, cam, zoom: 0.04, note: 'estimates for the last total eclipse',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 450, 190, 200, 0); R.pill('ESTIMATES FOR THE LAST TOTAL ECLIPSE', 960, 800, 46, pop(lt, 0.4)); } });
    add({ id: 'S30b', at: bet, cam, zoom: 0.04, note: '650 million to 1.4 billion years',
      draw(lt, d, t) { R.paper(); line([[360, 520], [1560, 520]], C.ink, 10); const a = eo(seg(lt, 0.2, 1.4)); wRect(560, 470, lerp(0, 760, a), 100, 14, C.orange, { seed: 7, lw: 8 }); R.pill('650 MILLION', 560, 660, 44, pop(lt, 0.3)); R.pill('1.4 BILLION YEARS', 1320, 660, 44, pop(lt, 1.2)); R.pill('FROM NOW', 960, 280, 56, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(30), rem = Wc('remember', 30);
    add({ id: 'S31', at: st, cam, zoom: 0.04, note: 'standing in the shadow of a total eclipse',
      draw(lt, d, t) { R.paper(); M.eclipse(960, 450, 190, 200, 0); R.pill('A SHOW WITH AN END DATE', 960, 800, 54, pop(lt, 1.5), { hi: true }); } }); }

  // ═════════ 6 · DOES IT MATTER? ═════════
  { const st = A(31), tilt = Wc('helps', 31), ea = Wc('earth', 31), forty = Wc('forty', 31);
    add({ id: 'S32', at: st, cam: [700, 540], zoom: 0.05, chap: [6, 'MORE THAN ECLIPSES?'], note: 'host: anything else',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('ANYTHING ELSE?', 1260, 430, 56, pop(lt, 0.4), { hi: true }); } });
    const tiltE = (a, ghost) => { space(0); ctx.save(); ctx.translate(960, 540); ctx.rotate(a); line([[0, -300], [0, 300]], C.white, 8); G.globe(0, 0, 210, 0); line([[0, -330], [0, -230]], C.orange, 14); ctx.restore(); };
    add({ id: 'S32b', at: tilt, cam, zoom: 0.04, note: 'the Moon steadies the tilt',
      draw(lt, d, t) { tiltE(0.41 + Math.sin(lt * 1.5) * 0.04); R.pill('THE MOON STEADIES EARTH\'S TILT', 960, 160, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S32c', at: ea, cam, zoom: 0.04, note: 'about 22 to 24.5 degrees',
      draw(lt, d, t) { R.paper(); big('22° to 24.5°', 960, 430, 210); R.pill('EARTH\'S TILT', 960, 650, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S32d', at: forty, cam, zoom: 0.04, note: 'wobble over 40,000 years',
      draw(lt, d, t) { R.paper(); big('40,000', 960, 430, 300); R.pill('YEARS PER WOBBLE (ROUGHLY)', 960, 660, 52, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(32), later = Wc('later', 32);
    add({ id: 'S33', at: st, cam, zoom: 0.04, note: '1993: up to 90 degrees',
      draw(lt, d, t) { space(0); ctx.save(); ctx.translate(960, 540); ctx.rotate(lerp(0.41, PI / 2, eio(seg(lt, 0.4, 3.0)))); line([[0, -300], [0, 300]], C.white, 8); G.globe(0, 0, 210, 0); line([[0, -330], [0, -230]], C.orange, 14); ctx.restore(); R.pill('1993 SIMULATIONS: NO MOON, UP TO 90°?', 960, 160, 46, pop(lt, 0.3)); } });
    add({ id: 'S33b', at: later, cam, zoom: 0.04, note: 'later work: billions of years',
      draw(lt, d, t) { R.paper(); big('billions', 960, 430, 240); R.pill('LATER WORK: IT WOULD TAKE BILLIONS OF YEARS', 960, 660, 44, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S34', at: A(33), cam: [1200, 540], zoom: 0.05, note: 'stabilizer not a lifeline',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, mouth: 'grin' }); R.pill('A STABILIZER, NOT A LIFELINE', 700, 450, 50, pop(lt, 0.4), { hi: true }); } });
  add({ id: 'S35', at: A(34), cam: [1200, 540], zoom: 0.05, note: 'will we lose the Moon',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('LOSE THE MOON?', 700, 450, 54, pop(lt, 0.1)); } });
  { const st = A(35), but = Wc('but', 35);
    add({ id: 'S36', at: st, cam, zoom: 0.04, note: '50 billion years: locked',
      draw(lt, d, t) { pair(t, { er: 170, mr: 70 }); R.pill('IN THEORY: LOCKED AFTER ~50 BILLION YEARS', 960, 200, 46, pop(lt, 0.4)); } });
    add({ id: 'S36b', at: but, cam, zoom: 0.04, note: 'the Sun gets there first',
      draw(lt, d, t) { space(t); M.sun(960, 520, 190); R.pill('THE SUN GETS THERE FIRST', 960, 160, 56, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(36), wo = Wc('without', 36), mo = Wc("moon's", 36);
    add({ id: 'S37', at: st, cam, zoom: 0.04, note: 'brighter Sun boils away oceans',
      draw(lt, d, t) { space(t); const a = eo(seg(lt, 0.5, 3.5)); M.tideEarth(960, 600, 220, { b1: 1 - a, b2: 1 - a, bulge: 0.8, rot: t * 0.15 }); for (let i = 0; i < 5; i++) { const x = 800 + i * 80, y = 400 - ((t * 70 + i * 40) % 140); ctx.save(); ctx.globalAlpha = a * (1 - ((t * 70 + i * 40) % 140) / 140); line([[x, y + 60], [x + 20, y + 30], [x - 10, y], [x + 15, y - 30]], C.white, 10); ctx.restore(); } R.pill('1 TO 1.5 BILLION YEARS: OCEANS BOIL AWAY', 960, 150, 44, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S37b', at: wo, cam, zoom: 0.04, note: 'no oceans, no tidal drag',
      draw(lt, d, t) { space(t); M.tideEarth(960, 540, 220, { land: false, b1: 0, b2: 0, rot: 0 }); R.pill('NO OCEANS, NO TIDAL DRAG', 960, 160, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S37c', at: mo, cam, zoom: 0.04, note: 'the escape stalls',
      draw(lt, d, t) { pair(t, { er: 170, mr: 70 }); R.pill('THE MOON\'S ESCAPE STALLS', 960, 200, 56, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(37), so = Wc('so', 37);
    add({ id: 'S38', at: st, cam, zoom: 0.04, note: 'red giant in 4.5 billion years',
      draw(lt, d, t) { space(t); M.redGiant(960, 540, lerp(110, 290, eo(seg(lt, 0.4, 4.0)))); R.pill('~4.5 BILLION YEARS: A RED GIANT SUN', 960, 130, 48, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S38b', at: so, cam, zoom: 0.04, note: 'the Moon never leaves for good',
      draw(lt, d, t) { space(t); M.moon(960, 500, 200); R.pill('IT NEVER LEAVES FOR GOOD', 960, 170, 56, pop(lt, 0.3), { hi: true }); } }); }

  // ═════════ RECAP ═════════
  add({ id: 'S39', at: A(38), cam: [1200, 540], zoom: 0.05, chap: [7, 'PUTTING IT TOGETHER'], note: 'host: recap',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('PUTTING IT TOGETHER', 700, 450, 54, pop(lt, 0.2), { hi: true }); } });
  { const st = A(39), las = Wc('lasers', 39);
    add({ id: 'S40', at: st, cam, zoom: 0.04, note: '1969 mirrors',
      draw(lt, d, t) { M.lunarGround(760, t); M.reflector(960, 470, 0.9); R.pill('1969: MIRRORS LEFT ON THE MOON', 960, 190, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S40b', at: las, cam, zoom: 0.04, note: 'lasers show 3.8 cm a year',
      draw(lt, d, t) { pair(t); M.laser(740, 520, 1290, 520, t, (t * 0.7) % 1); R.pill('LASERS: 3.8 cm FARTHER EACH YEAR', 960, 250, 50, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S41', at: A(40), cam, zoom: 0.04, note: 'tides pull the Moon forward and up',
    draw(lt, d, t) { space(t); M.tideEarth(620, 540, 210, { ang: 0, b1: 1, b2: 1, shift: 0.45, rot: t * 0.3, bulge: 0.9 }); M.moon(1500, 540, 80); R.arrowV(1180, 470, 220, 0.15, C.orange, 30); R.pill('OCEAN BULGES TUG THE MOON FORWARD', 960, 190, 46, pop(lt, 0.4), { hi: true }); } });
  { const st = A(41), days = Wc('days', 41), ago = Wc('ago', 41);
    add({ id: 'S42', at: st, cam, zoom: 0.04, note: 'Earth pays with a slower spin',
      draw(lt, d, t) { space(t); G.globe(960, 520, 220, t * 0.3); M.spin(960, 520, 320, 1.15, 1.9); R.pill('EARTH PAYS WITH A SLOWER SPIN', 960, 170, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S42b', at: days, cam, zoom: 0.04, note: '1.7 ms per century',
      draw(lt, d, t) { R.paper(); big('+1.7 ms', 960, 430, 300); R.pill('PER CENTURY', 960, 660, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S42c', at: ago, cam, zoom: 0.04, note: 'long ago a few hours',
      draw(lt, d, t) { R.paper(); K.clock(960, 450, 1.3, lt * 5); R.pill('LONG AGO: ONLY A FEW HOURS', 960, 790, 52, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S43', at: A(42), cam, zoom: 0.04, note: 'total eclipses end',
    draw(lt, d, t) { R.paper(); M.eclipse(960, 450, 210, 150, 0, { corona: false }); R.pill('TOTAL ECLIPSES END', 960, 800, 56, pop(lt, 0.4), { hi: true }); } });
  add({ id: 'S44', at: A(43), cam, zoom: 0.03, note: 'tonight when you look up',
    draw(lt, d, t) { space(t); M.moon(1100, 700, 360); ctx.beginPath(); ctx.moveTo(-50, 880); ctx.bezierCurveTo(500, 820, 1200, 900, 1980, 850); ctx.lineTo(1980, 1100); ctx.lineTo(-50, 1100); ctx.fillStyle = '#161F30'; ctx.fill(); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('A LITTLE FARTHER THAN LAST YEAR', 760, 260, 50, pop(lt, 1.2), { hi: true }); } });
  { const st = A(44), kn = Wc('know', 44);
    add({ id: 'S45', at: st, cam, zoom: 0.05, note: 'loop back: the Moon is leaving',
      draw(lt, d, t) { space(t); const x = lerp(1100, 1180, eio(seg(lt, 0, 4))); M.moon(x, 520, 230); R.arrowV(x + 280, 520, 200, 0, C.orange, 30); R.pill('VERY, VERY SLOWLY', 560, 300, 54, pop(lt, 1.2), { hi: true }); } });
    add({ id: 'S45b', at: kn, cam: [1200, 540], zoom: 0.05, note: 'now you know',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip, mouth: 'grin' }); R.pill('NOW YOU KNOW HOW WE CAN PROVE IT', 700, 450, 46, pop(lt, 0.3), { hi: true }); } }); }

  return { shots: S, cues: CUES };
}
