// THUMBNAIL scene (QS='&thumb=1'): dark navy, ONE big focal object: the Moon, drifting away (ghost moons behind it). Text is added afterwards (PIL).
import { ctx, C, W, H, TAU, fillAll, circle, line } from './core/lib.js';
import * as R from './core/space.js';
import * as M from './core/moon.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#16203A');
  for (let i = 0; i < 40; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y > 150 && y < 850) continue; circle(x, y, 2 + (i % 3), 'rgba(255,255,255,0.55)'); }
  // ghost moons = where it was
  ctx.save(); ctx.globalAlpha = 0.18; M.moon(1330, 450, 250); ctx.globalAlpha = 0.3; M.moon(1430, 420, 280); ctx.restore();
  M.moon(1590, 390, 300, { hi: true });
  R.arrowV(1330, 850, 280, -0.2, C.orange, 44);
}
