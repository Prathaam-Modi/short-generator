// THUMBNAIL scene (QS='&thumb=1'): dark navy, ONE big focal object on the right: a glowing tin drop about to be hit by a laser. Text is added afterwards (PIL).
import { ctx, C, W, H, TAU, fillAll, circle, line } from './core/lib.js';
import * as E from './core/euv.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#16203A');
  for (let i = 0; i < 40; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y < 700) continue; circle(x, y, 2 + (i % 3), 'rgba(255,255,255,0.3)'); }
  circle(1620, 400, 400, '#1E2B4E');
  E.beam(1130, 1080, 1405, 575, 50, 1, C.red);
  E.droplet(1640, 400, 240, 0, true);
  E.plasma(1410, 560, 1.05, 1, 0.3);
}
