// THUMBNAIL scene (QS='&thumb=1'): dark navy, ONE big focal object on the right: a phone with a nearly empty battery. Text is added afterwards (PIL).
import { ctx, C, W, H, TAU, fillAll, circle, line } from './core/lib.js';
import * as R from './core/space.js';
import * as K from './core/kit.js';
import * as B from './core/batt.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#16203A');
  for (let i = 0; i < 40; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y > 150 && y < 850) continue; circle(x, y, 2 + (i % 3), 'rgba(255,255,255,0.35)'); }
  circle(1620, 540, 400, 'rgba(245,124,42,0.16)');
  K.phone(1620, 540, 1.95, 0.07, C.white, () => {
    B.battery(0, -40, 0.42, 0.14, { color: C.red });
    R.txt('12%', 0, 70, 70, C.red, 'center', 1);
  });
}
