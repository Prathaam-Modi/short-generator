// THUMBNAIL scene (QS='&thumb=1', optional &v=2): dark navy, ONE big focal object on the right. Text is added afterwards (PIL).
import { ctx, C, W, H, TAU, fillAll, circle, line } from './core/lib.js';
import * as R from './core/space.js';
import * as Z from './core/sea.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  const v = new URLSearchParams(location.search).get('v') || '1';
  fillAll('#16203A');
  for (let i = 0; i < 40; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y > 150 && y < 850) continue; circle(x, y, 2 + (i % 3), 'rgba(255,255,255,0.4)'); }
  if (v === '2') {
    // an anchor about to land on a thin cable
    ctx.fillStyle = '#C9B58C'; ctx.fillRect(-10, 800, W + 20, 300); ctx.fillStyle = C.ink; ctx.fillRect(-10, 796, W + 20, 8);
    Z.cable([[900, 760], [1400, 770], [1950, 760]], 34);
    Z.anchor(1450, 420, 2.3, 0.18);
    R.arrowV(1450, 700, 120, Math.PI * 0.5, C.orange, 40);
  } else {
    circle(1520, 450, 360, 'rgba(245,124,42,0.16)');
    Z.cableCross(1520, 450, 340, 5, -1, 0.6);
  }
}
