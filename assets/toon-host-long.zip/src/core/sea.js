// Props for the undersea-cable video, same flat-fill + thick-ink look as kit.js / space.js.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './lib.js';
import * as R from './space.js';

export const DEEP = '#1F3A5F', DEEP2 = '#2A4A74', SAND = '#C9B58C', SAND_D = '#A8946C', GLASS = '#CFE8F7';
export const LASER = ['#F57C28', '#FFD23F', '#5DB36F', '#4A7FB5', '#D8392B', '#FFFFFF'];

/** deep-sea backdrop: flat navy water, a sand floor strip at y0, soft bubbles. */
export function seabed(y0 = 780, t = 0, o = {}) {
  if (!o.floorOnly) {
  ctx.fillStyle = DEEP; ctx.fillRect(-300, -300, W + 600, H + 600);
  ctx.fillStyle = DEEP2; ctx.fillRect(-300, 340, W + 600, 140); ctx.fillRect(-300, 640, W + 600, 90);
  for (let i = 0; i < 14; i++) { const x = rnd(i * 3) * W, y = 120 + ((rnd(i) * 800 - t * (18 + rnd(i + 5) * 14)) % 800 + 800) % 800; ctx.globalAlpha = 0.35; circle(x, y, 4 + rnd(i + 9) * 6, C.white); }
  ctx.globalAlpha = 1; }
  const P = [[-300, y0 + 30]]; for (let x = -200; x <= W + 300; x += 220) P.push([x, y0 + (rnd(x * 0.01) - 0.5) * 36]); P.push([W + 300, 1300], [-300, 1300]);
  ctx.beginPath(); ctx.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length; i++) ctx.lineTo(P[i][0], P[i][1]); ctx.closePath();
  ctx.fillStyle = SAND; ctx.fill(); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke();
  for (let i = 0; i < 9; i++) { const x = 100 + i * 220 + rnd(i) * 60, y = y0 + 80 + rnd(i + 3) * 140; ell(x, y, 26 + rnd(i) * 22, 7, SAND_D); }
}

/** a cable drawn along a polyline: ink outline, dark core, light dashes. w = thickness */
export function cable(pts, w = 22, o = {}) {
  inkLine(pts, o.color || C.gray, w, 6);
  if (o.dash !== false) { ctx.save(); ctx.setLineDash([w * 0.9, w * 1.8]); line(pts, C.grayLight, Math.max(4, w * 0.22)); ctx.restore(); }
}
/** cable drawn partly: along a function y(x) between x0 and x1 up to progress p */
export function cableSag(x0, y0, x1, y1, sag, w = 22, p = 1, o = {}) {
  const pts = []; const n = 28; for (let i = 0; i <= n * p; i++) { const u = i / n; pts.push([lerp(x0, x1, u), lerp(y0, y1, u) + Math.sin(u * Math.PI) * sag]); }
  if (pts.length > 1) cable(pts, w, o); return pts;
}

/** garden hose coil (green), ~ 2r wide */
export function hose(x, y, r = 150, p = 1) {
  ctx.save(); ctx.translate(x, y);
  for (let k = 2; k >= 0; k--) { const rr = r - k * r * 0.26; ctx.beginPath(); ctx.arc(0, 0, rr, 0, TAU * (k === 2 ? p : 1)); ctx.lineWidth = r * 0.2 + 12; ctx.strokeStyle = C.ink; ctx.stroke(); }
  for (let k = 2; k >= 0; k--) { const rr = r - k * r * 0.26; ctx.beginPath(); ctx.arc(0, 0, rr, 0, TAU * (k === 2 ? p : 1)); ctx.lineWidth = r * 0.2; ctx.strokeStyle = C.green; ctx.stroke(); }
  wRect(r * 0.9, -r * 0.2, r * 0.42, r * 0.4, 8, C.yellow, { seed: 3, lw: 6 });
  ctx.restore();
}

/** cross-section of a cable: layers shown = n (1..5), outermost first. Fiber core in the middle with light dots. */
export function cableCross(x, y, r = 260, n = 5, hiIdx = -1, t = 0) {
  const layers = [['#2B2B2B', 1.0], [C.grayLight, 0.82], [C.orange, 0.62], [C.yellow, 0.48], [GLASS, 0.34]];
  ctx.save(); ctx.translate(x, y);
  for (let i = 0; i < Math.min(n, 5); i++) {
    const [c, f] = layers[i]; circle(0, 0, r * f, hiIdx === i ? C.orange : c); ctx.lineWidth = 7; ctx.strokeStyle = C.ink; ctx.stroke();
  }
  if (n >= 2) for (let i = 0; i < 18; i++) { const a = (i / 18) * TAU; circle(Math.cos(a) * r * 0.72, Math.sin(a) * r * 0.72, r * 0.045, C.ink); }
  if (n >= 5) for (let i = 0; i < 4; i++) { const a = (i / 4) * TAU + t * 0.4; circle(Math.cos(a) * r * 0.13, Math.sin(a) * r * 0.13, r * 0.06, LASER[i]); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke(); }
  ctx.restore();
}

/** a glass strand with colored light pulses running along it. colors = how many laser colors */
export function fiber(x0, y0, x1, y1, t, colors = 1, o = {}) {
  const w = o.w || 34, A0 = o.alpha ?? 1;
  ctx.globalAlpha = A0; inkLine([[x0, y0], [x1, y1]], GLASS, w, 7);
  const dx = x1 - x0, dy = y1 - y0;
  for (let c = 0; c < colors; c++) {
    const lane = colors === 1 ? 0 : (c - (colors - 1) / 2) * (w / colors) * 0.95;
    for (let i = 0; i < 9; i++) {
      const u = (((i / 9) + t * 0.35 + c * 0.018) % 1);
      const px = x0 + dx * u, py = y0 + dy * u + lane;
      const sz = colors === 1 ? 11 : 6;
      ctx.globalAlpha = A0 * Math.min(1, Math.min(u, 1 - u) * 8); circle(px, py, sz, LASER[c % LASER.length]); ctx.globalAlpha = 1;
    }
  }
}

/** a repeater: capsule with rings, sits on the cable */
export function repeater(x, y, s = 1, glow = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-70, -30, 140, 60, 24, C.blue, { seed: 11, lw: 7 });
  for (const dx of [-36, 0, 36]) line([[dx, -30], [dx, 30]], C.ink, 6);
  if (glow > 0) { ctx.globalAlpha = glow; circle(0, 0, 90, C.yellow); ctx.globalAlpha = 1; wRect(-70, -30, 140, 60, 24, C.orange, { seed: 11, lw: 7 }); for (const dx of [-36, 0, 36]) line([[dx, -30], [dx, 30]], C.ink, 6); }
  ctx.restore();
}

export function bolt(x, y, s = 1, color = C.yellow) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[10, -70], [-34, 8], [-4, 8], [-14, 70], [36, -14], [4, -14]], color, { seed: 21, lw: 7 });
  ctx.restore();
}

/** simplified world: continents as flat blobs on a deep-blue ocean. returns nothing. */
export const CITY = { ny: [610, 370], lon: [930, 300], sf: [330, 400], mum: [1330, 560], sing: [1520, 700], tok: [1700, 400], cape: [1020, 780], rio: [690, 760], syd: [1700, 880], sey: [1280, 620], lis: [880, 380], dubai: [1220, 520] };
export function worldMap(o = {}) {
  const { bg = DEEP, land = SAND } = o;
  ctx.fillStyle = bg; ctx.fillRect(-300, -300, W + 600, H + 600);
  const cont = [
    [[200, 260], [380, 190], [560, 230], [660, 330], [600, 440], [500, 520], [420, 470], [300, 400]],         // N America
    [[560, 560], [700, 580], [740, 700], [680, 860], [610, 900], [580, 760]],                                 // S America
    [[860, 260], [960, 220], [1080, 260], [1060, 340], [940, 390], [860, 350]],                                // Europe
    [[900, 440], [1060, 430], [1140, 560], [1080, 760], [1000, 840], [940, 700], [880, 540]],                  // Africa
    [[1130, 240], [1400, 190], [1700, 250], [1760, 400], [1560, 520], [1420, 640], [1320, 600], [1220, 480], [1120, 360]], // Asia
    [[1580, 780], [1780, 780], [1800, 880], [1640, 920]],                                                       // Australia
  ];
  cont.forEach((p, i) => blob(p, land, { seed: 40 + i, lw: 7, wob: 5 }));
}
/** a cable route on the map between two points with an arc. p = draw progress */
export function route(a, b, arc = -90, p = 1, color = C.orange, w = 12) {
  const pts = []; const n = 30;
  for (let i = 0; i <= n * p; i++) { const u = i / n; pts.push([lerp(a[0], b[0], u), lerp(a[1], b[1], u) + Math.sin(u * Math.PI) * arc]); }
  if (pts.length > 1) inkLine(pts, color, w, 4); return pts;
}
export function city(p, label, sc = 1) { circle(p[0], p[1], 18 * sc, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); circle(p[0], p[1], 8 * sc, C.red); }

/** cable ship, side view, ~w wide. old = tall smokestacks (Great Eastern). cable trails off the stern (left) into the sea if trail */
export function cableShip(x, y, w, t = 0, o = {}) {
  const bob = Math.sin(t * 1.3) * 3, hh = w * 0.15;
  ctx.save(); ctx.translate(x, y + bob);
  // spool drums on deck
  wRect(-w * 0.12, -w * 0.12, w * 0.3, w * 0.12, 6, C.orange, { seed: 61, lw: 6 });
  for (let i = 0; i < 3; i++) line([[-w * 0.1 + i * w * 0.09, -w * 0.12], [-w * 0.1 + i * w * 0.09, 0]], C.ink, 5);
  if (o.old) { for (const dx of [0.02, 0.14]) wRect(w * dx - w * 0.04 + w * 0.12, -w * 0.3, w * 0.06, w * 0.19, 4, C.sweater, { seed: 62 + dx * 10, lw: 6 }); }
  poly([[-w / 2, w * 0.0], [w / 2, w * 0.0], [w / 2 - w * 0.05, hh], [-w / 2 + w * 0.05, hh]], C.sweater, { seed: 63, wob: 1, lw: 7 });
  wRect(-w / 2, -w * 0.01, w, w * 0.034, 5, R.DECK, { seed: 64, lw: 6, wob: 1 });
  wRect(w * 0.26, -w * 0.12, w * 0.17, w * 0.12, 6, C.white, { seed: 65, lw: 6 });
  wRect(w * 0.3, -w * 0.09, w * 0.04, w * 0.03, 3, C.blue, { seed: 66, lw: 3 }); wRect(w * 0.36, -w * 0.09, w * 0.04, w * 0.03, 3, C.blue, { seed: 67, lw: 3 });
  // stern sheave + A-frame
  inkLine([[-w / 2 + 14, 0], [-w / 2 + 14, -w * 0.12], [-w / 2 + w * 0.08, -w * 0.12]], C.grayLight, 10, 5);
  ctx.restore();
}

export function buoy(x, y, s = 1, t = 0) {
  const b = Math.sin(t * 2) * 4; ctx.save(); ctx.translate(x, y + b); ctx.scale(s, s);
  line([[0, -60], [0, -110]], C.ink, 10); circle(0, -118, 14, C.yellow); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke();
  poly([[-46, 30], [46, 30], [34, -50], [-34, -50]], C.orange, { seed: 71, lw: 7 });
  poly([[-42, 8], [42, 8], [38, -14], [-38, -14]], C.white, { seed: 72, lw: 5 });
  ctx.restore();
}

export function anchor(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  inkLine([[0, -90], [0, 80]], C.grayLight, 20, 6);
  inkLine([[-34, -50], [34, -50]], C.grayLight, 18, 6);
  ctx.beginPath(); ctx.arc(0, -108, 20, 0, TAU); ctx.lineWidth = 12; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.lineWidth = 6; ctx.strokeStyle = C.grayLight; ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 40, 90, 0.15 * Math.PI, 0.85 * Math.PI); ctx.lineWidth = 26; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.lineWidth = 14; ctx.strokeStyle = C.grayLight; ctx.stroke();
  poly([[-100, 80], [-70, 60], [-60, 104]], C.grayLight, { seed: 81, lw: 6 }); poly([[100, 80], [70, 60], [60, 104]], C.grayLight, { seed: 82, lw: 6 });
  ctx.restore();
}

export function shark(x, y, s = 1, flip = 1, t = 0) {
  ctx.save(); ctx.translate(x, y + Math.sin(t * 2) * 6); ctx.scale(s * flip, s);
  blob([[-150, 0], [-90, -40], [20, -52], [120, -20], [160, 10], [110, 30], [20, 48], [-90, 36]], '#7C8FA3', { seed: 91, lw: 7 });
  poly([[-130, 0], [-190, -52], [-170, 0], [-190, 50]], '#7C8FA3', { seed: 92, lw: 7 });
  poly([[-20, -50], [20, -108], [50, -46]], '#7C8FA3', { seed: 93, lw: 7 });
  blob([[0, 20], [90, 10], [150, 6], [90, 40], [30, 42]], C.white, { seed: 94, lw: 0 });
  circle(105, -4, 7, C.ink);
  ctx.restore();
}

export function trawler(x, y, w, t = 0) {
  const bob = Math.sin(t * 1.4) * 3, hh = w * 0.18;
  ctx.save(); ctx.translate(x, y + bob);
  poly([[-w / 2, 0], [w / 2, 0], [w / 2 - w * 0.08, hh], [-w / 2 + w * 0.06, hh]], C.red, { seed: 121, wob: 1, lw: 7 });
  wRect(-w * 0.1, -w * 0.22, w * 0.3, w * 0.22, 6, C.white, { seed: 122, lw: 6 });
  wRect(-w * 0.04, -w * 0.15, w * 0.07, w * 0.07, 3, C.blue, { seed: 123, lw: 3 });
  line([[-w * 0.38, 0], [-w * 0.38, -w * 0.28], [-w * 0.1, -w * 0.28]], C.ink, 8);
  ctx.restore();
}
export function net(x0, y0, x1, y1, w = 160) {
  const dx = x1 - x0, dy = y1 - y0;
  poly([[x0, y0], [x1 - w / 2, y1], [x1 + w / 2, y1]], 'rgba(255,255,255,0.18)', { seed: 131, lw: 6 });
  for (let i = 1; i < 5; i++) { const u = i / 5; line([[lerp(x0, x1 - w / 2, u), lerp(y0, y1, u)], [lerp(x0, x1 + w / 2, u), lerp(y0, y1, u)]], C.white, 3); }
}

export function volcano(x, y, s = 1, t = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[-320, 0], [-70, -260], [70, -260], [320, 0]], '#6B5A4A', { seed: 141, lw: 8 });
  poly([[-90, -250], [0, -330], [90, -250]], C.orange, { seed: 142, lw: 7 });
  for (let i = 0; i < 6; i++) { const u = (t * 0.6 + i / 6) % 1; ctx.globalAlpha = 1 - u; circle(-40 + i * 16 + Math.sin(i) * 30, -300 - u * 260, 40 + u * 50, i % 2 ? C.grayLight : C.gray); } ctx.globalAlpha = 1;
  ctx.restore();
}

/** shore station: a little building with an antenna-free dish roof and a cable going out */
export function station(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-130, -150, 260, 150, 10, C.white, { seed: 151, lw: 8 });
  poly([[-150, -150], [0, -230], [150, -150]], C.red, { seed: 152, lw: 8 });
  wRect(-30, -90, 60, 90, 6, C.blue, { seed: 153, lw: 6 });
  for (const dx of [-95, 65]) wRect(dx, -120, 40, 40, 5, C.yellow, { seed: 154 + dx, lw: 5 });
  ctx.restore();
}

/** top view of a ship's cable tank: concentric cable rings */
export function coil(x, y, r = 220, p = 1) {
  ctx.save(); ctx.translate(x, y);
  circle(0, 0, r, C.grayLight); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  for (let k = 0; k < 6; k++) { const rr = r * (0.88 - k * 0.13); if (rr <= r * 0.12) break; ctx.beginPath(); ctx.arc(0, 0, rr, 0, TAU * (k === 0 ? 1 : p)); ctx.lineWidth = r * 0.1; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.lineWidth = r * 0.06; ctx.strokeStyle = C.gray; ctx.stroke(); }
  circle(0, 0, r * 0.1, C.orange); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.restore();
}

/** small grapple hook */
export function grapple(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  inkLine([[0, -120], [0, 20]], C.grayLight, 18, 6);
  for (const d of [-1, 0, 1]) { ctx.beginPath(); ctx.arc(d * 50, 20, 50, d === 0 ? 0.1 * Math.PI : (d < 0 ? 0.0 : 0.3 * Math.PI), d === 0 ? 0.9 * Math.PI : (d < 0 ? 0.7 * Math.PI : Math.PI), false); ctx.lineWidth = 24; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.lineWidth = 12; ctx.strokeStyle = C.grayLight; ctx.stroke(); }
  ctx.restore();
}

/** a break: two cable ends with a gap and sparks */
export function breakMark(x, y, s = 1, t = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[-34, -80], [-6, -20], [-40, 0], [0, 70], [-14, 20], [34, 4]], C.red, { seed: 161, lw: 6, wob: 0 });
  ctx.restore();
}
