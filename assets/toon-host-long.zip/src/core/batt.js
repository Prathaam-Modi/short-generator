// Battery props for the Toon Host LONG engine: battery icon, cell cutaway, anode zoom (crust / plating), thermometer, sun, kettle, car, seesaw.
// Same look as the rest of the kit: flat fills + thick wobbly ink outlines, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, rnd, wRect, wEll, poly, circle, line, inkLine, rr } from './lib.js';
import * as R from './space.js';
import * as K from './kit.js';

export const LIQ = '#DCEBF5', GRAPH = '#5E5A57', OXIDE = '#86AED0', CRUST = '#7E411D', METAL = '#E4E0DA';

/** battery icon, 360x180 at s = 1. level 0..1; o.color, o.text (inside, ink) */
export function battery(x, y, s = 1, level = 1, o = {}) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(176, -36, 30, 72, 9, C.gray, { seed: 301 });
  wRect(-180, -90, 360, 180, 30, C.white, { seed: 302, lw: 9 });
  const col = o.color || (level < 0.25 ? C.red : C.green);
  if (level > 0.02) wRect(-158, -68, 316 * clamp(level), 136, 14, col, { seed: 303, lw: 0 });
  wRect(-180, -90, 360, 180, 30, null, { seed: 302, lw: 9 });
  if (o.text) R.txt(o.text, 0, 6, o.size || 80, C.ink, 'center', 1);
  ctx.restore();
}

function ion(x, y, r = 20, a = 1) { if (a <= 0) return; ctx.save(); ctx.globalAlpha = clamp(a); wEll(x, y, r, r, C.orange, { seed: 320, n: 10, lw: 5, wob: 0.5 }); ctx.restore(); }
function electron(x, y, a = 1) { if (a <= 0) return; ctx.save(); ctx.globalAlpha = clamp(a); circle(x, y, 13, C.white); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.restore(); }

const gapY = (i) => -134 + i * 76;
const anodeSlot = (k) => [-560 + (k % 3) * 62, gapY(Math.floor(k / 3))];
const cathodeSlot = (k) => [470 + (k % 3) * 62, gapY(Math.floor(k / 3))];

/** the cell cutaway (1280 x 500 at s = 1, wire arch above). t = clock.
 *  o: na / nc = ions parked in the anode / cathode (0..15), flow = moving ions (0..12), dir = -1 charging (cathode to anode) or +1 discharging,
 *  wire = electrons on the outside circuit (o.edir), load = 'bulb', hi = 'anode' | 'cathode' | 'sep' | 'liq' (orange) */
export function cell(x, y, s = 1, t = 0, o = {}) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  const hi = o.hi;
  wRect(-640, -250, 1280, 500, 40, C.white, { seed: 310, lw: 9 });
  ctx.fillStyle = hi === 'liq' ? '#F9CFA8' : LIQ; ctx.fillRect(-340, -240, 680, 480);
  for (let i = 0; i < 6; i++) {
    wRect(-610, -208 + i * 76, 270, 36, 10, hi === 'anode' ? C.orange : GRAPH, { seed: 330 + i, lw: 6, wob: 1 });
    wRect(340, -208 + i * 76, 270, 36, 10, hi === 'cathode' ? C.orange : OXIDE, { seed: 340 + i, lw: 6, wob: 1 });
  }
  wRect(-14, -240, 28, 480, 8, hi === 'sep' ? C.orange : C.white, { seed: 350, lw: 7, wob: 1 });
  for (let k = 0; k < (o.na || 0); k++) { const [px, py] = anodeSlot(k); ion(px, py); }
  for (let k = 0; k < (o.nc || 0); k++) { const [px, py] = cathodeSlot(k); ion(px, py); }
  const n = o.flow || 0, dir = o.dir ?? -1;
  for (let i = 0; i < n; i++) {
    const u = ((t * 0.28 + i / n) % 1), row = (i * 5) % 10, yy = -190 + row * 42 + (rnd(i) - 0.5) * 10;
    const a = Math.min(seg(u, 0, 0.12), 1 - seg(u, 0.88, 1));
    const px = dir < 0 ? lerp(520, -520, u) : lerp(-520, 520, u);
    ion(px, yy, 20, a);
  }
  if (o.wire) {
    const P = [[-470, -250], [-470, -330], [470, -330], [470, -250]];
    inkLine(P, C.grayLight, 10, 5);
    if (o.load === 'bulb') K.bulb(0, -430, 0.45, 1);
    const L1 = 80, L2 = 940, TOT = L1 * 2 + L2, ed = o.edir ?? 1;
    for (let i = 0; i < 8; i++) {
      let d = ((t * 150 * ed + i * TOT / 8) % TOT + TOT) % TOT, px, py;
      if (d < L1) { px = -470; py = -250 - d; } else if (d < L1 + L2) { px = -470 + (d - L1); py = -330; } else { px = 470; py = -330 + (d - L1 - L2); }
      electron(px, py);
    }
  }
  ctx.restore();
}

/** zoom on the graphite side (x, y = centre of a 1500 x 520 view at s = 1).
 *  o: crust 0..1 (brown film), stuck = lithium dots locked in the crust, flow = ions arriving, speed, spikes 0..1 (plated metal), elec = electrons held back, hiCrust = crust in orange */
export function zoom(x, y, s = 1, t = 0, o = {}) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  const cr = clamp(o.crust ?? 0), face = -350 + (cr > 0 ? 22 + cr * 150 : 0);
  wRect(-750, -260, 1500, 520, 36, LIQ, { seed: 360, lw: 9 });
  wRect(-750, -220, 400, 440, 16, GRAPH, { seed: 361, lw: 8 });
  for (let i = 1; i < 6; i++) line([[-730, -220 + i * 73], [-370, -220 + i * 73]], C.grayLight, 7);
  if (cr > 0) wRect(-352, -220, face + 352, 440, 10, CRUST, { seed: 362, lw: 6, wob: 1 });
  const st = o.stuck || 0;
  for (let k = 0; k < st; k++) { const px = -340 + (k % 3) * 40 + 20, py = -180 + Math.floor(k / 3) * 56; if (px < face - 10) ion(px, py, 15); }
  const n = o.flow ?? 0, sp = o.speed ?? 0.25;
  for (let i = 0; i < n; i++) {
    const u = ((t * sp + i / Math.max(1, n)) % 1), row = (i * 3) % 8, yy = -190 + row * 54;
    const a = Math.min(seg(u, 0, 0.1), 1 - seg(u, 0.88, 1));
    ion(lerp(700, face + 24, u), yy, 20, a);
  }
  if (o.spikes) {
    const sk = clamp(o.spikes);
    for (let k = 0; k < 7; k++) { const by = -180 + k * 60, len = (50 + rnd(k + 3) * 130) * sk; poly([[face, by - 20], [face + len, by + (rnd(k) - 0.5) * 20], [face, by + 20]], METAL, { seed: 370 + k, lw: 6, wob: 1 }); }
  }
  if (o.elec) {
    for (let i = 0; i < 4; i++) { const yy = -150 + i * 100, px = -352 - 38 - Math.abs(Math.sin(t * 3 + i)) * 20; electron(px, yy); }
    K.redX(face, 0, 0.12, 1);
  }
  ctx.restore();
}

/** thermometer (60 x 400 at s = 1). level 0..1, col = fill colour */
export function thermo(x, y, s = 1, level = 0.5, col = C.red) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-32, -190, 64, 340, 32, C.white, { seed: 380, lw: 8 });
  wRect(-18, 150 - 320 * clamp(level), 36, 320 * clamp(level), 18, col, { seed: 381, lw: 0 });
  wRect(-32, -190, 64, 340, 32, null, { seed: 380, lw: 8 });
  wEll(0, 176, 58, 58, col, { seed: 382, n: 14 });
  ctx.restore();
}

export function sun(x, y, s = 1, t = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  for (let i = 0; i < 12; i++) { const an = i * TAU / 12 + t * 0.3, r0 = 150, r1 = i % 2 ? 210 : 240; line([[Math.cos(an) * r0, Math.sin(an) * r0], [Math.cos(an) * r1, Math.sin(an) * r1]], C.ink, 16); line([[Math.cos(an) * r0, Math.sin(an) * r0], [Math.cos(an) * r1, Math.sin(an) * r1]], C.yellow, 8); }
  wEll(0, 0, 120, 120, C.yellow, { seed: 390, n: 18, lw: 9 });
  ctx.restore();
}

/** kettle with limescale inside (cutaway), scale = 0..1 thickness */
export function kettle(x, y, s = 1, scale = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[150, -40], [250, -130], [280, -110], [190, 20]], C.grayLight, { seed: 400, wob: 1 });
  line([[-170, -80], [-250, -40], [-250, 40], [-170, 80]], C.ink, 26);
  wRect(-180, -150, 360, 280, 70, C.grayLight, { seed: 401, lw: 9 });
  wRect(-140, -90, 280, 190, 40, LIQ, { seed: 402, lw: 6 });
  wRect(-140, 100 - 70 * scale, 280, 70 * scale, 20, C.paper, { seed: 403, lw: 6 });
  wRect(-60, -190, 120, 44, 18, C.gray, { seed: 404 });
  ctx.restore();
}

/** a small electric car (440 wide at s = 1) with an orange battery under the floor */
export function car(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-130, -140, 270, 100, 40, C.jeansLight, { seed: 410, lw: 8 });
  wRect(-230, -70, 460, 110, 34, C.white, { seed: 411, lw: 9 });
  wRect(-120, 44, 240, 30, 10, C.orange, { seed: 412, lw: 6 });
  for (const wx of [-140, 140]) { circle(wx, 50, 52, C.ink); circle(wx, 50, 22, C.grayLight); }
  ctx.restore();
}

/** seesaw. tilt in radians (+ = right end down). returns the two end points */
export function seesaw(x, y, s = 1, tilt = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[-70, 140], [0, 0], [70, 140]], C.grayLight, { seed: 420, wob: 1 });
  ctx.save(); ctx.rotate(tilt); wRect(-400, -18, 800, 36, 14, C.orange, { seed: 421 }); ctx.restore();
  ctx.restore();
  return [[x - Math.cos(tilt) * 400 * s, y - Math.sin(tilt) * 400 * s], [x + Math.cos(tilt) * 400 * s, y + Math.sin(tilt) * 400 * s]];
}
