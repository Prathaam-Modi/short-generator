// EUV props (same inked look): wafer, tin droplet, laser beam, plasma flash, collector mirror, mirror layers, wave, mask, lens, chamber, cone, machine, generator.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, rnd, circle, line, ell, blob, poly, wEll, wRect, inkLine, rr } from './lib.js';
import * as R from './space.js';
import * as K from './kit.js';

export const TIN = '#C9CED6', TIN_D = '#8E95A3', MOLY = '#7E8794', SILI = '#9FC3E0', COAT = '#9ED3AE', DARKBG = '#16203A';

/** silicon wafer (disc, r). o: dies (grid count), coat (coating colour), hi (index of the orange die), pat (0..1 stripes exposed), flat */
export function wafer(x, y, r, o = {}) {
  ctx.save(); ctx.translate(x, y);
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = o.coat || TIN; ctx.fill(); ctx.save(); ctx.clip();
  const n = o.dies || 0;
  if (n) {
    const d = (2 * r) / n; let k = 0;
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      const cx = -r + (i + 0.5) * d, cy = -r + (j + 0.5) * d; if (Math.hypot(cx, cy) > r - d * 0.4) continue;
      const hi = o.hi === k; k++;
      ctx.beginPath(); ctx.rect(cx - d * 0.42, cy - d * 0.42, d * 0.84, d * 0.84); ctx.fillStyle = hi ? C.orange : '#A9B2C2'; ctx.fill(); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke();
    }
  }
  if (o.pat) {
    const rows = 7, p = clamp(o.pat);
    for (let i = 0; i < rows; i++) { const yy = -r * 0.7 + i * ((r * 1.4) / (rows - 1)); const w = 2 * Math.sqrt(Math.max(0, r * r - yy * yy)) * 0.8 * clamp(p * rows - i); if (w > 0) wRect(-w / 2, yy - 9, w, 18, 6, o.patColor || C.orange, { seed: 600 + i, lw: 4, wob: 0.8 }); }
  }
  ctx.restore();
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  // shine
  ctx.beginPath(); ctx.arc(0, 0, r * 0.82, Math.PI * 1.05, Math.PI * 1.35); ctx.lineWidth = 8; ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineCap = 'round'; ctx.stroke();
  ctx.restore();
}
/** tin droplet. mode 0 = ball, 1 = flattened pancake (p = 0..1 blend) */
export function droplet(x, y, r, p = 0, hi = false) {
  ctx.save(); ctx.translate(x, y);
  const rx = lerp(r, r * 3.2, p), ry = lerp(r, r * 0.38, p);
  wEll(0, 0, rx, ry, hi ? C.orange : TIN, { seed: 610, n: 14, lw: Math.max(5, r * 0.22), wob: 0.6 });
  if (!hi) ell(-rx * 0.35, -ry * 0.35, rx * 0.22, ry * 0.2, '#FFFFFF');
  ctx.restore();
}
/** laser beam from (x0,y0) to (x1,y1), width w. glow = 0..1 thickness pulse */
export function beam(x0, y0, x1, y1, w = 26, a = 1, color = C.red) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = clamp(a);
  inkLine([[x0, y0], [x1, y1]], color, w, 6);
  line([[x0, y0], [x1, y1]], '#FFFFFF', w * 0.28);
  ctx.restore();
}
/** plasma flash: yellow burst with white core */
export function plasma(x, y, s = 1, a = 1, rot = 0) {
  if (a <= 0) return;
  K.burst(x, y, s, a, C.yellow, rot); K.burst(x, y, s * 0.55, a, '#FFFFFF', rot + 0.2);
}
/** curved collector mirror (open to the right). w = height, depth = how deep the bowl */
export function collector(x, y, h = 420, depth = 150, color = '#A9BBD0') {
  const outer = [], inner = [];
  for (let i = 0; i <= 10; i++) { const a = lerp(-1.25, 1.25, i / 10); outer.push([x - Math.cos(a) * depth, y + Math.sin(a) * h / 2]); }
  for (let i = 10; i >= 0; i--) { const a = lerp(-1.25, 1.25, i / 10); inner.push([x - Math.cos(a) * depth * 0.72 + 8, y + Math.sin(a) * h / 2 * 0.97]); }
  poly(outer.concat(inner), color, { seed: 620, wob: 1, lw: 9 });
  line(inner.slice(2, 9).map((p) => [p[0] + 18, p[1]]), '#FFFFFF', 7);
}
/** big round EUV mirror seen from the side/front (r) */
export function mirror(x, y, r = 160, rot = 0, hi = false) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
  wEll(0, 0, r * 0.42, r, hi ? C.orange : '#B7C8DA', { seed: 630, n: 18, lw: 9, wob: 1 });
  wEll(-r * 0.06, 0, r * 0.3, r * 0.82, hi ? '#F9A66A' : '#D8E4F0', { seed: 631, n: 16, lw: 0 });
  ctx.beginPath(); ctx.arc(-r * 0.1, 0, r * 0.7, Math.PI * 1.1, Math.PI * 1.35); ctx.lineWidth = 9; ctx.strokeStyle = '#FFFFFF'; ctx.lineCap = 'round'; ctx.stroke();
  ctx.restore();
}
/** multilayer cross-section: w wide, n alternating layers (each h tall), rays=0..1 incoming + reflected arrows */
export function layers(x, y, w, n = 12, h = 30, o = {}) {
  ctx.save(); ctx.translate(x, y);
  for (let i = 0; i < n; i++) {
    const hi = o.hi === i;
    wRect(-w / 2, i * h, w, h + 2, 4, hi ? C.orange : (i % 2 ? SILI : MOLY), { seed: 640 + i, lw: 4, wob: 0.6 });
  }
  if (o.rays) {
    const p = clamp(o.rays), ax = -w * 0.2, top = 0;
    inkLine([[ax - 220, top - 200], [ax - 220 + 220 * Math.min(1, p * 2), top - 200 + 200 * Math.min(1, p * 2)]], C.yellow, 20, 6);
    if (p > 0.5) { const q = (p - 0.5) * 2; inkLine([[ax, top], [ax + 220 * q, top - 200 * q]], C.yellow, 20 * (o.refl ?? 0.7) + 4, 6); }
  }
  ctx.restore();
}
/** sine wave polyline from x to x + w, wavelength wl, amplitude amp, p = reveal 0..1 */
export function wave(x, y, w, amp, wl, color = C.orange, lw = 14, p = 1, ph = 0) {
  const pts = [], n = Math.floor(w * clamp(p) / 6);
  for (let i = 0; i <= n; i++) { const xx = i * 6; pts.push([x + xx, y + Math.sin((xx / wl) * TAU + ph) * amp]); }
  if (pts.length > 1) inkLine(pts, color, lw, 5);
}
/** stencil / mask plate with cut-out pattern */
export function mask(x, y, s = 1, hi = false) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-170, -170, 340, 340, 18, hi ? C.orange : C.gray, { seed: 650, lw: 9 });
  for (const [px, py, w, h] of [[-110, -110, 150, 34], [-110, -50, 220, 34], [-110, 10, 90, 34], [30, 10, 80, 34], [-110, 70, 220, 34]]) wRect(px, py, w, h, 8, '#EAF3FA', { seed: px + py, lw: 4, wob: 0.8 });
  ctx.restore();
}
/** glass lens (side view, r tall) */
export function lens(x, y, r = 150, hi = false) {
  ctx.save(); ctx.translate(x, y);
  wEll(0, 0, r * 0.4, r, hi ? '#F9C9A1' : '#CFE8F7', { seed: 660, n: 16, lw: 9, wob: 1 });
  ctx.beginPath(); ctx.arc(-r * 0.08, 0, r * 0.7, Math.PI * 1.1, Math.PI * 1.35); ctx.lineWidth = 8; ctx.strokeStyle = '#FFFFFF'; ctx.lineCap = 'round'; ctx.stroke();
  ctx.restore();
}
/** vacuum chamber: big rounded box outline, light fill */
export function chamber(x, y, w, h, fill = '#E4EFF8') {
  wRect(x - w / 2, y - h / 2, w, h, 40, fill, { seed: 670, lw: 10 });
}
/** cone of light narrowing to a point at (x, y), opening upward with half-width hw, height h */
export function cone(x, y, hw, h, color = C.yellow, a = 1) {
  if (a <= 0) return; ctx.save(); ctx.globalAlpha = a;
  poly([[x, y], [x - hw, y - h], [x + hw, y - h]], color, { seed: 680, wob: 1, lw: 7 }); ctx.restore();
}
/** droplet generator: nozzle block with spout pointing down (x, y = spout tip) */
export function generator(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-90, -250, 180, 170, 24, C.grayLight, { seed: 690, lw: 9 });
  poly([[-46, -90], [46, -90], [16, -8], [-16, -8]], C.gray, { seed: 691, lw: 8, wob: 1 });
  wRect(-60, -230, 120, 56, 12, '#E4E0DA', { seed: 692, lw: 6, wob: 1 });
  ctx.restore();
}
/** stylised EUV machine: big grey box on feet with orange panel and a window (about 560 wide at s = 1) */
export function machine(x, y, s = 1, hi = false) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-280, -180, 560, 300, 30, '#E4E0DA', { seed: 700, lw: 9 });
  wRect(-280, -180, 560, 80, 30, hi ? C.orange : C.grayLight, { seed: 701, lw: 9 });
  wRect(-230, -70, 230, 150, 18, '#CFE8F7', { seed: 702, lw: 7 });
  for (let i = 0; i < 3; i++) wRect(40 + i * 70, -60 + i * 8, 56, 130 - i * 16, 10, i === 1 ? C.orange : C.gray, { seed: 703 + i, lw: 6 });
  wRect(-250, 118, 70, 50, 8, C.gray, { seed: 710, lw: 7 }); wRect(180, 118, 70, 50, 8, C.gray, { seed: 711, lw: 7 });
  ctx.restore();
}
/** simple sun disc for the temperature comparison */
export function sunDisc(x, y, r) {
  circle(x, y, r, C.yellow); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
}
