// MOON-LONG props (same inked look): moon, sun, tide Earth, retroreflector, corner cube, laser, clam, rock layers, eclipse discs, red giant.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, rnd, circle, line, ell, blob, poly, wEll, wRect, inkLine, fillAll } from './lib.js';
import * as R from './space.js';
import * as G from './gps.js';
import * as K from './kit.js';

export const MOON = '#E6E1D8', CRATER = '#C9C3B8', GROUND = '#B9B3A9';
/** the Moon: pale disc, soft craters, ink outline */
export function moon(x, y, r, o = {}) {
  const { hi = false } = o;
  ctx.save(); ctx.translate(x, y);
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = MOON; ctx.fill(); ctx.save(); ctx.clip();
  for (const [cx, cy, cr] of [[-0.35, -0.3, 0.2], [0.3, -0.45, 0.14], [0.45, 0.15, 0.24], [-0.15, 0.4, 0.17], [-0.55, 0.2, 0.1], [0.05, -0.05, 0.09]]) { circle(cx * r, cy * r, cr * r, CRATER); ctx.lineWidth = 5; ctx.strokeStyle = '#A9A399'; ctx.stroke(); }
  ctx.restore();
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.lineWidth = 9; ctx.strokeStyle = hi ? C.orange : C.ink; ctx.stroke(); if (hi) { ctx.lineWidth = 3; ctx.strokeStyle = C.ink; ctx.beginPath(); ctx.arc(0, 0, r + 6, 0, TAU); ctx.stroke(); }
  ctx.restore();
}
export function sun(x, y, r, color = C.yellow) {
  ctx.save(); ctx.translate(x, y);
  for (let i = 0; i < 12; i++) { const a = i / 12 * TAU; poly([[Math.cos(a - 0.12) * r * 1.08, Math.sin(a - 0.12) * r * 1.08], [Math.cos(a) * r * 1.38, Math.sin(a) * r * 1.38], [Math.cos(a + 0.12) * r * 1.08, Math.sin(a + 0.12) * r * 1.08]], color, { seed: 700 + i, lw: 6 }); }
  circle(0, 0, r, color); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.restore();
}
export function redGiant(x, y, r) {
  circle(x, y, r * 1.18, C.orange); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  circle(x, y, r, C.red); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
}
/** Earth with an ocean shell that bulges toward (b1) and away from (b2) the Moon. ang = direction of the Moon, shift = bulge axis offset (rad), rot = land spin */
export function tideEarth(x, y, r, o = {}) {
  const { ang = 0, b1 = 0, b2 = 0, shift = 0, rot = 0, bulge = 0.85, land = true } = o;
  const P = [], n = 72;
  for (let i = 0; i < n; i++) {
    const th = (i / n) * TAU, c = Math.cos(th - ang - shift);
    const rad = r * (1.1 + bulge * 0.34 * b1 * Math.pow(Math.max(0, c), 3) + bulge * 0.34 * b2 * Math.pow(Math.max(0, -c), 3));
    P.push([x + Math.cos(th) * rad, y + Math.sin(th) * rad]);
  }
  blob(P, R.SEA_HI, { seed: 9, lw: 8, wob: 0.6 });
  if (land) G.globe(x, y, r, rot); else { circle(x, y, r, '#9C8F7E'); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke(); }
}
/** retroreflector panel: grid of glass cubes in an aluminium frame (10 x 10) */
export function reflector(x, y, s = 1, hi = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-190, -190, 380, 380, 18, '#B5B0AA', { seed: 640, lw: 9 });
  for (let i = 0; i < 10; i++) for (let j = 0; j < 10; j++) { circle(-153 + i * 34, -153 + j * 34, 13, hi && (i + j) % 2 === 0 ? C.orange : '#CFE3F2'); ctx.lineWidth = 3; ctx.strokeStyle = C.ink; ctx.stroke(); }
  ctx.restore();
}
/** corner cube: three faces meeting at one corner */
export function cube(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  const k = 0.87, c = [0, 0], t = [0, -1], ru = [k, -0.5], rd = [k, 0.5], b = [0, 1], ld = [-k, 0.5], lu = [-k, -0.5];
  const f = (pts, col, sd) => poly(pts.map((p) => [p[0] * 150, p[1] * 150]), col, { seed: sd, lw: 8, wob: 1 });
  f([c, lu, t, ru], '#DCE8F2', 651); f([c, ru, rd, b], '#9FC1DE', 652); f([c, b, ld, lu], '#6F9CC4', 653);
  ctx.restore();
}
/** laser pulse beam from (x0,y0) to (x1,y1); t = clock; head = 0..1 travelling pulse */
export function laser(x0, y0, x1, y1, t = 0, head = null) {
  inkLine([[x0, y0], [x1, y1]], C.orange, 10, 4);
  if (head != null) { const px = lerp(x0, x1, head), py = lerp(y0, y1, head); circle(px, py, 24, C.yellow); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); }
}
/** a lunar ground strip with craters, drawn over a navy sky */
export function lunarGround(y = 760, t = 0) {
  R.space(t, false);
  ctx.beginPath(); ctx.moveTo(-50, y); ctx.bezierCurveTo(400, y - 50, 900, y + 40, 1300, y - 20); ctx.bezierCurveTo(1600, y - 60, 1800, y, 1980, y - 20); ctx.lineTo(1980, 1100); ctx.lineTo(-50, 1100); ctx.closePath();
  ctx.fillStyle = GROUND; ctx.fill(); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke();
  for (const [cx, cy, rx] of [[300, y + 130, 120], [1500, y + 110, 150], [960, y + 190, 90]]) { ell(cx, cy, rx, rx * 0.28, CRATER); ctx.lineWidth = 5; ctx.strokeStyle = '#A9A399'; ctx.stroke(); }
}
export function clam(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  const P = []; for (let i = 0; i <= 10; i++) { const a = Math.PI + (i / 10) * Math.PI; P.push([Math.cos(a) * 190, Math.sin(a) * 160 + 70]); } P.push([130, 80], [-130, 80]);
  blob(P, '#E8D9B8', { seed: 660, lw: 9 });
  for (let i = 1; i < 7; i++) { const a = Math.PI + (i / 7) * Math.PI; line([[0, 70], [Math.cos(a) * 170, Math.sin(a) * 145 + 70]], '#B9A57F', 6); }
  for (let k = 1; k < 4; k++) { ctx.beginPath(); ctx.ellipse(0, 70, 55 * k, 48 * k, 0, Math.PI, 0); ctx.lineWidth = 4; ctx.strokeStyle = '#B9A57F'; ctx.stroke(); }
  ctx.restore();
}
/** stack of rock layers */
export function layers(x, y, w, n = 6, hiIdx = -1) {
  const cols = ['#D9C7A3', '#C2A987', '#E6D8BA', '#B79B78', '#DCCBA6', '#C8B08C'];
  for (let i = 0; i < n; i++) wRect(x - w / 2, y + i * 62, w, 62, 6, i === hiIdx ? C.orange : cols[i % cols.length], { seed: 670 + i, lw: 6, wob: 1 });
}
/** sun disc + moon disc eclipse. mr = moon radius, sr = sun radius, dx = moon offset */
export function eclipse(x, y, sr, mr, dx = 0, o = {}) {
  const { corona = true } = o;
  ctx.save(); ctx.translate(x, y);
  circle(0, 0, sr, C.yellow); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  circle(dx, 0, mr, '#2A3040'); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  if (corona && mr >= sr) { ctx.beginPath(); ctx.arc(dx, 0, mr + 22, 0, TAU); ctx.lineWidth = 14; ctx.strokeStyle = C.orange; ctx.globalAlpha = 0.9; ctx.stroke(); ctx.globalAlpha = 1; }
  ctx.restore();
}
/** stack of source pages with a check */
export function pages(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  for (let i = 2; i >= 0; i--) { ctx.save(); ctx.translate(i * 26, -i * 20); wRect(-150, -190, 300, 380, 12, i === 0 ? C.white : '#F2EEE6', { seed: 680 + i, lw: 7 }); if (i === 0) { for (let k = 0; k < 7; k++) line([[-110, -140 + k * 42], [k % 3 === 2 ? 20 : 110, -140 + k * 42]], '#B5B0AA', 8); } ctx.restore(); }
  ctx.restore();
}
/** curved spin arrow around (x, y) radius r */
export function spin(x, y, r, a0 = 0.2, a1 = 1.6, color = C.orange) {
  ctx.save(); ctx.translate(x, y); ctx.beginPath(); ctx.arc(0, 0, r, Math.PI * a0, Math.PI * a1); ctx.lineWidth = 22; ctx.strokeStyle = C.ink; ctx.lineCap = 'round'; ctx.stroke(); ctx.lineWidth = 11; ctx.strokeStyle = color; ctx.stroke();
  const a = Math.PI * a1, px = Math.cos(a) * r, py = Math.sin(a) * r, tx = -Math.sin(a), ty = Math.cos(a);
  poly([[px + tx * 46, py + ty * 46], [px - ty * 30, py + tx * 30], [px + ty * 30, py - tx * 30]], color, { seed: 690, lw: 6 });
  ctx.restore();
}
export function nightSky(t = 0) { R.space(t, false); }
