// HOW DOES A ROCKET LAND ITSELF?  (long-form pilot, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';

const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
const PI = Math.PI;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const seaBg = (t) => { R.sky(t); R.sea(700, t); };
const DECK_Y = 706, SHIP_W = 700;
const FEET = 349;                                  // local y of the feet with legs open
function splash(x, y, p) { if (p <= 0 || p >= 1) return; ctx.save(); ctx.globalAlpha = 1 - p; for (let i = 0; i < 3; i++) { const r = 40 + p * 150 * (1 + i * 0.35); ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.16, 0, 0, TAU); ctx.lineWidth = 7; ctx.strokeStyle = C.white; ctx.stroke(); } ctx.restore(); }
function puff(x, y, p) { if (p <= 0 || p >= 1) return; ctx.save(); ctx.globalAlpha = 1 - p; for (const [dx, dy, r] of [[-60, 0, 34], [10, -14, 44], [70, 0, 30]]) { circle(x + dx * (1 + p), y + dy - p * 40, r * (1 + p * 0.8), C.white); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); } ctx.restore(); }
function speedStreaks(t, a = 0.8, x0 = 300, x1 = 1620) { ctx.save(); ctx.globalAlpha = a; for (let i = 0; i < 12; i++) { const x = lerp(x0, x1, rnd(i + 7)), y = ((t * 1400 + rnd(i) * 1000) % 1100) - 80; line([[x, y], [x, y - 150 - rnd(i + 3) * 90]], C.white, 7); } ctx.restore(); }
function dim(x0, y0, x1, y1, label, sc = 1, size = 40) {
  if (sc <= 0) return; ctx.save(); ctx.globalAlpha = clamp(sc);
  const an = Math.atan2(y1 - y0, x1 - x0), nx = -Math.sin(an) * 18, ny = Math.cos(an) * 18;
  line([[x0, y0], [x1, y1]], C.ink, 5); line([[x0 - nx, y0 - ny], [x0 + nx, y0 + ny]], C.ink, 5); line([[x1 - nx, y1 - ny], [x1 + nx, y1 + ny]], C.ink, 5); ctx.restore();
  if (label) R.pill(label, (x0 + x1) / 2, (y0 + y1) / 2, size, sc);
}
function gauge(x, y, r, v) {
  ctx.save(); ctx.lineCap = 'butt';
  ctx.beginPath(); ctx.arc(x, y, r, PI, TAU); ctx.lineWidth = 62; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, r, PI, TAU); ctx.lineWidth = 46; ctx.strokeStyle = C.white; ctx.stroke();
  ctx.beginPath(); ctx.arc(x, y, r, PI, PI + clamp(v) * PI); ctx.lineWidth = 46; ctx.strokeStyle = C.orange; ctx.stroke();
  const a = PI + clamp(v) * PI; inkLine([[x, y], [x + Math.cos(a) * (r - 20), y + Math.sin(a) * (r - 20)]], C.ink, 10, 0); circle(x, y, 22, C.ink);
  ctx.restore();
}
function forceChart(p1, p2, o = {}) {
  const base = 820, k = 1.4;
  R.paper(); line([[360, base], [1560, base]], C.ink, 6);
  R.bar(700, base, 190, 340 * k, C.orange, p1, 1); R.bar(1220, base, 190, 250 * k, C.blue, p2, 2);
  if (p1 > 0.95) R.pill('about 340 kN', 700, base - 340 * k - 50, 44);
  if (p2 > 0.95) R.pill('about 250 kN', 1220, base - 250 * k - 50, 44);
  R.pill('ONE ENGINE AT 40%', 700, 876, 38, p1 > 0.2 ? 1 : 0); R.pill('EMPTY ROCKET WEIGHT', 1220, 876, 38, p2 > 0.2 ? 1 : 0);
  if (o.line) { ctx.save(); ctx.setLineDash([22, 16]); line([[420, base - 250 * k], [1500, base - 250 * k]], C.ink, 5); ctx.restore(); }
  if (o.hi) R.pill('PUSHES HARDER THAN IT WEIGHS', 960, 330, 46, o.hi, { hi: true });
}
const FAR = (u) => [lerp(300, 1800, u), 760 - 560 * Math.sin(PI * u)];                    // path with no boostback
const BK = (u) => { const a = [960, 200], b = [640, 120], c = [420, 740]; return [(1 - u) * (1 - u) * a[0] + 2 * (1 - u) * u * b[0] + u * u * c[0], (1 - u) * (1 - u) * a[1] + 2 * (1 - u) * u * b[1] + u * u * c[1]]; };
function flightBg(t) { R.space(t, false); ctx.fillStyle = R.SEA; ctx.fillRect(-300, 800, W + 600, 400); ctx.fillStyle = C.ink; ctx.fillRect(-300, 797, W + 600, 6); wRect(250, 780, 100, 22, 4, C.grayLight, { seed: 3, lw: 5 }); R.ship(1560, 786, 280, t); R.surf(812, t); }

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;

  // ═════════ HOOK ═════════
  { const st = A(0), f41 = Wd('forty', 0) - st;
    add({ id: 'S01', at: st, cam: [960, 500], zoom: 0.04, note: 'tower of tanks falls through the sky, 41 m',
      draw(lt, d, t) {
        R.sky(t); speedStreaks(t, 0.7);
        const y = lerp(-250, 520, eio(seg(lt, 0, d - 0.3))), a = eo(seg(lt, f41, f41 + 0.4));
        R.rocket(960, y, 0.7, { fins: 1, t });
        dim(800, y - 332 * 0.7, 800, y + 284 * 0.7, '41 m', a, 44);
      } }); }
  { const st = A(1), tl = Wd('perfectly', 1) - st + 1.6;
    add({ id: 'S02', at: st, cam: [960, 520], zoom: 0.04, note: 'rocket lands on the drone ship',
      draw(lt, d, t) {
        seaBg(t); R.ship(960, DECK_Y, SHIP_W, t, 'OF COURSE I STILL LOVE YOU');
        const p = eio(seg(lt, 0.2, tl)), y = lerp(-120, DECK_Y - FEET * 0.62 - 6, p), fl = 1 - seg(lt, tl - 0.4, tl);
        R.rocket(960, y, 0.62, { legs: 1, fins: 1, flame: fl * 0.5, nozzles: 1, t });
        puff(960, DECK_Y - 8, seg(lt, tl, tl + 0.9)); R.surf(790, t);
      } });
    cue(st + tl, 'thud', { gain: 0.5 }); }
  { const st = A(2), six = Wd('six', 2) - st;
    add({ id: 'S03', at: st, cam: [960, 520], zoom: 0.04, note: 'nine minutes clock',
      draw(lt, d, t) { R.paper(); K.clock(960, 460, 1.5, lt * 0.9); R.pill('about 9 minutes after launch', 960, 760, 54, eob(seg(lt, 0.3, 0.7))); } });
    add({ id: 'S03b', at: st + six - 0.1, cam: [960, 520], zoom: 0.04, note: '600+ landings counter',
      draw(lt, d, t) { R.paper(); const n = Math.round(600 * eo(seg(lt, 0.1, 1.1))); R.txt(n + '+', 960, 430, 300, C.orange, 'center', 2); R.pill('booster landings so far', 960, 680, 54, eob(seg(lt, 0.4, 0.8))); } }); }
  add({ id: 'S04', at: A(3), cam: [1200, 540], zoom: 0.05, note: 'host asks the question',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, eob(seg(lt, 0.2, 0.6)) * 0.8, -0.1); R.pill('HOW DOES A ROCKET LAND ITSELF?', 700, 450, 56, eob(seg(lt, 0.1, 0.5))); } });

  // ═════════ 1 · WHY BOTHER ═════════
  add({ id: 'S05', at: A(4), cam: [700, 540], zoom: 0.05, chap: [1, 'WHY BOTHER?'], note: 'host shrugs',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, brow: 0.7 }); } });
  { const st = Wc('most', 4);
    add({ id: 'S06', at: st, cam: [960, 520], zoom: 0.04, note: 'expendable stage falls into the sea and sinks',
      draw(lt, d, t) {
        seaBg(t); const p = seg(lt, 0.3, 2.6), y = lerp(-250, 760, eo(p)), rot = lerp(0.05, 0.9, p);
        R.rocket(960, y, 0.5, { rot, fins: 1, t }); R.surf(780, t);
        splash(960, 776, seg(lt, 2.1, 3.2));
        const sink = seg(lt, 3.2, d); if (sink > 0) { /* hull sinks under the surf strip */ }
        R.pill('USED ONCE', 960, 300, 56, eob(seg(lt, Wd('gone', 4) - st, Wd('gone', 4) - st + 0.3)), { hi: true });
      } }); }
  { const st = A(5);
    add({ id: 'S07', at: st, cam: [960, 500], zoom: 0.04, note: 'jumbo jet across the Atlantic, then into the bin',
      draw(lt, d, t) {
        R.paper(); const thr = Wd('throwing', 5) - st, p = seg(lt, 0, thr - 0.2);
        R.pill('LONDON', 300, 760, 40); R.pill('NEW YORK', 1620, 760, 40);
        const jx = lerp(300, 1500, eio(p)), jy = 380 - 120 * Math.sin(p * PI);
        const fall = eo(seg(lt, thr, thr + 0.9));
        ctx.save(); ctx.translate(lerp(jx, 1560, fall), lerp(jy, 650, fall)); ctx.rotate(fall * 1.2);
        wEll(0, 0, 150, 30, C.white, { seed: 5 }); poly([[-20, 0], [-90, -70], [-60, -70], [30, 0]], C.blue, { seed: 6 }); poly([[-20, 6], [-90, 76], [-60, 76], [30, 6]], C.blue, { seed: 7 }); poly([[-120, -4], [-160, -56], [-136, -56], [-96, -4]], C.orange, { seed: 8 });
        ctx.restore();
        wRect(1500, 640, 120, 130, 12, C.grayLight, { seed: 9 }); wRect(1488, 622, 144, 26, 8, C.gray, { seed: 10 });
        if (fall > 0.8) K.redX(1560, 400, 0.22, 1);
      } }); }
  { const st = A(6), sixty = Wc('sixty', 6), fuel = Wc('fuel', 6);
    add({ id: 'S08', at: st, cam: [700, 540], zoom: 0.05, note: 'stack with first stage highlighted',
      draw(lt, d, t) {
        R.paper(); R.rocket(700, 560, 0.5, { upper: 30, t });
        R.callout('FIRST STAGE', 1160, 600, 706, 580, 46, eob(seg(lt, 1.0, 1.4)), { hi: true }); R.callout('SECOND STAGE', 1180, 290, 706, 300, 40, eob(seg(lt, 2.4, 2.8)));
      } });
    add({ id: 'S08b', at: sixty, cam: [700, 480], zoom: 0.04, note: 'cost pie',
      draw(lt, d, t) {
        R.paper(); R.pie(640, 470, 270, [{ v: 0.6, color: C.orange }, { v: 0.2, color: C.blue }, { v: 0.1, color: C.yellow }, { v: 0.1, color: C.grayLight }], eo(seg(lt, 0, 0.9)), 0);
        R.pill('FIRST STAGE  about 60%', 1380, 330, 46, eob(seg(lt, 0.5, 0.9)), { hi: true });
        R.pill('SECOND STAGE  about 20%', 1380, 440, 40, eob(seg(lt, 1.2, 1.5))); R.pill('FAIRING  about 10%', 1380, 540, 40, eob(seg(lt, 1.5, 1.8))); R.pill('EVERYTHING ELSE  about 10%', 1380, 640, 40, eob(seg(lt, 1.8, 2.1)));
      } });
    add({ id: 'S08c', at: fuel, cam: [960, 520], zoom: 0.04, note: 'fuel is cheap',
      draw(lt, d, t) { R.paper(); K.coin(700, 520, 1.1); K.coin(840, 560, 0.9); K.coin(760, 640, 0.9); R.pill('FUEL: $200,000 to $300,000', 1180, 470, 58, eob(seg(lt, 0.2, 0.6))); R.pill('per launch  (Musk)', 1180, 580, 40, eob(seg(lt, 0.8, 1.2))); } }); }
  { const st = A(7), idea = Wc('whole', 7);
    add({ id: 'S09', at: st, cam: [960, 520], zoom: 0.04, note: 'fly again loop',
      draw(lt, d, t) {
        R.paper(); R.rocket(960, 520, 0.55, { legs: 1, fins: 1, t });
        ctx.save(); ctx.lineWidth = 12; ctx.strokeStyle = C.orange; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(960, 500, 330, -2.6 + lt * 0.4, 2.4 + lt * 0.4); ctx.stroke(); ctx.restore();
        R.pill('FLY IT AGAIN', 1420, 300, 52, eob(seg(lt, 0.5, 0.9)), { hi: true }); R.pill('CHEAPER LAUNCHES', 500, 760, 46, eob(seg(lt, Wd('cheaper', 7) - st, Wd('cheaper', 7) - st + 0.3)));
      } });
    add({ id: 'S10', at: idea, cam: [700, 540], zoom: 0.05, note: 'host with a bulb',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); K.bulb(900, 330 + Math.sin(lt * 3) * 8, 1.0, 1); } }); }

  // ═════════ 2 · WHY IT'S HARD ═════════
  add({ id: 'S11', at: A(8), cam: [700, 540], zoom: 0.05, chap: [2, "WHY IT'S HARD"], note: 'host winces',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.hip, armL: K.ARM.hip, frown: 0.6, sweat: lt > 1, brow: 0.8, eyes: 'wide' }); } });
  { const st = Wc('think', 8), bul = Wc('bullet', 8);
    add({ id: 'S12', at: st, cam: [960, 540], zoom: 0.05, note: 'host balances a broomstick',
      draw(lt, d, t) {
        R.studio(880); const wob = Math.sin(lt * 4) * 0.12;
        host(960, lt, { arm: K.ARM.hold, armL: K.ARM.hip, holding: (x, y) => { ctx.save(); ctx.translate(x + 40, y - 20); ctx.rotate(wob); inkLine([[0, 0], [0, -330]], C.hair, 16, 6); poly([[-26, -330], [26, -330], [40, -400], [-40, -400]], C.yellow, { seed: 12, wob: 1.2 }); ctx.restore(); } });
      } });
    add({ id: 'S13', at: bul, cam: [960, 540], zoom: 0.05, note: 'on a boat, fast',
      draw(lt, d, t) {
        seaBg(t); const bob = Math.sin(lt * 3) * 6, wob = Math.sin(lt * 5) * 0.15;
        speedStreaks(t, 0.0); ctx.save(); ctx.globalAlpha = 0.8; for (let i = 0; i < 6; i++) line([[620 - i * 40, 560 + i * 28 + bob], [380 - i * 40 - (lt * 300) % 80, 560 + i * 28 + bob]], C.white, 8); ctx.restore();
        K.host({ x: 960, y: 450 + bob, s: 0.33, arm: K.ARM.hold, armL: K.ARM.hip, mouth: 'o', eyes: 'wide', holding: (x, y) => { ctx.save(); ctx.translate(x + 40, y - 20); ctx.rotate(wob); inkLine([[0, 0], [0, -330]], C.hair, 16, 6); poly([[-26, -330], [26, -330], [40, -400], [-40, -400]], C.yellow, { seed: 12, wob: 1.2 }); ctx.restore(); } });
        poly([[780, 640 + bob], [1140, 640 + bob], [1090, 720 + bob], [830, 720 + bob]], C.orange, { seed: 14 }); R.surf(740, t);
        R.pill('faster than a bullet', 960, 220, 48, eob(seg(lt, 0.3, 0.7)));
      } }); }
  add({ id: 'S14', at: A(9), cam: [960, 500], zoom: 0.04, note: "can't hover",
    draw(lt, d, t) { R.sky(t); R.rocket(960, 500 + Math.sin(lt * 2) * 6, 0.6, { legs: 1, fins: 1, flame: 0.4, nozzles: 1, t }); K.redX(960, 480, 0.55, eob(seg(lt, 1.0, 1.4))); R.pill("A ROCKET CAN'T HOVER", 960, 840, 56, eob(seg(lt, 0.4, 0.8)), { hi: true }); } });
  { const st = A(10), few = Wc('landing', 10), forty = Wc('forty', 10);
    add({ id: 'S15', at: st, cam: [700, 520], zoom: 0.05, chap: null, note: 'nine engines at liftoff',
      draw(lt, d, t) { R.paper(); R.pill('THE MATH', 960, 190, 52, 1, { hi: true }); R.rocket(800, 520, 0.6, { flame: 1, t }); R.pill('9 ENGINES  =  about 7,600 kN', 1340, 560, 46, eob(seg(lt, Wd('nine', 10) - st, Wd('nine', 10) - st + 0.3))); } });
    add({ id: 'S16', at: few, cam: [960, 520], zoom: 0.04, note: 'throttle gauge to 40%',
      draw(lt, d, t) { R.paper(); const v = lerp(1, 0.4, eio(seg(lt, forty - few, forty - few + 1.4))); gauge(960, 700, 300, v); R.txt(Math.round(v * 100) + '%', 960, 580, 140, C.orange, 'center', 2); R.pill('LOWEST THROTTLE: 40%', 960, 790, 46, eob(seg(lt, forty - few + 1.2, forty - few + 1.6)), { hi: false }); } }); }
  add({ id: 'S17', at: A(11), cam: [700, 560], zoom: 0.04, note: 'engine bar', draw(lt, d, t) { forceChart(eo(seg(lt, 0.2, 1.4)), 0, {}); } });
  add({ id: 'S18', at: A(12), cam: [1100, 560], zoom: 0.04, note: 'weight bar', draw(lt, d, t) { forceChart(1, eo(seg(lt, 0.5, 1.7)), {}); } });
  { const st = A(13), sl = Wc('slowed', 13);
    add({ id: 'S19', at: st, cam: [960, 560], zoom: 0.04, note: 'engine beats weight', draw(lt, d, t) { forceChart(1, 1, { line: true, hi: eob(seg(lt, 0.8, 1.2)) }); } });
    add({ id: 'S20', at: sl, cam: [960, 520], zoom: 0.04, note: 'shoots up again',
      draw(lt, d, t) {
        R.sky(t); const p = seg(lt, 1.6, 3.6), y = lerp(520, -500, p * p);
        if (p > 0) speedStreaks(t, 0.7);
        R.rocket(960, y, 0.6, { legs: 1, fins: 1, flame: 0.45 + p * 0.5, nozzles: 1, t });
        R.pill('THRUST  >  WEIGHT', 440, 760, 50, eob(seg(lt, 0.3, 0.7)));
      } }); }
  { const st = A(14);
    add({ id: 'S21', at: st, cam: [960, 520], zoom: 0.04, note: 'speed hits zero as the legs touch',
      draw(lt, d, t) {
        seaBg(t); R.ship(960, DECK_Y, SHIP_W, t); const end = d - 1.0, p = eio(seg(lt, 0.2, end)), y = lerp(80, DECK_Y - FEET * 0.62 - 6, p);
        R.rocket(960, y, 0.62, { legs: 1, fins: 1, flame: 0.5 * (1 - seg(lt, end - 0.3, end)), nozzles: 1, t }); R.surf(790, t);
        const sp = Math.max(0, Math.round(lerp(60, 0, eo(p)))); R.pill('SPEED  ' + sp + ' m/s', 400, 250, 52, 1, { hi: sp === 0 });
      } }); }

  // ═════════ 3 · THE FOUR STEPS ═════════
  { const st = A(15), lets = Wc('lets', 15), carries = Wc('carries', 15);
    add({ id: 'S22', at: st, cam: [960, 540], zoom: 0.04, chap: [3, 'FOUR STEPS'], note: 'stack climbing, 80 km',
      draw(lt, d, t) { R.space(t); R.rocket(960, 560, 0.5, { upper: 30, flame: 1, t }); R.ruler(1500, 820, 200, 4, seg(lt, 0, lets - st)); R.pill('about 80 km up', 1500, 140, 44, eob(seg(lt, 2.0, 2.4))); } });
    add({ id: 'S22b', at: lets, cam: [960, 500], zoom: 0.04, note: 'stage separation',
      draw(lt, d, t) {
        R.space(t); const gap = 30 + eo(seg(lt, 0.2, 2.2)) * 260;
        R.rocket(960, lerp(580, 640, eo(seg(lt, 0, 2.2))), 0.5, { upper: gap, upperFlame: seg(lt, 0.9, 1.3), t });
        R.pill('SEPARATION', 520, 520, 48, eob(seg(lt, 0.2, 0.6)), { hi: true });
      } });
    add({ id: 'S22c', at: carries, cam: [960, 540], zoom: 0.04, note: 'second stage goes on',
      draw(lt, d, t) { R.space(t); R.rocket(960, 640, 0.5, { t }); R.callout('FIRST STAGE: COMING BACK', 560, 520, 940, 560, 42, eob(seg(lt, 0.2, 0.6)), { hi: true }); R.callout('SECOND STAGE: TO ORBIT', 1400, 200, 1400, 90, 40, eob(seg(lt, 0.6, 1.0))); } }); }
  { const st = A(16), flip = Wc('flip', 16);
    add({ id: 'S23', at: st, cam: [960, 540], zoom: 0.04, note: 'spent tower coasting up',
      draw(lt, d, t) { R.space(t); R.stepTracker(0, eo(seg(lt, flip - st, flip - st + 0.4))); R.rocket(960, 540 - lt * 8, 0.55, { fins: 0, t }); R.pill('SPENT FIRST STAGE', 560, 700, 44, eob(seg(lt, 0.4, 0.8))); } }); }
  { const st = A(17), turn = Wc('turn', 17), eng = Wc('engines', 17);
    add({ id: 'S24', at: st, cam: [960, 540], zoom: 0.04, note: 'nitrogen thrusters flip the stage',
      draw(lt, d, t) {
        R.space(t); R.stepTracker(0); const rot = PI * eio(seg(lt, turn - st, turn - st + 2.6)), on = (lt > turn - st && lt < turn - st + 3) ? 1 : 0;
        R.rocket(960, 540, 0.55, { rot, puffs: on, t }); R.callout('NITROGEN GAS THRUSTERS', 1380, 250, 1010, 360 + Math.cos(rot) * 0, 40, eob(seg(lt, 0.4, 0.8)));
        R.pill('ENGINES FORWARD', 540, 800, 44, eob(seg(lt, eng - st, eng - st + 0.3)), { hi: true });
      } }); }
  { const st = A(18), three = Wd('three', 18) - st, send = Wd('send', 18) - st;
    const boost = (off) => (lt, d, t) => {
      const tt = lt + off;
      flightBg(t); R.stepTracker(1); R.trail(FAR, 0, 1, { color: '#55607A', w: 6 }); R.pill('WITHOUT BOOSTBACK', 1500, 420, 38, eob(seg(tt, 1.0, 1.4)));
      const p = seg(tt, three, three + 2.6); R.trail(BK, 0, eo(p), { color: C.orange, w: 10, dash: [26, 16] });
      const [bx, by] = p > 0 ? BK(eo(p)) : FAR(0.4);
      R.rocket(bx, by, 0.26, { rot: -PI / 2 + 0.2, flame: seg(tt, three, three + 0.4) * (1 - seg(tt, three + 2.3, three + 2.6)), nozzles: 3, t });
      R.pill('BOOSTBACK BURN', 960, 880, 44, eob(seg(tt, 0.2, 0.6)), { hi: true }); if (tt > three) R.pill('3 ENGINES FIRE', 960, 780, 40, eob(seg(tt, three, three + 0.3)));
    };
    add({ id: 'S25', at: st, cam: [960, 500], zoom: 0.04, note: 'boostback burn: setup', draw: boost(0) });
    add({ id: 'S25b', at: Wd('three', 18) - 0.06, cam: [960, 300], zoom: 0.12, note: 'boostback burn: fire', draw: boost(Wd('three', 18) - 0.06 - st) });
    add({ id: 'S25c', at: Wd('send', 18) - 0.06, cam: [560, 640], zoom: 0.14, note: 'heading back to the coast', draw: (lt, d, t) => { boost(Wd('send', 18) - 0.06 - st)(lt, d, t); R.pill('BACK TOWARD THE COAST', 700, 330, 42, eob(seg(lt, 0.3, 0.7)), { hi: true }); } });
    add({ id: 'S26', at: Wc('some', 18), cam: [1300, 540], zoom: 0.04, note: 'boostback sometimes skipped',
      draw(lt, d, t) { flightBg(t); R.trail(FAR, 0, 1, { color: C.orange, w: 10 }); R.pill('SHIP FAR DOWNRANGE', 1400, 420, 46, eob(seg(lt, 0.2, 0.6))); R.pill('NO BOOSTBACK NEEDED', 1400, 520, 46, eob(seg(lt, 0.7, 1.1)), { hi: true }); } }); }
  { const st = A(19), noair = Wc('air', 19);
    add({ id: 'S27', at: st, cam: [960, 400], zoom: 0.04, note: 'coasting over the top',
      draw(lt, d, t) {
        flightBg(t); R.stepTracker(1, 0.35); R.trail(BK, 0, 1, { color: C.orange, w: 10, dash: [26, 16] });
        const p = clamp(lt / (noair - st + 1.5)), [bx, by] = BK(lerp(0.02, 0.35, p)); R.rocket(bx, by, 0.26, { rot: lerp(-PI / 2, -PI * 0.9, p), puffs: 1, t });
        R.pill('NO AIR UP HERE', 1300, 300, 46, eob(seg(lt, noair - st, noair - st + 0.3)), { hi: true });
      } }); }
  { const st = A(20), around = Wc('around', 20), from = Wd('roughly', 20) - 0.06;
    const entry = (off, close) => (lt, d, t) => {
      const tt = lt + off;
      R.space(t, false); ctx.fillStyle = R.SKY_LO; ctx.fillRect(-300, 520, W + 600, 700); ctx.fillStyle = C.ink; ctx.fillRect(-300, 517, W + 600, 6); R.stepTracker(2);
      const y = 300 + tt * 22; R.rocket(960, Math.min(y, 640), close ? 0.62 : 0.5, { fins: 1, flame: 0.8, nozzles: 3, t });
      if (close) { ctx.save(); ctx.globalAlpha = 0.55; for (let i = 0; i < 9; i++) { const x = 700 + rnd(i) * 520, yy = ((t * 900 + rnd(i + 4) * 800) % 700) + 100; line([[x, yy], [x, yy + 80]], C.white, 6); } ctx.restore(); }
      const v = Math.round(lerp(3000, 560, eio(seg(tt, from - st, around - st + 1.2))) / 10) * 10;
      if (close) R.pill(v.toLocaleString('en-US') + ' mph', 520, 300, 64, eob(seg(lt, 0.2, 0.6)), { hi: true });
      R.pill('ENTRY BURN', 1420, 300, 44, eob(seg(tt, 0.3, 0.7)));
    };
    add({ id: 'S28', at: st, cam: [960, 540], zoom: 0.04, note: 'entry burn', draw: entry(0, false) });
    add({ id: 'S28b', at: from, cam: [960, 560], zoom: 0.1, note: 'speed counter drops', draw: entry(from - st, true) }); }
  { const st = A(21), feath = Wc('feathers', 21);
    add({ id: 'S29', at: st, cam: [960, 520], zoom: 0.04, note: 'four grid fins unfold',
      draw(lt, d, t) { R.sky(t); R.stepTracker(2); R.rocket(960, 520, 0.7, { fins: eio(seg(lt, 1.0, 2.2)), t }); R.callout('4 GRID FINS', 1400, 260, 1020, 360, 46, eob(seg(lt, 1.6, 2.0)), { hi: true }); } });
    add({ id: 'S29b', at: Wc('together', 21), cam: [960, 520], zoom: 0.04, note: 'like feathers on a dart',
      draw(lt, d, t) {
        R.sky(t); R.stepTracker(2); R.rocket(660, 520, 0.7, { fins: 1, t });
        ctx.save(); ctx.translate(1260, 520); ctx.rotate(PI); inkLine([[0, -230], [0, 200]], C.sweater, 16, 5); poly([[-26, 200], [26, 200], [0, 290]], C.gray, { seed: 21, wob: 0.8 }); poly([[0, -230], [-70, -300], [-20, -170]], C.orange, { seed: 22 }); poly([[0, -230], [70, -300], [20, -170]], C.orange, { seed: 23 }); poly([[0, -180], [-60, -250], [-14, -130]], C.orange, { seed: 24 }); ctx.restore();
        R.pill('LIKE THE FEATHERS ON A DART', 960, 840, 44, eob(seg(lt, 0.4, 0.8)));
      } }); }
  add({ id: 'S31', at: A(22), cam: [960, 500], zoom: 0.06, note: 'one piece of titanium',
    draw(lt, d, t) {
      R.paper(); ctx.save(); ctx.translate(960, 470); ctx.rotate(Math.sin(lt * 0.8) * 0.05);
      wRect(-260, -200, 520, 400, 14, C.sweater, { seed: 31 }); ctx.strokeStyle = C.grayLight; ctx.lineWidth = 8; for (let i = 1; i < 6; i++) { line([[-260 + i * 86.7, -190], [-260 + i * 86.7, 190]], C.grayLight, 8); } for (let j = 1; j < 4; j++) line([[-250, -200 + j * 100], [250, -200 + j * 100]], C.grayLight, 8);
      ctx.restore(); R.pill('CAST FROM ONE PIECE OF TITANIUM', 960, 800, 48, eob(seg(lt, 0.4, 0.8)), { hi: true });
    } });
  { const st = A(23), legs = Wd('legs', 23) - st;
    add({ id: 'S32', at: st, cam: [960, 520], zoom: 0.04, note: 'landing burn, legs fold out',
      draw(lt, d, t) {
        seaBg(t); R.ship(960, DECK_Y, SHIP_W, t); R.stepTracker(3);
        const p = eio(seg(lt, 0.4, d - 0.2)), y = lerp(150, DECK_Y - FEET * 0.62 - 300, p) + 0; R.rocket(960, y, 0.62, { legs: eio(seg(lt, legs, legs + 0.9)), fins: 1, flame: 0.55, nozzles: 1, t }); R.surf(790, t);
        R.pill('LAST 30 SECONDS or so', 440, 300, 44, eob(seg(lt, 0.3, 0.7)));
      } }); }
  add({ id: 'S33', at: A(24), cam: [960, 560], zoom: 0.05, note: 'legs open, 18 m wide',
    draw(lt, d, t) {
      R.paper(); R.rocket(960, 440, 0.95, { legs: 1, fins: 1, t }); const s = 0.95;
      dim(960 - 168 * s, 850, 960 + 168 * s, 850, '18 m', eob(seg(lt, 2.6, 3.0)), 44); R.callout('CARBON FIBER + ALUMINUM HONEYCOMB', 1470, 330, 1090, 640, 38, eob(seg(lt, 0.5, 0.9)), { hi: true });
    } });
  { const st = A(25), brisk = Wc('brisk', 25), then = Wd('then', 25) - 0.06;
    add({ id: 'S34', at: st, cam: [960, 520], zoom: 0.04, note: 'touchdown at 5 mph',
      draw(lt, d, t) {
        seaBg(t); R.ship(960, DECK_Y, SHIP_W, t); const p = eio(seg(lt, 0.1, 3.4)), y = lerp(250, DECK_Y - FEET * 0.62 - 6, p);
        R.rocket(960, y, 0.62, { legs: 1, fins: 1, flame: 0.4 * (1 - seg(lt, 3.1, 3.4)), nozzles: 1, t }); puff(960, DECK_Y - 8, seg(lt, 3.4, 4.3)); R.surf(790, t);
        R.pill('touchdown speed: about 5 mph', 460, 260, 46, eob(seg(lt, 0.8, 1.2)), { hi: true });
      } });
    add({ id: 'S34c', at: brisk, cam: [960, 520], zoom: 0.04, note: 'a brisk walk, standing upright',
      draw(lt, d, t) { seaBg(t); R.ship(960, DECK_Y, SHIP_W, t, 'OF COURSE I STILL LOVE YOU'); R.rocket(960, DECK_Y - FEET * 0.62 - 6, 0.62, { legs: 1, fins: 1, t }); R.surf(790, t); R.pill('a brisk walk', 460, 250, 52, eob(seg(lt, 0.1, 0.5))); R.pill('about 9 minutes after liftoff', 960, 190, 46, eob(seg(lt, then - brisk, then - brisk + 0.3)), { hi: true }); } }); }

  // ═════════ 4 · THE BRAIN ═════════
  add({ id: 'S37', at: A(26), cam: [700, 540], zoom: 0.05, chap: [4, 'THE BRAIN'], note: 'nobody is flying it',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, brow: 0.6 }); R.pill('NO PILOT', 1240, 330, 56, eob(seg(lt, Wd('nobody', 26) - A(26), Wd('nobody', 26) - A(26) + 0.3)), { hi: true }); R.pill('NO REMOTE CONTROL', 1240, 450, 46, eob(seg(lt, Wd('ground', 26) - A(26), Wd('ground', 26) - A(26) + 0.3))); } });
  { const st = A(27), cvx = Wc('convex', 27), simp = Wc('simple', 27);
    add({ id: 'S38', at: st, cam: [960, 520], zoom: 0.04, note: 'onboard computer',
      draw(lt, d, t) { R.paper(); K.chip(960, 470, 1.3, C.orange); R.pill('ONBOARD COMPUTER', 960, 800, 52, eob(seg(lt, 0.3, 0.7))); R.pill('CONVEX OPTIMIZATION', 960, 190, 52, eob(seg(lt, cvx - st, cvx - st + 0.3)), { hi: true }); } });
    add({ id: 'S39', at: simp, cam: [960, 520], zoom: 0.04, note: 'many paths, pick the best one',
      draw(lt, d, t) {
        R.paper(); R.ship(1500, 770, 300, t); const P = (b) => (u) => [lerp(380, 1500, u) + 0, 220 + 540 * u * u * (1 - b) + 540 * u * (1 - u) * 0 + b * 340 * Math.sin(PI * u)];
        const bulges = [-0.55, -0.3, 0.0, 0.35, 0.7];
        bulges.forEach((b, i) => R.trail(P(b), 0, eo(seg(lt, 0.2 + i * 0.2, 1.4 + i * 0.2)), { color: i === 2 ? C.red : '#8C8782', w: 6, dash: [14, 14] }));
        R.trail(P(0.7), 0, eo(seg(lt, 2.4, 3.6)), { color: C.orange, w: 12, dash: [1, 0] });
        R.rocket(380, 270, 0.2, { fins: 1, t }); R.pill('THE BEST PATH THAT DOES NOT RUN OUT OF FUEL', 960, 880, 38, eob(seg(lt, 3.2, 3.6)), { hi: true });
      } }); }
  { const st = A(28), began = Wc('began', 28), later = Wc('later', 28);
    add({ id: 'S40a', at: st, cam: [960, 520], zoom: 0.04, note: 'an engineer named Lars Blackmore',
      draw(lt, d, t) { R.paper(); K.laptop(960, 470, 1.15); { const pts = []; const u = eo(seg(lt, 0.8, 2.6)); for (let i = 0; i <= 24 * u; i++) { const k = i / 24; pts.push([780 + 360 * k, 440 - 130 * Math.sin(PI * k) + 70 * k * k]); } if (pts.length > 1) line(pts, C.orange, 10); } R.pill('LARS BLACKMORE', 960, 190, 56, eob(seg(lt, 0.3, 0.7)), { hi: true }); R.pill('an engineer', 960, 800, 44, eob(seg(lt, 0.8, 1.2))); } });
    add({ id: 'S40', at: began, cam: [960, 520], zoom: 0.04, note: '2007, JPL, Mars',
      draw(lt, d, t) { R.space(t, false); circle(1300, 440, 170, C.red); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.stroke(); wEll(1240, 380, 36, 22, '#B22E22', { seed: 4, lw: 0 }); R.pill('2007  ·  NASA JET PROPULSION LAB', 700, 300, 46, eob(seg(lt, 0.3, 0.7))); R.pill('FOR LANDING ON MARS', 700, 430, 46, eob(seg(lt, Wd('mars', 28) - began, Wd('mars', 28) - began + 0.3)), { hi: true }); } });
    add({ id: 'S41', at: later, cam: [960, 520], zoom: 0.04, note: 'later SpaceX',
      draw(lt, d, t) { R.paper(); R.rocket(1300, 520, 0.55, { legs: 1, fins: 1, t }); R.pill("LATER: LED SPACEX'S", 600, 400, 48, eob(seg(lt, 0.3, 0.7))); R.pill('REUSABLE ROCKET TEAM', 600, 510, 48, eob(seg(lt, 0.6, 1.0)), { hi: true }); } }); }
  { const st = A(29), wind = Wd('wind', 29) - 0.06 - st, each = Wd('each', 29) - 0.06 - st;
    const plan = (off) => (lt, d, t) => {
      const tt = lt + off; R.paper(); R.ship(1500, 770, 300, t);
      const push = eo(seg(tt, wind, wind + 1.2)), rx = lerp(520, 700, push), ry = lerp(250, 330, push);
      const P = (x0, y0) => (u) => [lerp(x0, 1500, u), lerp(y0, 740, u * u) - 90 * Math.sin(PI * u)];
      R.trail(P(520, 250), 0, eo(seg(tt, 0.2, 1.4)), { color: push > 0.1 ? '#B5B0AA' : C.orange, w: push > 0.1 ? 6 : 12, dash: push > 0.1 ? [14, 14] : [1, 0] });
      if (push > 0.1) R.trail(P(rx, ry), 0, eo(seg(tt, wind + 1.0, wind + 2.0)), { color: C.orange, w: 12, dash: [1, 0] });
      const fly = seg(tt, each, d + off), q = tt >= each ? lerp(0.02, 0.8, eio(fly)) : 0;
      const [fx, fy] = tt >= each ? P(rx, ry)(q) : [rx, ry]; R.rocket(fx, fy, 0.2, { fins: 1, t });
      if (tt > wind - 0.3 && tt < wind + 1.6) R.arrowV(300, 330, 190, 0.1, C.blue, 26);
      if (tt < wind) R.pill('PLAN THE WHOLE DESCENT', 960, 880, 44, eob(seg(tt, 0.4, 0.8)));
      if (tt > wind && tt < each) { R.pill('WIND PUSHES IT OFF COURSE', 700, 170, 44, eob(seg(tt, wind, wind + 0.3))); R.pill('RE-PLAN IN LESS THAN A SECOND', 960, 880, 44, eob(seg(tt, wind + 1.4, wind + 1.8)), { hi: true }); }
      if (tt >= each) R.pill('about 99% sure of the landing', 960, 880, 46, eob(seg(tt, each, each + 0.3)), { hi: true });
    };
    add({ id: 'S42', at: st, cam: [900, 500], zoom: 0.05, note: 'plan the descent', draw: plan(0) });
    add({ id: 'S42b', at: st + wind, cam: [700, 400], zoom: 0.1, note: 'wind pushes it off course, replan', draw: plan(wind) });
    add({ id: 'S42c', at: st + each, cam: [1100, 560], zoom: 0.08, note: 'still 99% sure', draw: plan(each) }); }
  add({ id: 'S43', at: A(30), cam: [960, 540], zoom: 0.05, note: 'about ten meters',
    draw(lt, d, t) { R.paper(); R.shipTop(960, 470, 900, t); ctx.save(); ctx.setLineDash([16, 12]); ctx.beginPath(); ctx.arc(960, 470, 99, 0, TAU); ctx.lineWidth = 8; ctx.strokeStyle = C.orange; ctx.stroke(); ctx.restore(); R.callout('about 10 m', 1480, 250, 1050, 470, 48, eob(seg(lt, 0.8, 1.2)), { hi: true }); } });

  // ═════════ 5 · THE SHIP ═════════
  { const st = A(31), legs = Wc('legs', 31);
    add({ id: 'S44', at: st, cam: [960, 520], zoom: 0.04, chap: [5, 'THE SHIP'], note: 'drone ship side view, 91 m',
      draw(lt, d, t) { seaBg(t); R.ship(960, DECK_Y, 900, t, 'JUST READ THE INSTRUCTIONS'); R.surf(800, t); dim(510, 640, 1410, 640, '91 m', eob(seg(lt, 1.4, 1.8)), 44); R.pill('DRONE SHIP', 960, 220, 52, eob(seg(lt, 0.3, 0.7)), { hi: true }); } });
    add({ id: 'S45', at: legs, cam: [960, 520], zoom: 0.04, note: 'legs span 18 of those meters',
      draw(lt, d, t) { R.paper(); R.shipTop(960, 470, 900, t); wRect(960 - 89, 470 - 89, 178, 178, 8, null, { seed: 8, lw: 8, stroke: C.orange }); dim(1500, 470 - 257, 1500, 470 + 257, '52 m', 1, 44); dim(960 - 89, 760, 960 + 89, 760, '18 m', eob(seg(lt, 0.4, 0.8)), 44); } }); }
  add({ id: 'S46', at: A(32), cam: [960, 540], zoom: 0.04, note: 'four thrusters hold it still',
    draw(lt, d, t) { R.paper(); R.shipTop(960, 470, 900, t); for (const [sx, sy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { const p = (t * 0.8 + (sx + sy) * 0.1) % 1; ctx.save(); ctx.globalAlpha = 1 - p; ctx.beginPath(); ctx.arc(960 + sx * 430, 470 + sy * 237, 30 + p * 70, 0, TAU); ctx.lineWidth = 7; ctx.strokeStyle = C.orange; ctx.stroke(); ctx.restore(); } R.pill('4 THRUSTERS  ·  STAYS PUT, EVEN IN A STORM', 960, 880, 40, eob(seg(lt, 0.3, 0.7)), { hi: true }); } });
  { const st = A(33), of = Wc('of', 33), just = Wc('just', 33), sf = Wc('shortfall', 33), they = Wc('they', 33);
    const names = [['OF COURSE I STILL LOVE YOU', of], ['JUST READ THE INSTRUCTIONS', just], ['A SHORTFALL OF GRAVITAS', sf]];
    add({ id: 'S47', at: st, cam: [960, 520], zoom: 0.04, note: 'the ship names',
      draw(lt, d, t) {
        seaBg(t); const tt = st + lt; let nm = null; for (const [n, w] of names) if (tt >= w) nm = n;
        R.ship(960, DECK_Y, 900, t, nm || 'DRONE SHIP'); R.surf(838, t); if (nm) R.pill(nm, 960, 300, 58, eob(seg(tt, names.find((q) => q[0] === nm)[1], names.find((q) => q[0] === nm)[1] + 0.3)), { hi: true });
      } });
    add({ id: 'S48', at: they, cam: [960, 520], zoom: 0.04, note: 'from Iain M. Banks novels',
      draw(lt, d, t) { R.paper(); wRect(760, 280, 400, 520, 16, C.blue, { seed: 7 }); wRect(790, 310, 340, 140, 8, C.white, { seed: 8 }); R.txt('THE CULTURE', 960, 380, 52, C.ink); R.pill('IAIN M. BANKS  ·  SCIENCE FICTION NOVELS', 960, 880, 42, eob(seg(lt, 0.3, 0.7)), { hi: true }); } }); }

  // ═════════ 6 · FAILING FIRST ═════════
  add({ id: 'S52', at: A(34), cam: [700, 540], zoom: 0.05, chap: [6, 'FAILING FIRST'], note: 'host sweats',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, sweat: true, mouth: 'flat', brow: 0.7 }); } });
  add({ id: 'S53', at: A(35), cam: [960, 520], zoom: 0.04, note: 'Sep 2013: spins out and crashes',
    draw(lt, d, t) { seaBg(t); const p = seg(lt, 0.3, 4.2); R.rocket(lerp(760, 1000, p), lerp(-80, 700, p * p), 0.5, { rot: p * 9, fins: 0, t }); R.surf(790, t); splash(1000, 786, seg(lt, 4.0, 5.2)); R.pill('SEPTEMBER 2013', 960, 190, 52, eob(seg(lt, 0.3, 0.7))); R.pill('ROLLED OUT OF CONTROL', 960, 290, 44, eob(seg(lt, 1.2, 1.6)), { hi: true }); } });
  { const st = A(36), stuck = Wc('stuck', 36);
    add({ id: 'S54', at: st, cam: [960, 520], zoom: 0.04, note: 'Jan 2015: hit the ship hard',
      draw(lt, d, t) { seaBg(t); R.ship(960, DECK_Y, SHIP_W, t); const p = eio(seg(lt, 0.3, 3.2)); R.rocket(960, lerp(-80, DECK_Y - FEET * 0.62 - 6, p), 0.62, { rot: lerp(0, 0.35, seg(lt, 3.0, 3.6)), legs: 1, fins: 1, t }); R.surf(790, t); K.burst(960, DECK_Y - 20, 0.8 * eo(seg(lt, 3.1, 3.5)), 1 - seg(lt, 3.5, 4.2)); R.pill('JANUARY 2015', 440, 200, 50, eob(seg(lt, 0.3, 0.7))); R.pill('FINS RAN OUT OF HYDRAULIC FLUID', 960, 880, 40, eob(seg(lt, 2.0, 2.4)), { hi: true }); } });
    add({ id: 'S54b', at: Wd('because', 36) - 0.06, cam: [960, 520], zoom: 0.04, note: 'hydraulic fluid empty',
      draw(lt, d, t) { R.paper(); gauge(960, 640, 300, lerp(0.35, 0, eio(seg(lt, 0.4, 2.4)))); R.pill('HYDRAULIC FLUID FOR THE FINS', 960, 780, 48, eob(seg(lt, 0.2, 0.6))); R.pill('EMPTY', 960, 540, 80, eob(seg(lt, 2.2, 2.6)), { hi: true }); } });
    add({ id: 'S55', at: stuck, cam: [960, 520], zoom: 0.04, note: 'Apr 2015: stuck valve',
      draw(lt, d, t) { R.paper(); K.gear(960, 470, 1.6, lt * 0.5); K.redX(960, 470, 0.5, eob(seg(lt, 0.9, 1.3))); R.pill('APRIL 2015', 960, 190, 50, eob(seg(lt, 0.2, 0.6))); R.pill('A STUCK VALVE', 960, 790, 52, eob(seg(lt, 0.5, 0.9)), { hi: true }); } }); }
  { const st = A(37), first = Wc('first', 37);
    add({ id: 'S56', at: st, cam: [960, 520], zoom: 0.04, note: 'Dec 21 2015: first ground landing',
      draw(lt, d, t) { R.sky(t); R.pad(740); const p = eio(seg(lt, 0.4, 4.2)); R.rocket(960, lerp(-100, 740 - FEET * 0.62, p), 0.62, { legs: 1, fins: 1, flame: 0.5 * (1 - seg(lt, 3.9, 4.2)), nozzles: 1, t }); puff(960, 735, seg(lt, 4.2, 5.2)); R.pill('DEC 21, 2015  ·  FLORIDA', 460, 220, 48, eob(seg(lt, 0.3, 0.7))); } });
    add({ id: 'S56b', at: Wd('nine', 37) - 0.06, cam: [960, 520], zoom: 0.04, note: '9 min 45 s',
      draw(lt, d, t) { R.paper(); K.clock(960, 450, 1.4, lt * 0.6); R.pill('9 minutes 45 seconds after liftoff', 960, 780, 52, eob(seg(lt, 0.3, 0.7)), { hi: true }); } });
    add({ id: 'S57', at: first, cam: [960, 520], zoom: 0.04, note: 'the first one ever',
      draw(lt, d, t) { R.sky(t); R.pad(740); R.rocket(960, 740 - FEET * 0.62, 0.62, { legs: 1, fins: 1, t }); K.check(1380, 400, 0.45, eob(seg(lt, 0.3, 0.7))); R.pill('THE FIRST OF ITS KIND', 520, 300, 54, eob(seg(lt, 0.4, 0.8)), { hi: true }); } }); }
  { const st = A(38), mar = Wc('march', 38);
    add({ id: 'S58', at: st, cam: [960, 520], zoom: 0.04, note: 'Apr 2016: first ship landing',
      draw(lt, d, t) { seaBg(t); R.ship(960, DECK_Y, SHIP_W, t, 'OF COURSE I STILL LOVE YOU'); const p = eio(seg(lt, 0.3, 3.6)); R.rocket(960, lerp(-100, DECK_Y - FEET * 0.62 - 6, p), 0.62, { legs: 1, fins: 1, flame: 0.5 * (1 - seg(lt, 3.3, 3.6)), nozzles: 1, t }); puff(960, DECK_Y - 8, seg(lt, 3.6, 4.5)); R.surf(790, t); R.pill('APRIL 8, 2016', 440, 200, 50, eob(seg(lt, 0.3, 0.7))); R.pill('300 km out at sea', 440, 300, 40, eob(seg(lt, 1.6, 2.0))); } });
    add({ id: 'S59', at: mar, cam: [960, 520], zoom: 0.04, note: 'Mar 2017: the same booster flies again',
      draw(lt, d, t) { R.space(t); R.rocket(960, 560, 0.55, { legs: 0, fins: 0, flame: 1, t }); ctx.save(); ctx.lineWidth = 12; ctx.strokeStyle = C.orange; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(960, 500, 360, -2.6 + lt * 0.4, 2.4 + lt * 0.4); ctx.stroke(); ctx.restore(); R.pill('MARCH 30, 2017', 460, 220, 50, eob(seg(lt, 0.3, 0.7))); R.pill('THE SAME BOOSTER FLIES AGAIN', 960, 880, 44, eob(seg(lt, 0.8, 1.2)), { hi: true }); } }); }

  // ═════════ 7 · TODAY ═════════
  add({ id: 'S60', at: A(39), cam: [960, 520], zoom: 0.04, chap: [7, 'TODAY'], note: '600 landings',
    draw(lt, d, t) { R.paper(); const n = Math.round(600 * eo(seg(lt, 0.5, 3.0))); R.txt(String(n), 960, 430, 320, C.orange, 'center', 2); R.pill('BOOSTER LANDINGS  ·  APRIL 19, 2026', 960, 690, 50, eob(seg(lt, 0.8, 1.2))); } });
  { const st = A(40), closing = Wc('closing', 40), shut = Wd('shuttle', 40) - 0.06;
    const bars = (off) => (lt, d, t) => {
      const tt = lt + off; R.paper(); const base = 800, k = 11; line([[400, base], [1520, base]], C.ink, 6);
      R.bar(760, base, 220, 36 * k, C.orange, eo(seg(tt, 0.6, 2.2)), 1); R.bar(1160, base, 220, 39 * k, C.blue, eo(seg(tt, shut - st, shut - st + 1.4)), 2);
      R.pill('36 flights', 760, base - 36 * k - 50, 46, eob(seg(tt, 2.0, 2.4))); if (tt > shut - st) R.pill('39 flights', 1160, base - 39 * k - 50, 46, eob(seg(tt, shut - st + 1.2, shut - st + 1.6)));
      R.pill('ONE FALCON BOOSTER', 760, 870, 36, 1, { hi: true }); if (tt > shut - st) R.pill('ONE SHUTTLE ORBITER', 1160, 870, 36, 1);
      if (tt < closing - st) R.pill('at least 35 flights, a record of 36 by August', 960, 200, 44, eob(seg(tt, 1.2, 1.6)));
    };
    add({ id: 'S61', at: st, cam: [960, 520], zoom: 0.04, note: 'booster flights', draw: bars(0) });
    add({ id: 'S61b', at: closing, cam: [1160, 560], zoom: 0.08, note: 'closing in on the shuttle', draw: bars(closing - st) }); }
  add({ id: 'S62', at: A(41), cam: [960, 520], zoom: 0.04, note: 'Starlink satellites in orbit',
    draw(lt, d, t) { R.space(t); for (let i = 0; i < 90; i++) { const a = rnd(i) * TAU + t * (0.02 + rnd(i + 5) * 0.03), r = 1180 + 22 * Math.floor(rnd(i + 9) * 4); circle(W / 2 + Math.cos(a) * r, 1980 + Math.sin(a) * r, 5, C.white); } R.pill('more than 10,000 Starlink satellites', 960, 330, 56, eob(seg(lt, 0.4, 0.8)), { hi: true }); } });
  add({ id: 'S63', at: A(42), cam: [960, 520], zoom: 0.04, note: 'refurbish under 10% of building new',
    draw(lt, d, t) { R.paper(); const base = 800, k = 4.4; line([[400, base], [1520, base]], C.ink, 6); R.bar(760, base, 220, 100 * k, C.blue, eo(seg(lt, 0.4, 1.4)), 1); R.bar(1160, base, 220, 9 * k, C.orange, eo(seg(lt, Wd('refurbishing', 42) - A(42), Wd('refurbishing', 42) - A(42) + 1.0)), 2); R.pill('BUILD A NEW ONE', 760, 870, 36, 1); R.pill('REFURBISH: UNDER 10%', 1160, 870, 36, 1, { hi: true }); R.pill('BREAKS EVEN AFTER ABOUT 2 FLIGHTS', 960, 220, 46, eob(seg(lt, 2.0, 2.4))); } });

  // ═════════ OUTRO ═════════
  { const st = A(43), flip = Wc('flip', 43), brake = Wc('brake', 43), steer = Wc('steer', 43), burn = Wc('burn', 43);
    add({ id: 'S64', at: st, cam: [1000, 540], zoom: 0.05, note: 'recap with the four steps',
      draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip, mouth: 'talk', talk: talk(lt) }); const tt = st + lt; const act = tt >= burn ? 3 : tt >= steer ? 2 : tt >= brake ? 1 : tt >= flip ? 0 : -1; R.stepTracker(act < 0 ? 0 : act, 1); R.pill('A COMPUTER PLANS IT ALL', 700, 520, 52, eob(seg(lt, Wd('planned', 43) - st, Wd('planned', 43) - st + 0.3)), { hi: true }); } }); }
  { const st = A(44), land = Wc('landing', 44), and = Wd('now', 44) - 0.3;
    add({ id: 'S65a', at: st, cam: [960, 520], zoom: 0.04, note: 'falling backwards from the edge of space',
      draw(lt, d, t) { R.space(t, true); R.rocket(960, lerp(-200, 560, eio(seg(lt, 0.2, land - st))), 0.55, { fins: 1, t }); R.pill('FROM THE EDGE OF SPACE', 960, 190, 50, eob(seg(lt, 0.8, 1.2))); } });
    add({ id: 'S65b', at: land, cam: [960, 520], zoom: 0.04, note: 'landing on the ship',
      draw(lt, d, t) { seaBg(t); R.ship(960, DECK_Y, SHIP_W, t, 'OF COURSE I STILL LOVE YOU'); const p = eio(seg(lt, 0.2, 4.0)); R.rocket(960, lerp(-100, DECK_Y - FEET * 0.62 - 6, p), 0.62, { legs: 1, fins: 1, flame: 0.5 * (1 - seg(lt, 3.6, 4.0)), nozzles: 1, t }); puff(960, DECK_Y - 8, seg(lt, 4.0, 5.0)); R.surf(790, t); } });
    add({ id: 'S65c', at: and, cam: [1100, 540], zoom: 0.05, note: 'just another launch day',
      draw(lt, d, t) { R.sky(t); R.pad(880); const p = seg(lt, 1.5, d); R.rocket(560, lerp(880 - 284 * 0.55, -500, p * p * p), 0.55, { flame: seg(lt, 1.2, 1.6), t }); K.shadow(1300, 872, 300); K.host({ x: 1300, y: 548 + idle(lt), s: 0.5, arm: K.ARM.wave, mouth: 'grin', eyes: 'happy' }); R.pill('just another launch day', 1000, 240, 56, eob(seg(lt, 0.4, 0.8)), { hi: true }); } }); }

  return { shots: S, cues: CUES };
}
