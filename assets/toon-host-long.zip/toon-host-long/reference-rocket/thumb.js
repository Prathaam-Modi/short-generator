// THUMBNAIL scene (QS='&thumb=1'): dark sky, big rocket about to land, ship below. Text is added afterwards.
import { ctx, C, W, H, fillAll, circle } from './core/lib.js';
import * as R from './core/space.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  R.space(0, false);
  R.sea(870, 0); R.ship(1330, 860, 860, 0, 'OF COURSE I STILL LOVE YOU'); R.surf(905, 0);
  R.rocket(1330, 420, 1.0, { legs: 1, fins: 1, flame: 0.38, nozzles: 1, t: 0.35 });
}
