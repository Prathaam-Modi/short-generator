// THUMBNAIL scene (QS='&thumb=1'): dark navy, ONE big focal object: a satellite whose body is a clock. Text is added afterwards (PIL).
import { ctx, C, W, H, fillAll, circle } from './core/lib.js';
import * as R from './core/space.js';
import * as K from './core/kit.js';
import * as G from './core/gps.js';
export function drawThumb() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  fillAll('#16203A');
  for (let i = 0; i < 40; i++) { const x = ((i * 977) % 1900) + 10, y = ((i * 613) % 1000) + 10; if (x < 1000 && y > 200 && y < 800) continue; circle(x, y, 2 + (i % 3), 'rgba(255,255,255,0.55)'); }
  G.sat(1430, 400, 2.2, 0.12, false);
  K.clock(1430, 400, 1.1, 5.2);
}
