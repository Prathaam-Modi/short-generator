// LONG-FORM STYLE SHEET (1920x1080): the look and the layout rules in one image.
//   QS='&sheet=1' node tools/capture.mjs frames review/sheet "0"
import { ctx, C, W, H, fillAll, circle, line, wRect, inkLine } from './core/lib.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';

const T = (s, x, y, size = 30, color = C.ink, align = 'left') => R.txt(s, x, y, size, color, align, 1);
function subtitle(text, hiWord) {
  ctx.save(); ctx.font = '900 58px Inter'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  const ws = text.split(' '), sp = 16, widths = ws.map((w) => ctx.measureText(w).width), tw = widths.reduce((a, b) => a + b, 0) + sp * (ws.length - 1);
  let x = W / 2 - tw / 2;
  ws.forEach((w, i) => { ctx.lineWidth = 12; ctx.strokeStyle = C.ink; ctx.strokeText(w, x, 988); ctx.fillStyle = w.replace(/[^A-Za-z]/g, '') === hiWord ? C.orange : C.white; ctx.fillText(w, x, 988); x += widths[i] + sp; });
  ctx.restore();
}
function frame(i, title, sub, draw) {
  const sc = 420 / W, x = 60 + i * 460, y = 170;
  ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc); ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.clip(); draw(); ctx.restore();
  ctx.save(); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.strokeRect(x, y, 420, 236); ctx.restore();
  T(title, x + 210, y + 236 + 32, 26, C.ink, 'center'); T(sub, x + 210, y + 236 + 62, 20, C.gray, 'center');
}

export function drawSheet() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.letterSpacing = '0px';
  fillAll(C.bg);
  T('TOON HOST', 60, 70, 64); T('LONG-FORM  ·  16:9  ·  CALM, CLEAN, ONE IDEA PER SHOT', 60, 128, 24, C.gray);

  frame(0, 'THE HOST SHOT', 'studio grey, host at the side, 1 label', () => {
    R.studio(880); K.shadow(1330, 880, 420); K.host({ x: 1330, y: 548, s: 0.5, arm: K.ARM.open, armL: K.ARM.hip, mouth: 'talk', talk: 0.7 });
    R.pill('HOW DOES IT LAND?', 640, 430, 64); subtitle('So how does a rocket land itself?', 'itself?');
  });
  frame(1, 'THE EXPLAINER SHOT', 'sky, sea, ship + rocket, 2 labels', () => {
    R.sky(0); R.sea(800, 0); R.ship(1000, 790, 560, 0, 'OF COURSE I STILL LOVE YOU'); R.surf(840, 0);
    R.rocket(1000, 520, 0.62, { legs: 1, fins: 1, flame: 0.35, nozzles: 1, t: 0.3 });
    R.callout('4 LEGS · 18 m WIDE', 560, 380, 940, 640, 46); subtitle('The legs open and it touches down.', 'touches');
  });
  frame(2, 'THE SPACE SHOT', 'navy sky, Earth limb, tracker top', () => {
    R.space(0); R.stepTracker(1); R.rocket(960, 420, 0.7, { rot: Math.PI * 0.8, fins: 0, flame: 0.7, nozzles: 3, puffs: 1, t: 0.2 });
    R.pill('NITROGEN THRUSTERS', 1400, 330, 44); subtitle('Little thrusters squirt nitrogen gas.', 'nitrogen');
  });
  frame(3, 'THE DIAGRAM SHOT', 'paper, one chart, plain labels', () => {
    R.paper(); R.pie(700, 470, 250, [{ v: 0.6, color: C.orange }, { v: 0.2, color: C.blue }, { v: 0.1, color: C.yellow }, { v: 0.1, color: C.grayLight }], 1, 0);
    R.pill('FIRST STAGE ~60%', 1260, 420, 54, 1, { hi: true }); R.pill('SECOND STAGE ~20%', 1260, 540, 44); subtitle('The first stage is the biggest part.', 'biggest');
  });

  // components band
  T('COMPONENTS', 60, 500, 24, C.gray);
  K.shadow(150, 790, 120); R.rocket(150, 660, 0.34, { fins: 0 });
  T('stowed', 150, 830, 18, C.gray, 'center');
  K.shadow(300, 790, 120); R.rocket(300, 660, 0.34, { legs: 1, fins: 1, flame: 0.4, nozzles: 1, t: 0.4 });
  T('landing', 300, 830, 18, C.gray, 'center');
  R.ship(600, 670, 300, 0, 'JUST READ THE INSTRUCTIONS'); ctx.save(); ctx.beginPath(); ctx.rect(420, 735, 360, 80); ctx.clip(); R.surf(745, 0); ctx.restore();
  T('drone ship', 600, 830, 18, C.gray, 'center');
  R.shipTop(940, 690, 250); T('top view', 940, 830, 18, C.gray, 'center');
  R.pill('WHITE PILL LABEL', 1330, 600, 34); R.pill('KEY FACT', 1330, 680, 34, 1, { hi: true }); R.callout('POINTER', 1330, 765, 1450, 700, 30);
  T('labels: 1 style', 1330, 830, 18, C.gray, 'center');
  K.host({ x: 1700, y: 650, s: 0.2, arm: K.ARM.point, mouth: 'grin' }); T('the host', 1700, 830, 18, C.gray, 'center');

  // rules
  ctx.fillStyle = C.paper; ctx.fillRect(0, 870, W, 210); ctx.fillStyle = C.ink; ctx.fillRect(0, 867, W, 6);
  const rules = ['ONE idea and ONE focal object per shot', 'Margins 120 px · bottom 150 px = subtitle', 'Flat fills · thick ink outline · no gradients', 'Orange = the one thing to look at',
    'Labels: white pill, 40 px+, 3 at most', 'Moving camera · calm backgrounds'];
  rules.forEach((r, i) => { const x = 60 + (i % 2) * 640, y = 915 + Math.floor(i / 2) * 56; circle(x + 14, y, 12, C.orange); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke(); T(r, x + 40, y + 2, 22); });
  const pal = [C.ink, C.bg, C.skin, C.orange, C.yellow, C.red, C.green, C.blue, R.SKY, R.NAVY];
  pal.forEach((c, i) => { wRect(1420 + (i % 5) * 90, 915 + Math.floor(i / 5) * 70, 76, 52, 10, c, { seed: i + 1, lw: 5 }); });
}
