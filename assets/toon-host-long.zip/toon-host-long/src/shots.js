// WHY YOUR PHONE NEEDS EINSTEIN TO FIND YOU  (long-form, 1920x1080)
// Rules: ONE idea + ONE focal object per shot, margins 120 px, subtitle owns y > 930, white pill labels, orange = the thing to look at.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, blob, wRect, wEll, poly, circle, line, ell, inkLine } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/space.js';
import * as G from './core/gps.js';

const PI = Math.PI;
const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const idle = (lt, a = 4) => Math.sin(lt * 2.2) * a;
function host(x, lt, o = {}) { K.shadow(x, 872, 300); K.host({ x, y: 548 + idle(lt), s: 0.5, mouth: 'talk', talk: talk(lt), ...o }); }
const pop = (lt, a, d = 0.35) => eob(seg(lt, a, a + d));
function dim(x0, y0, x1, y1, label, sc = 1, size = 40) {
  if (sc <= 0) return; ctx.save(); ctx.globalAlpha = clamp(sc);
  const an = Math.atan2(y1 - y0, x1 - x0), nx = -Math.sin(an) * 18, ny = Math.cos(an) * 18;
  line([[x0, y0], [x1, y1]], C.ink, 5); line([[x0 - nx, y0 - ny], [x0 + nx, y0 + ny]], C.ink, 5); line([[x1 - nx, y1 - ny], [x1 + nx, y1 + ny]], C.ink, 5); ctx.restore();
  if (label) R.pill(label, (x0 + x1) / 2, (y0 + y1) / 2 - 50, size, sc);
}
const orbitBg = (t) => { R.space(t, true); };
// a satellite hovering over the limb
const SATP = [960, 330];
// horizontal bar chart column with a signed value (zero line at base)
function zeroBars(p1, p2, p3, o = {}) {
  const base = 600, k = 8; R.paper(); line([[360, base], [1560, base]], C.ink, 6);
  if (p1 > 0) R.bar(640, base, 200, 45 * k * 0, C.blue, 0);
  if (p1 > 0) { const h = 7 * k * 3 * clamp(p1); wRect(540, base, 200, h, 12, C.blue, { seed: 1, lw: 7, wob: 1.2 }); if (p1 > 0.95) R.pill('-7 µs', 640, base + h + 56, 46); }
  if (p2 > 0) R.bar(960, base, 200, 45 * k * 0.75 * 1.2 * 1, C.orange, p2, 2);
  if (p2 > 0.95) R.pill('+45 µs', 960, base - 45 * k * 0.9 - 50, 46);
  if (p3 > 0) R.bar(1280, base, 200, 38 * k * 0.9, C.orange, p3, 3);
  if (p3 > 0.95) R.pill('+38 µs', 1280, base - 38 * k * 0.9 - 50, 46, 1, { hi: true });
  R.pill('SPEED', 640, 830, 36, p1 > 0.2 ? 1 : 0); R.pill('GRAVITY', 960, 830, 36, p2 > 0.2 ? 1 : 0); if (p3 > 0.2) R.pill('NET', 1280, 830, 36, 1, { hi: true });
}
const aboutBox = (txt, x, y, size, color = C.orange) => R.txt(txt, x, y, size, color, 'center', 2);

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => { const d0 = o.draw; if (o.chap) o.draw = (lt, d, t) => { d0(lt, d, t); R.chapterTag(o.chap[0], o.chap[1], lt); }; S.push(o); cue(o.at, 'whoosh', { gain: 0.22 }); return o; };
  const A = (i) => (i === 0 ? 0 : L(i) - 0.06);
  const Wc = (w, i) => Wd(w, i) - 0.06;

  // ═════════ HOOK ═════════
  { const st = A(0), few = Wc('few', 0);
    add({ id: 'S01', at: st, cam: [960, 520], zoom: 0.05, note: 'phone with a blue dot',
      draw(lt, d, t) { G.map(); K.phone(960, 500, 1.55, 0, C.paper, () => { }); G.dot(960, 500, 0.9, t); R.pill('A FEW METERS', 1400, 330, 50, pop(lt, few - st), { hi: true }); } }); }
  { const st = A(1), tr = Wc('only', 1);
    add({ id: 'S02', at: st, cam: [960, 520], zoom: 0.04, note: 'dot works because Einstein was right',
      draw(lt, d, t) { R.paper(); wRect(560, 260, 800, 460, 20, C.sweater, { seed: 301 }); R.txt('RELATIVITY', 960, 400, 130, C.white, 'center', 3); line([[640, 500], [1280, 500]], C.grayLight, 6); R.txt('time runs at different speeds', 960, 580, 46, '#B5B0AA', 'center', 1); K.check(1330, 700, 0.55, pop(lt, tr - st)); R.pill('EINSTEIN WAS RIGHT', 960, 830, 56, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(2), ten = Wc('ten', 2);
    add({ id: 'S03', at: st, cam: [960, 520], zoom: 0.04, note: 'dot drifts away 10 km a day',
      draw(lt, d, t) {
        G.map(); const p = eio(seg(lt, ten - st - 0.4, ten - st + 2.2));
        ctx.save(); ctx.setLineDash([20, 16]); line([[460, 520], [lerp(460, 1460, p), lerp(520, 400, p)]], C.ink, 6); ctx.restore();
        circle(460, 520, 24, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke();
        G.dot(lerp(460, 1460, p), lerp(520, 400, p), 0.9, t); R.pill('10+ km  PER DAY', 960, 220, 56, pop(lt, ten - st), { hi: true });
      } }); }
  add({ id: 'S04', at: A(3), cam: [1200, 540], zoom: 0.05, note: 'host asks',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); K.mark('?', 1010, 330 + Math.sin(lt * 3) * 8, pop(lt, 0.2, 0.4) * 0.8, -0.1); R.pill('A MAP APP THAT NEEDS RELATIVITY?', 700, 450, 50, pop(lt, 0.1)); } });

  // ═════════ 1 · LISTEN ONLY ═════════
  { const st = A(4), only = Wc('satellite', 4);
    add({ id: 'S05', at: st, cam: [960, 520], zoom: 0.04, chap: [1, 'ONLY LISTENING'], note: 'phone never talks',
      draw(lt, d, t) { R.paper(); K.phone(960, 520, 1.3); R.arrowV(1180, 380, 240, -0.55, C.orange, 28); K.redX(1450, 270, 0.4, pop(lt, 0.9)); R.pill('NEVER TALKS', 1500, 400, 46, pop(lt, 0.5)); } });
    add({ id: 'S05b', at: only, cam: [960, 520], zoom: 0.04, note: 'phone only listens',
      draw(lt, d, t) { R.space(t, false); K.phone(960, 620, 1.2); G.rings(960, 300, t, { n: 3, max: 300, color: C.orange, arc: [0.15 * PI, 0.85 * PI], w: 8 }); G.sat(960, 220, 0.45, 0, true); R.pill('ONLY LISTENS', 1400, 560, 52, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(5), km = Wc('kilometers', 5), fleet = Wc('fleet', 5), lh = Wc('lighthouses', 5);
    add({ id: 'S06', at: st, cam: [960, 520], zoom: 0.04, note: 'one satellite 20,000 km up',
      draw(lt, d, t) { orbitBg(t); G.sat(960, 330 + Math.sin(lt * 1.5) * 6, 0.9, 0, true); dim(1400, 340, 1400, 870, 'about 20,000 km', pop(lt, km - st), 44); } });
    add({ id: 'S06b', at: fleet, cam: [960, 520], zoom: 0.04, note: 'a fleet broadcasting',
      draw(lt, d, t) { orbitBg(t); for (let i = 0; i < 5; i++) { const a = -PI + (i + 0.5) * (PI / 5) + t * 0.03, x = W / 2 + Math.cos(a) * 1000, y = 1980 + Math.sin(a) * 1250 - 400 + 400; if (y < 700) { G.rings(x, y, t + i * 0.2, { n: 2, max: 180, color: C.white, w: 5 }); G.sat(x, y, 0.32, a + PI / 2, i === 2); } } R.pill('BROADCASTING NONSTOP', 960, 160, 48, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S06c', at: lh, cam: [960, 520], zoom: 0.04, note: 'like lighthouses shouting the time',
      draw(lt, d, t) { R.space(t, false); G.lighthouse(960, 840, 1.0); const a = (Math.sin(t * 2) * 0.5 + 0.5); ctx.save(); ctx.globalAlpha = 0.35; poly([[960, 440], [1700, 380], [1700, 520]], C.yellow, { lw: 0 }); ctx.restore(); R.pill('SHOUTS THE TIME', 1400, 250, 52, pop(lt, 0.8), { hi: true }); } }); }
  { const st = A(6), when = Wc('and', 6);
    add({ id: 'S07', at: st, cam: [960, 520], zoom: 0.04, note: 'where I am',
      draw(lt, d, t) { R.space(t, true); G.rings(960, 380, t, { n: 3, max: 340, w: 6 }); G.sat(960, 380, 0.8, 0, true); R.pill('HERE IS WHERE I AM', 960, 190, 56, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S07b', at: when, cam: [960, 520], zoom: 0.04, note: 'and exactly when I sent this',
      draw(lt, d, t) { R.paper(); K.clock(960, 460, 1.5, lt * 0.8 + 1); R.pill('AND EXACTLY WHEN I SENT THIS', 960, 790, 54, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(7), late = Wc('late', 7), less = Wc('less', 7);
    add({ id: 'S08', at: st, cam: [960, 520], zoom: 0.04, note: 'radio at the speed of light',
      draw(lt, d, t) { R.space(t, false); G.sat(960, 210, 0.45, 0, true); K.phone(960, 700, 1.0); const p = (lt * 0.9) % 1; for (let i = 0; i < 4; i++) { const q = (p + i / 4) % 1; circle(960, lerp(260, 540, q), 14, C.yellow); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); } R.pill('SPEED OF LIGHT', 1400, 440, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S08b', at: late, cam: [960, 520], zoom: 0.04, note: 'late means far',
      draw(lt, d, t) { R.paper(); K.clock(640, 470, 1.2, 4.2); R.pill('LATE', 1300, 400, 80, pop(lt, 0.2), { hi: true }); R.arrowV(1050, 520, 300, 0, C.ink, 22); R.pill('FAR AWAY', 1300, 620, 64, pop(lt, 0.7)); } });
    add({ id: 'S08c', at: less, cam: [960, 520], zoom: 0.04, note: 'less late means close',
      draw(lt, d, t) { R.paper(); K.clock(640, 470, 1.2, 1.2); R.pill('LESS LATE', 1300, 400, 80, pop(lt, 0.2), { hi: true }); R.arrowV(1050, 520, 300, 0, C.ink, 22); R.pill('CLOSER', 1300, 620, 64, pop(lt, 0.7)); } }); }
  add({ id: 'S09', at: A(8), cam: [960, 520], zoom: 0.04, note: 'distance = giant invisible sphere',
    draw(lt, d, t) {
      R.space(t, false); const r = lerp(60, 330, eo(seg(lt, 0.2, 2.2)));
      ctx.save(); ctx.globalAlpha = 0.9; circle(960, 520, r, 'rgba(255,255,255,0.14)'); ctx.lineWidth = 8; ctx.strokeStyle = C.white; ctx.setLineDash([22, 16]); ctx.stroke(); ctx.restore();
      G.sat(960, 520, 0.4, 0, true); K.phone(960 + r * 0.7, 520 + r * 0.7, 0.4); R.pill('ONE SATELLITE = ONE DISTANCE', 960, 190, 50, pop(lt, 2.0), { hi: true });
    } });
  { const st = A(9), sec = A(9), third = Wc('third', 9), cong = Wc('congratulations', 9);
    add({ id: 'S10b', at: st, cam: [960, 520], zoom: 0.04, note: '2 sats = a circle',
      draw(lt, d, t) { R.paper(); ctx.save(); ctx.beginPath(); ctx.ellipse(960, 480, 300, 90, 0, 0, TAU); ctx.lineWidth = 22; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.lineWidth = 12; ctx.strokeStyle = C.orange; ctx.stroke(); ctx.restore(); R.pill('2 SATELLITES: A CIRCLE', 960, 850, 52, pop(lt, 0.3)); } });
    add({ id: 'S10c', at: third, cam: [960, 520], zoom: 0.04, note: '3 sats = two points',
      draw(lt, d, t) { R.paper(); circle(1230, 420, 28, '#B5B0AA'); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('far out in space', 1230, 330, 38, pop(lt, 0.6)); G.globe(780, 560, 190, lt * 0.2); R.pill('3 SATELLITES: TWO POINTS', 960, 850, 52, pop(lt, 0.3)); } });
    add({ id: 'S10d', at: cong, cam: [960, 520], zoom: 0.04, note: 'the other one is you',
      draw(lt, d, t) { R.paper(); G.globe(960, 520, 230, lt * 0.2); G.dot(1060, 450, 0.8, t); R.pill('THAT IS YOU', 1400, 300, 60, pop(lt, 0.3), { hi: true }); } }); }

  // ═════════ 2 · THE TIMING PROBLEM ═════════
  add({ id: 'S11', at: A(10), cam: [700, 540], zoom: 0.05, chap: [2, 'THE TIMING PROBLEM'], note: 'host: a catch',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'talk' }); K.clock(1180, 470, 1.1, lt * 1.2); R.pill('IT IS ALL ABOUT TIME', 1180, 700, 46, pop(lt, 0.5), { hi: true }); } });
  { const st = A(11), bil = Wc("that's", 11);
    add({ id: 'S12', at: st, cam: [960, 520], zoom: 0.04, note: 'light covers 30 cm in a nanosecond',
      draw(lt, d, t) { R.paper(); const base = 600; line([[360, base], [1560, base]], C.ink, 8); for (let i = 0; i <= 10; i++) line([[360 + i * 120, base - 20], [360 + i * 120, base + 20]], C.ink, 5); const p = eio(seg(lt, 0.4, 2.2)); circle(lerp(360, 1560, p), base - 70, 34, C.yellow); ctx.lineWidth = 7; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('30 cm', 960, base + 90, 60, pop(lt, 2.0), { hi: true }); R.pill('LIGHT IN ONE NANOSECOND', 960, 300, 50, pop(lt, 0.3)); } });
    add({ id: 'S12b', at: bil, cam: [960, 520], zoom: 0.04, note: 'one billionth of a second',
      draw(lt, d, t) { R.paper(); aboutBox('1 ns', 960, 430, 300); R.pill('ONE BILLIONTH OF A SECOND', 960, 680, 52, pop(lt, 0.3)); R.txt('0.000000001 s', 960, 790, 64, C.gray, 'center', 2); } }); }
  add({ id: 'S13', at: A(12), cam: [960, 520], zoom: 0.04, note: 'one ns off = 30 cm off',
    draw(lt, d, t) { G.map(); circle(760, 520, 30, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); G.dot(1040, 520, 0.9, t); dim(760, 640, 1040, 640, '30 cm', pop(lt, 1.4), 44); R.pill('CLOCK OFF BY 1 ns', 960, 220, 54, pop(lt, 0.3), { hi: true }); } });
  { const st = A(13), four = Wc('four', 13);
    add({ id: 'S14', at: st, cam: [960, 520], zoom: 0.04, note: 'about 4 ns to stay within a meter',
      draw(lt, d, t) { R.paper(); aboutBox('4 ns', 960, 430, 300); R.pill('TO STAY WITHIN ABOUT 1 METER', 960, 700, 50, pop(lt, 0.4)); R.pill('SATELLITE CLOCKS MUST AGREE', 960, 810, 46, pop(lt, 1.0), { hi: true }); } }); }
  add({ id: 'S15', at: A(14), cam: [960, 520], zoom: 0.04, note: 'phone has a cheap clock',
    draw(lt, d, t) { R.paper(); G.cereal(760, 480, 1.1); K.clock(1180, 520, 0.8, lt * 0.7 + 3); R.pill('A WATCH FROM A CEREAL BOX', 960, 850, 50, pop(lt, 0.6), { hi: true }); } });
  { const st = A(15), three = Wc('three', 15), lets = Wc('lets', 15);
    const sats4 = (n, t, lt) => { orbitBg(t); K.phone(960, 760, 0.55); const pos = [[420, 330], [960, 220], [1500, 330], [1230, 520]]; pos.forEach(([x, y], i) => { if (i < n) { ctx.save(); ctx.globalAlpha = 0.7; ctx.setLineDash([14, 14]); line([[x, y + 30], [960, 700]], C.white, 5); ctx.restore(); G.sat(x, y, 0.36, 0, i === 3); } }); };
    add({ id: 'S16', at: st, cam: [960, 520], zoom: 0.04, note: 'a fourth satellite',
      draw(lt, d, t) { sats4(4, t, lt); R.pill('LISTEN TO A FOURTH SATELLITE', 960, 130, 48, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S16b', at: three, cam: [960, 520], zoom: 0.04, note: 'three give the position',
      draw(lt, d, t) { sats4(3, t, lt); R.pill('3 SATELLITES  =  YOUR POSITION', 960, 130, 48, pop(lt, 0.3)); } });
    add({ id: 'S16c', at: lets, cam: [960, 520], zoom: 0.04, note: 'fourth fixes the clock',
      draw(lt, d, t) { sats4(4, t, lt); R.pill("THE 4TH FIXES YOUR PHONE'S CLOCK", 960, 130, 48, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(16), ninety = Wc('nineties', 16), hund = Wc('around', 16), may = Wc('may', 16), five = Wc('dropped', 16);
    add({ id: 'S17', at: st, cam: [960, 520], zoom: 0.04, note: 'result a few meters',
      draw(lt, d, t) { G.map(); G.dot(960, 520, 1.0, t); R.pill('GOOD TO A FEW METERS', 960, 220, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S17b', at: ninety, cam: [960, 520], zoom: 0.04, note: 'nineties: blurred to 100 m',
      draw(lt, d, t) { G.map(); const r = 270; ctx.save(); ctx.globalAlpha = 0.28; circle(960, 520, r, C.orange); ctx.globalAlpha = 1; ctx.setLineDash([20, 14]); ctx.lineWidth = 8; ctx.strokeStyle = C.orange; ctx.stroke(); ctx.restore(); G.dot(1020, 470, 0.7, t); R.pill('THE 1990s: BLURRED ON PURPOSE', 960, 220, 50, pop(lt, 0.4)); } });
    add({ id: 'S17b2', at: hund, cam: [960, 520], zoom: 0.04, note: 'about 100 m',
      draw(lt, d, t) { G.map(); const r = 270; ctx.save(); ctx.globalAlpha = 0.28; circle(960, 520, r, C.orange); ctx.globalAlpha = 1; ctx.setLineDash([20, 14]); ctx.lineWidth = 8; ctx.strokeStyle = C.orange; ctx.stroke(); ctx.restore(); G.dot(1020, 470, 0.7, t); dim(960 - r, 520, 960 + r, 520, 'about 100 m', pop(lt, 0.4), 46); } });
    add({ id: 'S17c', at: may, cam: [960, 520], zoom: 0.04, note: 'switched off May 2000',
      draw(lt, d, t) { G.map(); const r = lerp(270, 30, eo(seg(lt, 0.6, 1.8))); ctx.save(); ctx.globalAlpha = 0.28; circle(960, 520, r, C.orange); ctx.restore(); G.dot(960, 520, 0.8, t); R.pill('MAY 2000: BLUR SWITCHED OFF', 960, 220, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S17d', at: five, cam: [960, 520], zoom: 0.04, note: '100 m -> 5 m',
      draw(lt, d, t) { R.paper(); const base = 800, k = 4.4; line([[400, base], [1520, base]], C.ink, 6); R.bar(760, base, 220, 100 * k, C.blue, eo(seg(lt, 0.1, 0.9)), 1); R.bar(1160, base, 220, 5 * k, C.orange, eo(seg(lt, 0.7, 1.2)), 2); R.pill('about 100 m', 760, base - 100 * k - 50, 44); R.pill('about 5 m', 1160, base - 5 * k - 60, 44, pop(lt, 1.1), { hi: true }); R.pill('BEFORE', 760, 870, 36); R.pill('AFTER', 1160, 870, 36, 1, { hi: true }); } }); }

  // ═════════ 3 · CLOCKS IN SPACE ═════════
  add({ id: 'S18', at: A(17), cam: [960, 520], zoom: 0.04, chap: [3, 'CLOCKS IN SPACE'], note: 'atomic clock',
    draw(lt, d, t) { R.paper(); G.atom(960, 480, 1.2, t); R.pill('AN ATOMIC CLOCK', 960, 850, 56, pop(lt, 0.5), { hi: true }); } });
  { const st = A(18), count = Wc('count', 18), sec = Wc('second', 18), nine = Wc('nine', 18);
    add({ id: 'S19', at: st, cam: [960, 520], zoom: 0.04, note: 'cesium atoms vibrate steadily',
      draw(lt, d, t) { R.paper(); G.atom(640, 480, 0.8, t); ctx.save(); ctx.beginPath(); for (let i = 0; i <= 120; i++) { const x = 1000 + i * 6, y = 480 + Math.sin(i * 0.5 - t * 8) * 70; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.lineWidth = 12; ctx.strokeStyle = C.orange; ctx.lineCap = 'round'; ctx.stroke(); ctx.restore(); R.pill('CESIUM ATOMS: ONE STEADY RATE', 960, 800, 48, pop(lt, 0.7)); } });
    add({ id: 'S19b', at: count, cam: [960, 520], zoom: 0.04, note: 'count the vibrations',
      draw(lt, d, t) { R.paper(); const n = Math.floor(9192631770 * eo(seg(lt, 0.2, d - 0.6))); R.txt(n.toLocaleString('en-US'), 960, 470, 150, C.orange, 'center', 2); R.pill('COUNT THE VIBRATIONS', 960, 700, 52, pop(lt, 0.3)); } });
    add({ id: 'S19c', at: sec, cam: [960, 520], zoom: 0.04, note: 'one second',
      draw(lt, d, t) { R.paper(); K.clock(960, 450, 1.3, lt * 2); R.pill('THE OFFICIAL SECOND', 960, 790, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S19d', at: nine, cam: [960, 520], zoom: 0.04, note: 'that many vibrations',
      draw(lt, d, t) { R.paper(); R.txt('9,192,631,770', 960, 400, 150, C.orange, 'center', 2); R.pill('VIBRATIONS  =  EXACTLY ONE SECOND', 960, 620, 54, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(19), ground = Wc('ground', 19);
    add({ id: 'S20', at: st, cam: [960, 520], zoom: 0.04, note: 'several clocks per satellite',
      draw(lt, d, t) { orbitBg(t); G.sat(960, 400, 1.0, 0, true); R.pill('SEVERAL ATOMIC CLOCKS ON BOARD', 960, 170, 50, pop(lt, 0.4)); } });
    add({ id: 'S20b', at: ground, cam: [960, 520], zoom: 0.04, note: 'ground stations keep them in step',
      draw(lt, d, t) { R.sky(t); R.pad(900); G.dish(700, 900, 1.4); G.rings(780, 540, t, { n: 3, max: 260, color: C.orange, w: 7, arc: [-0.7 * PI, -0.2 * PI] }); R.pill('US NAVAL OBSERVATORY: MASTER CLOCKS', 1100, 330, 44, pop(lt, 1.0), { hi: true }); } }); }
  { const st = A(20);
    add({ id: 'S21', at: st, cam: [960, 520], zoom: 0.04, note: 'launch',
      draw(lt, d, t) { R.sky(t); R.pad(880); const p = seg(lt, 0.6, d); R.rocket(960, lerp(880 - 284 * 0.55, -400, p * p * p), 0.55, { flame: seg(lt, 0.5, 0.9), t }); K.mark('?', 1300, 330 + Math.sin(lt * 3) * 8, pop(lt, 1.6) * 0.9, 0.1); } }); }
  { const st = A(21), notb = Wc('not', 21);
    add({ id: 'S22', at: st, cam: [960, 520], zoom: 0.04, note: 'clocks disagree',
      draw(lt, d, t) { R.paper(); G.labeledClock(560, 460, 1.0, lt * 0.6 + 1, 'GROUND'); G.labeledClock(1360, 460, 1.0, lt * 0.6 + 2.6, 'ORBIT', true); R.pill('NOT THE SAME TIME', 960, 190, 56, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S22b', at: notb, cam: [960, 520], zoom: 0.04, note: 'time itself runs differently',
      draw(lt, d, t) { R.studio(880); host(960, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug }); R.pill('TIME ITSELF RUNS DIFFERENTLY UP THERE', 960, 150, 50, pop(lt, 1.2), { hi: true }); } }); }

  // ═════════ 4 · SPEED SLOWS TIME ═════════
  add({ id: 'S23', at: A(22), cam: [700, 540], zoom: 0.05, chap: [4, 'SPEED SLOWS TIME'], note: 'idea 1: speed',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('EINSTEIN IDEA 1: SPEED', 1260, 400, 52, pop(lt, 0.4), { hi: true }); R.pill('FASTER  =  SLOWER CLOCK', 1260, 530, 48, pop(lt, 2.0)); } });
  { const st = A(23), kmh = Wc('fourteen', 23);
    add({ id: 'S24', at: st, cam: [960, 520], zoom: 0.04, note: 'orbits at ~4 km/s',
      draw(lt, d, t) { orbitBg(t); const a = -PI * 0.5 + Math.sin(lt * 0.4) * 0.3 - 0.0; const x = W / 2 + Math.cos(a - 0.4 + lt * 0.12) * 900, y = 1980 + Math.sin(a - 0.4 + lt * 0.12) * 1250; G.sat(960 + Math.sin(lt * 0.5) * 120, 420, 1.0, 0, true); R.pill('about 4 km EVERY SECOND', 960, 150, 52, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S24b', at: kmh, cam: [960, 520], zoom: 0.04, note: '14,000 km/h',
      draw(lt, d, t) { R.paper(); aboutBox('14,000', 960, 430, 260); R.pill('KILOMETERS AN HOUR', 960, 650, 54, pop(lt, 0.3)); ctx.save(); ctx.globalAlpha = 0.8; for (let i = 0; i < 5; i++) line([[260, 800 + i * 0], [260 + 120, 800]], C.white, 1); ctx.restore(); } }); }
  add({ id: 'S25', at: A(24), cam: [960, 520], zoom: 0.04, note: 'clock falls behind 7 µs a day',
    draw(lt, d, t) { R.paper(); G.labeledClock(560, 460, 1.0, lt * 0.8, 'GROUND'); G.labeledClock(1360, 460, 1.0, lt * 0.8 - Math.min(lt, 3) * 0.25, 'ORBIT', true); R.pill('LOSES ABOUT 7 µs PER DAY', 960, 190, 56, pop(lt, 0.8), { hi: true }); } });
  { const st = A(25), seven = Wc('seven', 25), hold = Wc('hold', 25);
    add({ id: 'S26', at: st, cam: [960, 520], zoom: 0.04, note: 'a microsecond is a millionth',
      draw(lt, d, t) { R.paper(); aboutBox('1 µs', 960, 420, 280); R.pill('ONE MILLIONTH OF A SECOND', 960, 650, 52, pop(lt, 0.3)); R.pill('7 OF THEM SOUNDS LIKE NOTHING', 960, 780, 46, pop(lt, seven - st)); } });
    add({ id: 'S26b', at: hold, cam: [700, 540], zoom: 0.05, note: 'hold that thought',
      draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); K.bulb(930, 330 + Math.sin(lt * 3) * 8, 0.9, 1); R.pill('HOLD THAT THOUGHT', 1300, 500, 52, pop(lt, 0.4), { hi: true }); } }); }

  // ═════════ 5 · GRAVITY SPEEDS IT UP ═════════
  { const st = A(26), deeper = Wc('deeper', 26);
    add({ id: 'S27', at: st, cam: [960, 520], zoom: 0.04, chap: [5, 'GRAVITY TOO'], note: 'idea 2: gravity bends time',
      draw(lt, d, t) { R.paper(); const f = G.well(960, 380, 700, 380); circle(960, f(960) - 40, 40, C.orange); ctx.lineWidth = 7; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('EINSTEIN IDEA 2: GRAVITY', 960, 190, 56, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S27b', at: deeper, cam: [960, 520], zoom: 0.04, note: 'deeper = slower clock',
      draw(lt, d, t) { R.paper(); const f = G.well(960, 380, 700, 380); K.clock(960, f(960) - 100, 0.28, lt); R.pill('DEEPER IN GRAVITY  =  SLOWER CLOCK', 960, 190, 50, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(27), sat = Wc('satellite', 27), faster = Wc('faster', 27);
    add({ id: 'S28', at: st, cam: [960, 520], zoom: 0.04, note: 'you are deeper than the satellite',
      draw(lt, d, t) { R.paper(); const f = G.well(960, 400, 760, 380); K.clock(960, f(960) - 110, 0.3, lt * 0.6); R.pill('YOU', 960, f(960) + 120, 44, pop(lt, 0.4), { hi: true }); K.clock(1560, f(1560) - 110, 0.3, lt * 0.6); } });
    add({ id: 'S28b', at: sat, cam: [960, 520], zoom: 0.04, note: 'satellite higher up',
      draw(lt, d, t) { R.paper(); const f = G.well(960, 400, 760, 380); K.clock(1560, f(1560) - 110, 0.3, lt * 0.6); G.sat(1560, f(1560) - 300, 0.35, 0, true); R.pill('20,000 km UP', 1300, 190, 50, pop(lt, 0.3)); K.clock(960, f(960) - 110, 0.28, lt * 0.6); } });
    add({ id: 'S28c', at: faster, cam: [960, 520], zoom: 0.04, note: 'so its clock runs faster',
      draw(lt, d, t) { R.paper(); G.labeledClock(560, 460, 1.0, lt * 0.8, 'GROUND'); G.labeledClock(1360, 460, 1.0, lt * 1.1, 'ORBIT', true); R.pill('ORBIT CLOCK RUNS FASTER', 960, 190, 56, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S29', at: A(28), cam: [960, 520], zoom: 0.04, note: 'about +45 µs per day',
    draw(lt, d, t) { R.paper(); const n = Math.round(45 * eo(seg(lt, 0.3, 1.4))); aboutBox('+' + n + ' µs', 960, 430, 280); R.pill('GAINED EVERY DAY', 960, 660, 54, pop(lt, 1.2), { hi: true }); } });
  add({ id: 'S30', at: A(29), cam: [960, 520], zoom: 0.04, note: 'two effects pulling opposite ways',
    draw(lt, d, t) { zeroBars(eo(seg(lt, 0.3, 1.0)), eo(seg(lt, Wd('gravity', 29) - A(29), Wd('gravity', 29) - A(29) + 1.0)), 0); } });
  { const st = A(30), net = Wc('net', 30);
    add({ id: 'S31', at: st, cam: [960, 520], zoom: 0.04, note: 'gravity wins',
      draw(lt, d, t) { zeroBars(1, 1, eo(seg(lt, net - st, net - st + 0.9))); R.pill('GRAVITY WINS', 960, 130, 60, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S31b', at: Wc('thirty-eight', 30), cam: [960, 520], zoom: 0.04, note: '38 µs per day net',
      draw(lt, d, t) { R.paper(); aboutBox('+38 µs', 960, 430, 300); R.pill('PER DAY, VS A GROUND CLOCK', 960, 680, 52, pop(lt, 0.4)); } }); }
  { const st = A(31), re = Wc('remember', 31), nano = Wc('thirty-eight', 31);
    const lastNano = T.words.filter((w) => w.line === 31 && w.w.toLowerCase().replace(/[^a-z-]/g, '').startsWith('thirty-eight')).pop();
    add({ id: 'S32', at: st, cam: [960, 520], zoom: 0.04, note: 'who cares? your map app does',
      draw(lt, d, t) { R.studio(880); host(960, lt, { arm: K.ARM.shrug, armL: K.ARM.shrug, brow: 0.6 }); R.pill('38 MILLIONTHS OF A SECOND?', 960, 150, 54, pop(lt, 0.3)); } });
    add({ id: 'S32b', at: re, cam: [960, 520], zoom: 0.04, note: 'light 30 cm per ns',
      draw(lt, d, t) { R.paper(); aboutBox('30 cm', 960, 430, 260); R.pill('LIGHT TRAVELS PER NANOSECOND', 960, 660, 50, pop(lt, 0.4)); } });
    add({ id: 'S32c', at: lastNano.s - 0.06, cam: [960, 520], zoom: 0.04, note: '38 µs = 38,000 ns',
      draw(lt, d, t) { R.paper(); aboutBox('38,000 ns', 960, 430, 220); R.pill('=  38 MICROSECONDS', 960, 660, 54, pop(lt, 0.5), { hi: true }); } }); }
  { const st = A(32), roughly = Wc('roughly', 32), grow = Wc('grow', 32);
    add({ id: 'S33', at: st, cam: [960, 520], zoom: 0.04, note: 'multiply: ~11 km',
      draw(lt, d, t) { R.paper(); line([[360, 560], [1560, 560]], C.ink, 8); const p = eio(seg(lt, 0.6, 3.0)); circle(lerp(360, 1560, p), 490, 34, C.yellow); ctx.lineWidth = 7; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill('38 µs  ×  SPEED OF LIGHT', 960, 250, 52, pop(lt, 0.3)); R.pill('about 11 km', 960, 700, 70, pop(lt, roughly - st), { hi: true }); } });
    add({ id: 'S33b', at: grow, cam: [960, 520], zoom: 0.04, note: 'error grows 10+ km a day',
      draw(lt, d, t) { G.map(); const p = eio(seg(lt, 0.4, 3.2)); ctx.save(); ctx.setLineDash([20, 16]); line([[460, 620], [lerp(460, 1460, p), lerp(620, 380, p)]], C.ink, 6); ctx.restore(); circle(460, 620, 24, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); G.dot(lerp(460, 1460, p), lerp(620, 380, p), 0.9, t); R.pill('ERROR GROWS 10+ km EVERY DAY', 960, 190, 52, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(33), week = Wc('within', 33);
    add({ id: 'S34', at: st, cam: [960, 520], zoom: 0.04, note: 'tomorrow: next town',
      draw(lt, d, t) { G.map(); circle(500, 560, 24, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); G.dot(1000, 470, 0.9, t); dim(500, 650, 1000, 650, '~10 km', pop(lt, 0.8), 42); R.pill('TOMORROW: THE NEXT TOWN', 960, 200, 52, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S34b', at: week, cam: [960, 520], zoom: 0.04, note: 'a week: tens of km',
      draw(lt, d, t) { G.map(); circle(300, 600, 24, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); G.dot(1560, 340, 0.9, t); R.pill('A WEEK LATER: TENS OF KILOMETERS OFF', 960, 200, 50, pop(lt, 0.3), { hi: true }); } }); }

  // ═════════ 6 · THE FIX ═════════
  add({ id: 'S35', at: A(34), cam: [700, 540], zoom: 0.05, chap: [6, 'THE FIX'], note: 'host: cheat before launch',
    draw(lt, d, t) { R.studio(880); host(640, lt, { arm: K.ARM.point, mouth: 'grin' }); R.pill('THE FIX: CHEAT BEFORE LAUNCH', 1260, 420, 52, pop(lt, 0.5), { hi: true }); } });
  { const st = A(35), parts = Wc('four', 35), freq = Wc('just', 35);
    add({ id: 'S36', at: st, cam: [960, 520], zoom: 0.04, note: 'set slow on purpose',
      draw(lt, d, t) { R.paper(); K.clock(960, 450, 1.4, lt * 0.35); R.pill('SET SLOW ON THE GROUND', 960, 790, 54, pop(lt, 0.5), { hi: true }); } });
    add({ id: 'S36a', at: parts, cam: [960, 520], zoom: 0.04, note: '4.5 parts in 10 billion',
      draw(lt, d, t) { R.paper(); aboutBox('4.5', 960, 400, 280); R.pill('PARTS IN TEN BILLION', 960, 640, 56, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S36b', at: freq, cam: [960, 520], zoom: 0.04, note: 'just under 10.23 MHz',
      draw(lt, d, t) { R.paper(); R.txt('10.22999999543', 960, 440, 150, C.orange, 'center', 2); R.pill('MHz  (NOT 10.23)', 960, 640, 56, pop(lt, 0.4)); } }); }
  { const st = A(36), orb = Wc('relativity', 36), lines = Wc('lines', 36);
    add({ id: 'S37', at: st, cam: [960, 520], zoom: 0.04, note: 'in orbit relativity speeds it up',
      draw(lt, d, t) { orbitBg(t); G.sat(960, 400, 0.9, 0, true); R.pill('IN ORBIT, RELATIVITY SPEEDS IT UP', 960, 170, 50, pop(lt, orb - st), { hi: true }); } });
    add({ id: 'S37b', at: lines, cam: [960, 520], zoom: 0.04, note: 'now matches the ground',
      draw(lt, d, t) { R.paper(); G.labeledClock(560, 460, 1.0, lt * 0.8, 'GROUND'); G.labeledClock(1360, 460, 1.0, lt * 0.8, 'ORBIT', true); K.check(960, 460, 0.5, pop(lt, 0.6)); R.pill('SAME RATE', 960, 190, 56, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S38', at: A(37), cam: [960, 520], zoom: 0.04, note: '1977 test: under 1% off',
    draw(lt, d, t) { R.paper(); aboutBox('1977', 960, 400, 240); R.pill('MATCHED THE PREDICTION', 960, 620, 54, pop(lt, 0.8), { hi: true }); R.pill('BETTER THAN 1% OFF', 960, 740, 46, pop(lt, 1.8)); K.check(1500, 400, 0.4, pop(lt, 2.6)); } });
  { const st = A(38), four = Wc('four', 38);
    add({ id: 'S39', at: st, cam: [960, 520], zoom: 0.04, note: '1971 Hafele and Keating',
      draw(lt, d, t) { R.sky(t); const x = lerp(300, 1500, eio(seg(lt, 0.2, d - 0.3))); G.jet(x, 480 - 60 * Math.sin(seg(lt, 0, d) * PI), 1.4, -0.05); R.pill('1971: HAFELE AND KEATING', 960, 190, 52, pop(lt, 0.3)); } });
    add({ id: 'S39b', at: four, cam: [960, 520], zoom: 0.04, note: 'four atomic clocks on passenger jets',
      draw(lt, d, t) { R.paper(); for (let i = 0; i < 4; i++) K.clock(520 + i * 290, 480, 0.42, lt * 0.8 + i); R.pill('4 ATOMIC CLOCKS  ON PASSENGER JETS', 960, 760, 50, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(39), came = Wc('came', 39), cost = Wc('cost', 39);
    add({ id: 'S40', at: st, cam: [960, 520], zoom: 0.04, note: 'east then west around the world',
      draw(lt, d, t) { R.paper(); G.globe(960, 520, 250, 0); const a = lt * 1.0; for (const dir of [1, -1]) { const aa = -PI / 2 + dir * a; ctx.save(); ctx.translate(960, 520); G.jet(Math.cos(aa) * 300, Math.sin(aa) * 300 * 0.5 + 0, 0.5, dir > 0 ? 0 : PI); ctx.restore(); } R.pill('EAST, THEN WEST', 960, 200, 52, pop(lt, 0.3)); } });
    add({ id: 'S40b', at: came, cam: [960, 520], zoom: 0.04, note: 'results -59 ns east, +273 ns west',
      draw(lt, d, t) { R.paper(); const base = 560; line([[360, base], [1560, base]], C.ink, 6); wRect(640, base, 200, 59 * 1.1, 10, C.blue, { seed: 5, lw: 7 }); R.bar(1220, base, 200, 273 * 1.1, C.orange, eo(seg(lt, 0.4, 1.4)), 6); R.pill('EAST  -59 ns', 740, base + 59 * 1.1 + 60, 40); R.pill('WEST  +273 ns', 1320, base - 273 * 1.1 - 50, 40, pop(lt, 1.3), { hi: true }); R.pill('JUST AS RELATIVITY PREDICTED', 960, 200, 48, pop(lt, 2.6)); } });
    add({ id: 'S40c', at: cost, cam: [960, 520], zoom: 0.04, note: '$8,000, mostly plane tickets',
      draw(lt, d, t) { R.paper(); G.ticket(700, 520, 1.4, -0.1); K.coin(1180, 480, 1.1); K.coin(1330, 560, 0.9); R.pill('ABOUT $8,000  ·  MOSTLY PLANE TICKETS', 960, 850, 50, pop(lt, 0.4), { hi: true }); } }); }

  // ═════════ 7 · WHERE IT STARTED ═════════
  { const st = A(40);
    add({ id: 'S41', at: st, cam: [960, 520], zoom: 0.04, chap: [7, 'HOW IT STARTED'], note: 'Sputnik 1957',
      draw(lt, d, t) { R.space(t, false); G.sputnik(960, 520 + Math.sin(lt * 1.5) * 8, 1.4, 0.1); R.pill('SPUTNIK  ·  1957', 960, 200, 60, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(41), dop = Wc('doppler', 41);
    add({ id: 'S42', at: st, cam: [960, 520], zoom: 0.04, note: 'two scientists listened',
      draw(lt, d, t) { R.studio(880); host(960, lt, { arm: K.ARM.hold, armL: K.ARM.hip, holding: (x, y) => { ctx.save(); ctx.translate(x + 30, y - 20); wRect(-70, -50, 140, 100, 12, C.grayLight, { seed: 42 }); circle(-20, 0, 26, C.white); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); line([[30, -20], [50, -20]], C.ink, 6); line([[30, 10], [50, 10]], C.ink, 6); ctx.restore(); } }); R.pill('GUIER + WEIFFENBACH  ·  LISTENING', 960, 200, 46, pop(lt, 0.4)); } });
    add({ id: 'S42b', at: dop, cam: [960, 520], zoom: 0.04, note: 'doppler shift',
      draw(lt, d, t) { R.space(t, false); const sx = lerp(400, 1500, (lt * 0.15) % 1); for (let i = 0; i < 6; i++) { const p = (t * 0.6 + i / 6) % 1; ctx.save(); ctx.globalAlpha = 1 - p; ctx.beginPath(); ctx.arc(sx, 520, 30 + p * 260, 0, TAU); ctx.lineWidth = 6; ctx.strokeStyle = C.white; ctx.stroke(); ctx.restore(); } G.sputnik(sx, 520, 0.5, 0); R.pill('THE PITCH CHANGES AS IT PASSES', 960, 200, 50, pop(lt, 0.4), { hi: true }); } }); }
  { const st = A(42), seventy = Wc('seventy-three', 42);
    add({ id: 'S43', at: st, cam: [960, 520], zoom: 0.04, note: 'flip the idea around',
      draw(lt, d, t) { R.paper(); G.sat(560, 400, 0.6, 0, true); K.phone(1360, 640, 0.7); const f = lt > 1.6; R.arrowV(f ? 1260 : 660, f ? 560 : 440, 480, f ? PI * 0.85 : PI * 0.15, C.orange, 28); R.pill('FLIP THE IDEA AROUND', 960, 180, 54, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S43b', at: seventy, cam: [960, 520], zoom: 0.04, note: '1973 Navstar GPS',
      draw(lt, d, t) { R.space(t, true); G.sat(960, 400, 0.9, 0, true); R.pill('1973  ·  NAVSTAR GPS BEGINS', 960, 170, 54, pop(lt, 0.3), { hi: true }); } }); }
  { const st = A(43), full = Wc('full', 43);
    add({ id: 'S44', at: st, cam: [960, 520], zoom: 0.04, note: 'Feb 22 1978 first satellite',
      draw(lt, d, t) { R.sky(t); R.pad(880); const p = seg(lt, 0.6, d); R.rocket(960, lerp(880 - 284 * 0.55, -400, p * p * p), 0.55, { flame: seg(lt, 0.5, 0.9), t }); R.pill('FEBRUARY 22, 1978  ·  FIRST SATELLITE', 960, 190, 50, pop(lt, 0.3), { hi: true }); } });
    add({ id: 'S44b', at: full, cam: [960, 520], zoom: 0.04, note: 'timeline to April 1995',
      draw(lt, d, t) { R.paper(); line([[300, 520], [1620, 520]], C.ink, 10); const ys = [[1957, 'SPUTNIK'], [1973, 'NAVSTAR'], [1978, 'FIRST SATELLITE'], [1995, 'FULLY OPERATIONAL']]; ys.forEach(([y, lab], i) => { const x = lerp(340, 1580, (y - 1957) / 38); const a = pop(lt, 0.2 + i * 0.6, 0.3); circle(x, 520, 24 * a, i === 3 ? C.orange : C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); R.pill(String(y), x, 440, 40, a); if (i === 3) R.pill('APRIL 1995  ·  FULLY OPERATIONAL', 960, 700, 46, pop(lt, 2.8), { hi: true }); }); } }); }

  // ═════════ RECAP ═════════
  add({ id: 'S45', at: A(44), cam: [1200, 540], zoom: 0.05, chap: [8, 'PUTTING IT TOGETHER'], note: 'host: recap',
    draw(lt, d, t) { R.studio(880); host(1330, lt, { arm: K.ARM.open, armL: K.ARM.hip }); R.pill('PUTTING IT ALL TOGETHER', 700, 450, 54, pop(lt, 0.3), { hi: true }); } });
  { const st = A(45), four = Wc('four', 45);
    add({ id: 'S46', at: st, cam: [960, 520], zoom: 0.04, note: 'broadcast time, phone measures lateness',
      draw(lt, d, t) { orbitBg(t); G.rings(960, 330, t, { n: 3, max: 300, color: C.white, w: 6, arc: [0.1 * PI, 0.9 * PI] }); G.sat(960, 330, 0.5, 0, true); K.phone(960, 700, 0.8); R.pill('SATELLITES BROADCAST THE TIME', 1400, 330, 46, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S46b', at: four, cam: [960, 520], zoom: 0.04, note: 'four give position and clock',
      draw(lt, d, t) { orbitBg(t); K.phone(960, 760, 0.55); [[420, 330], [960, 220], [1500, 330], [1230, 520]].forEach(([x, y], i) => { ctx.save(); ctx.globalAlpha = 0.7; ctx.setLineDash([14, 14]); line([[x, y + 30], [960, 700]], C.white, 5); ctx.restore(); G.sat(x, y, 0.36, 0, i === 3); }); R.pill('4  =  POSITION + CLOCK', 960, 130, 50, pop(lt, 0.3), { hi: true }); } }); }
  add({ id: 'S47', at: A(46), cam: [960, 520], zoom: 0.04, note: 'right to a few billionths',
    draw(lt, d, t) { R.paper(); K.clock(960, 450, 1.3, lt * 0.8); R.pill('RIGHT TO A FEW BILLIONTHS OF A SECOND', 960, 790, 50, pop(lt, 0.4), { hi: true }); } });
  { const st = A(47), gr = Wc('gravity', 47);
    const sp = Wc('speed', 47);
    add({ id: 'S48', at: st, cam: [960, 520], zoom: 0.04, note: 'two kinds of relativity',
      draw(lt, d, t) { R.studio(880); host(960, lt, { arm: K.ARM.point, mouth: 'talk' }); R.pill('TWO KINDS OF RELATIVITY, CORRECTED', 960, 150, 50, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S48b', at: sp, cam: [960, 520], zoom: 0.04, note: 'speed -7',
      draw(lt, d, t) { zeroBars(eo(seg(lt, 0, 0.5)), 0, 0); R.pill('SPEED: THE CLOCK LOSES TIME', 960, 150, 46, pop(lt, 0.1)); } });
    add({ id: 'S48c', at: gr, cam: [960, 520], zoom: 0.04, note: 'gravity +45',
      draw(lt, d, t) { zeroBars(1, eo(seg(lt, 0, 0.5)), 0); R.pill('GRAVITY: THE CLOCK GAINS TIME', 960, 150, 46, pop(lt, 0.1), { hi: true }); } }); }
  { const st = A(48), hts = Wc('heights', 48), head = Wc('head', 48);
    add({ id: 'S49', at: st, cam: [960, 520], zoom: 0.04, note: '2010 optical clocks',
      draw(lt, d, t) { R.paper(); G.atom(960, 470, 1.1, t); R.pill('2010  ·  OPTICAL ATOMIC CLOCKS', 960, 850, 52, pop(lt, 0.4), { hi: true }); } });
    add({ id: 'S49a', at: hts, cam: [960, 520], zoom: 0.04, note: '33 cm apart',
      draw(lt, d, t) { R.paper(); const x = 860; K.clock(x, 330, 0.5, lt * 1.3); K.clock(x, 750, 0.5, lt * 1.0); dim(x + 260, 330, x + 260, 750, '33 cm', pop(lt, 0.4), 50); } });
    add({ id: 'S49b', at: head, cam: [960, 520], zoom: 0.04, note: 'your head ticks faster than your feet',
      draw(lt, d, t) { R.studio(880); host(960, lt, { arm: K.ARM.hip, armL: K.ARM.hip, mouth: 'grin' }); K.clock(1230, 250, 0.3, lt * 1.4); K.clock(1230, 800, 0.3, lt * 1.0); R.pill('HEAD  TICKS FASTER', 1580, 250, 40, pop(lt, 0.4), { hi: true }); R.pill('FEET', 1420, 800, 40, pop(lt, 0.8)); } }); }
  add({ id: 'S50', at: A(49), cam: [960, 520], zoom: 0.04, note: 'Einstein, proven right, in your pocket',
    draw(lt, d, t) { R.studio(880); host(660, lt, { arm: K.ARM.hold, armL: K.ARM.hip, mouth: 'grin', holding: (x, y) => { K.phone(x + 20, y - 60, 0.42, 0.1); } }); R.pill('EINSTEIN, PROVEN RIGHT', 1300, 380, 54, pop(lt, 0.6), { hi: true }); R.pill('IN YOUR POCKET', 1300, 500, 46, pop(lt, 2.2)); } });
  { const st = A(50), now = Wc('now', 50);
    add({ id: 'S51', at: st, cam: [960, 520], zoom: 0.05, note: 'loop back: the blue dot',
      draw(lt, d, t) { G.map(); K.phone(960, 500, 1.55, 0, C.paper, () => { }); G.dot(960, 500, 0.9, t); R.pill('WHY IT NEEDS EINSTEIN', 1400, 330, 50, pop(lt, now - st), { hi: true }); } }); }

  return { shots: S, cues: CUES };
}
