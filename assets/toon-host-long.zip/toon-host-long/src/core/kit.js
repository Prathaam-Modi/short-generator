// Toon Host engine: the COMPONENT ZOO. Every reusable thing on screen lives here.
// All functions draw immediately with the shared ctx, in 1080x1920 canvas pixels unless a scale is given.
// Look: flat fills + a thick wobbly ink outline on EVERYTHING (see lib.js blob / wEll / wRect / inkLine).
import { ctx, C, W, H, TAU, INK, lerp, clamp, rnd, rr, circle, ell, line, fillAll, blob, poly, wEll, wRect, inkLine, smooth } from './lib.js';

// ═════════════════════════ BACKGROUNDS ═════════════════════════
/** the default set: plain warm-grey studio wall + a slightly darker floor. The host stands on y ~1500 */
export function studio(fy = 1290) {
  fillAll(C.bg);
  ctx.fillStyle = C.floor; ctx.fillRect(-300, fy, W + 600, 900);
  ctx.fillStyle = C.floorLine; ctx.fillRect(-300, fy, W + 600, 6);
}
/** flat oval ground shadow under the shoes (no blur) */
export function shadow(x, y, w = 400, a = 1) { ctx.save(); ctx.globalAlpha = 0.25 * a; ell(x, y, w / 2, w * 0.065, C.ink); ctx.restore(); }
/** coloured wall with big soft circles + a floor strip: for a new "place" (accent = a palette colour) */
export function wall(color = C.orange, accent = C.orangeDark, t = 0, fy = 1290) {
  fillAll(color);
  ctx.globalAlpha = 0.55; circle(220 + Math.sin(t * 0.6) * 14, 520, 330, accent); circle(900, 1060 + Math.cos(t * 0.5) * 14, 420, accent); circle(780, 260, 160, accent); ctx.globalAlpha = 1;
  ctx.fillStyle = C.floor; ctx.fillRect(-300, fy, W + 600, 900); ctx.fillStyle = C.floorLine; ctx.fillRect(-300, fy, W + 600, 6);
}
/** graph-paper board for data / diagram shots. t scrolls it slowly */
export function grid(t = 0) {
  fillAll(C.paper);
  ctx.strokeStyle = C.paperLine; ctx.lineWidth = 3;
  const o = (t * 18) % 90;
  for (let x = -90; x <= W + 90; x += 90) { ctx.beginPath(); ctx.moveTo(x - o, -300); ctx.lineTo(x - o, H + 300); ctx.stroke(); }
  for (let y = -90; y <= H + 90; y += 90) { ctx.beginPath(); ctx.moveTo(-300, y - o); ctx.lineTo(W + 300, y - o); ctx.stroke(); }
}
/** dark "night / screen" backdrop for glitchy or serious moments */
export function dark(t = 0) {
  fillAll('#2A2928');
  ctx.strokeStyle = '#3A3938'; ctx.lineWidth = 3;
  for (let y = 0; y < H; y += 60) { ctx.beginPath(); ctx.moveTo(-300, y + ((t * 30) % 60)); ctx.lineTo(W + 300, y + ((t * 30) % 60)); ctx.stroke(); }
  ctx.fillStyle = '#1F1E1D'; ctx.fillRect(-300, 1500, W + 600, 700);
}

// ═════════════════════════ GRAPHICS (labels, marks, effects) ═════════════════════════
/** comic sticker label with a hard offset shadow. sc animates the pop */
export function sticker(text, x, y, size = 64, bg = C.yellow, fg = C.ink, sc = 1, rot = 0) {
  if (sc <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc);
  ctx.font = `900 ${size}px Inter`; ctx.letterSpacing = '1px';
  const w = ctx.measureText(text).width + size * 1.1, h = size * 1.6;
  wRect(-w / 2 + 8, -h / 2 + 9, w, h, h * 0.3, C.ink, { lw: 0 });
  wRect(-w / 2, -h / 2, w, h, h * 0.3, bg, { seed: text.length });
  ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, 0, size * 0.05);
  ctx.letterSpacing = '0px'; ctx.restore();
}
/** sticker with a pointer line + dot at the target */
export function tag(text, x, y, tx, ty, size = 58, sc = 1, bg = C.white) {
  if (sc <= 0) return;
  ctx.save(); ctx.globalAlpha = clamp(sc); inkLine([[x, y], [tx, ty]], C.ink, 6, 0); circle(tx, ty, 14, C.orange); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.restore();
  sticker(text, x, y, size, bg, C.ink, sc);
}
/** speech bubble. text may hold "\n" for lines; "*word" turns that word orange. tail points at (tx, ty). sc = pop */
export function bubble(text, x, y, w, h, tx, ty, size = 62, sc = 1) {
  if (sc <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.scale(sc, sc);
  const a = Math.atan2(ty - y, tx - x), bx = Math.cos(a) * w * 0.3, by = Math.sin(a) * h * 0.3;
  const tail = [[bx - 30 * Math.sin(a), by + 30 * Math.cos(a)], [tx - x, ty - y], [bx + 40 * Math.sin(a), by - 40 * Math.cos(a)]];
  poly(tail, C.white, { seed: 4, wob: 1 });
  wRect(-w / 2, -h / 2, w, h, h * 0.35, C.white, { seed: 9 });
  // cover the seam where the tail joins the bubble
  ctx.save(); ctx.fillStyle = C.white; ctx.beginPath(); ctx.moveTo(tail[0][0], tail[0][1]); ctx.lineTo(tail[2][0], tail[2][1]); ctx.lineTo(bx * 0.8, by * 0.8); ctx.closePath(); ctx.fill(); ctx.restore();
  const rows = text.split('\n'); ctx.font = `900 ${size}px Inter`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
  rows.forEach((row, ri) => {
    const ws = row.split(' '), widths = ws.map((s) => ctx.measureText(s.replace('*', '') + ' ').width), tw = widths.reduce((a2, b) => a2 + b, 0);
    let cx = -tw / 2; const cy = (ri - (rows.length - 1) / 2) * size * 1.15;
    ws.forEach((s, i) => { ctx.fillStyle = s.startsWith('*') ? C.orangeDark : C.ink; ctx.fillText(s.replace('*', ''), cx, cy); cx += widths[i]; });
  });
  ctx.restore();
}
/** red cross, outlined. a = alpha */
export function redX(x, y, s, a = 1) {
  if (a <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.globalAlpha = a;
  for (const [w, c] of [[104, C.ink], [76, C.red]]) { line([[-210, -210], [210, 210]], c, w); line([[210, -210], [-210, 210]], c, w); }
  ctx.restore();
}
/** green tick, outlined */
export function check(x, y, s, a = 1) {
  if (a <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.globalAlpha = a;
  for (const [w, c] of [[104, C.ink], [76, C.green]]) line([[-190, 20], [-60, 150], [200, -150]], c, w);
  ctx.restore();
}
/** chunky hand-drawn arrow along ang (radians). len in px. orange fill, ink outline */
export function arrow(x, y, len, ang = 0, a = 1, color = C.orange) {
  if (a <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.globalAlpha = a;
  poly([[-len / 2, -26], [len / 2 - 100, -30], [len / 2 - 100, -80], [len / 2, 0], [len / 2 - 100, 80], [len / 2 - 100, 30], [-len / 2, 26]], color, { seed: 2, wob: 1.5 });
  ctx.restore();
}
/** comic impact star. a = alpha, s = size (1 = ~260 px across) */
export function burst(x, y, s, a = 1, color = C.yellow, rot = 0) {
  if (a <= 0) return;
  const pts = []; const n = 14;
  for (let i = 0; i < n * 2; i++) { const an = (i / (n * 2)) * TAU + rot, r = (i % 2 ? 78 : 140) * s; pts.push([x + Math.cos(an) * r, y + Math.sin(an) * r]); }
  ctx.save(); ctx.globalAlpha = a; poly(pts, color, { seed: 6, wob: 2 }); ctx.restore();
}
/** horizontal speed lines trailing left of (x, y) */
export function speedLines(x, y, a = 1) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = a; for (let i = 0; i < 5; i++) line([[x - 80 - i * 20, y - 60 + i * 30], [x - 260 - i * 40, y - 60 + i * 30]], C.ink, 10); ctx.restore();
}
/** three "shock" strokes above a head (centre x, y; r = radius) */
export function shockLines(x, y, r, a = 1) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = a;
  for (const an of [-2.4, -Math.PI / 2, -0.75]) line([[x + Math.cos(an) * r, y + Math.sin(an) * r], [x + Math.cos(an) * (r + 70), y + Math.sin(an) * (r + 70)]], C.ink, 14);
  ctx.restore();
}
/** sweat drop (flies off the head when he is worried) */
export function sweat(x, y, s = 1, a = 1) {
  if (a <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.globalAlpha = a;
  blob([[0, -46], [24, -6], [28, 18], [14, 38], [-14, 38], [-28, 18], [-24, -6]], C.jeansLight, { seed: 3, wob: 1 });
  ctx.restore();
}
/** big outlined "?" or "!" (str), floats and rotates a little */
export function mark(str, x, y, s = 1, rot = 0, fill = C.orange) {
  if (s <= 0) return; const sizeBase = 230;
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  ctx.font = `900 ${sizeBase}px Inter`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.lineWidth = 46; ctx.strokeStyle = C.ink; ctx.strokeText(str, 0, 0); ctx.fillStyle = fill; ctx.fillText(str, 0, 0);
  ctx.restore();
}
export { bigText } from './lib.js';

// ═════════════════════════ PROPS ═════════════════════════
/** smartphone (220x420 at s = 1). inner(w, h) draws screen content in screen-local coords (centre 0,0) */
export function phone(x, y, s = 1, rot = 0, screen = C.white, inner = null) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-110, -210, 220, 420, 38, C.gray, { seed: 11 });
  ctx.save(); rr(-90, -184, 180, 368, 22); ctx.fillStyle = screen; ctx.fill(); ctx.clip();
  if (inner) inner(180, 368);
  ctx.restore();
  rr(-90, -184, 180, 368, 22); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke();
  wRect(-28, -196, 56, 14, 7, C.ink, { lw: 0 });
  ctx.restore();
}
/** feature phone, the old brick style (200x400): keypad + small screen */
export function brickPhone(x, y, s = 1, rot = 0, screen = C.green) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-100, -200, 200, 400, 46, C.gray, { seed: 21 });
  wRect(-64, -150, 128, 86, 10, screen, { seed: 22, lw: 6 });
  for (let r = 0; r < 4; r++) for (let c = 0; c < 3; c++) wRect(-62 + c * 44, -30 + r * 44, 36, 32, 10, C.grayLight, { seed: 30 + r * 3 + c, lw: 4, wob: 1 });
  ctx.restore();
}
/** microchip with pins (240 at s = 1); core colour defaults to orange */
export function chip(x, y, s = 1, core = C.orange, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  for (let i = 0; i < 5; i++) { const o = -80 + i * 40; for (const [px, py, w, h] of [[o - 8, -150, 16, 44], [o - 8, 106, 16, 44], [-150, o - 8, 44, 16], [106, o - 8, 44, 16]]) wRect(px, py, w, h, 5, C.grayLight, { lw: 5, wob: 1 }); }
  wRect(-110, -110, 220, 220, 26, C.gray, { seed: 41 });
  wRect(-62, -62, 124, 124, 14, core, { seed: 42, lw: 6 });
  circle(-82, -82, 8, C.grayLight);
  ctx.restore();
}
/** laptop (500 wide at s = 1). inner(w, h) draws screen content, centre 0,0 */
export function laptop(x, y, s = 1, screen = C.white, inner = null) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-230, -250, 460, 300, 24, C.gray, { seed: 51 });
  ctx.save(); rr(-206, -228, 412, 254, 10); ctx.fillStyle = screen; ctx.fill(); ctx.clip(); ctx.translate(0, -101); if (inner) inner(412, 254); ctx.restore();
  rr(-206, -228, 412, 254, 10); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke();
  poly([[-270, 56], [270, 56], [250, 92], [-250, 92]], C.grayLight, { seed: 52, wob: 1.5 });
  ctx.restore();
}
/** simple bar chart (w x h box, bottom-left at x, y). values 0..1 grow with p (0..1); hi = index in orange */
export function bars(x, y, w, h, values, p = 1, hi = -1) {
  const n = values.length, bw = w / (n * 1.5);
  line([[x - 20, y], [x + w + 20, y]], C.ink, 10);
  values.forEach((v, i) => {
    const bh = h * v * clamp(p * 1.4 - i * 0.12), bx = x + (i + 0.25) * (w / n) + 4;
    if (bh > 6) wRect(bx, y - bh - 6, bw, bh, 8, i === hi ? C.orange : C.jeans, { seed: 60 + i });
  });
}
/** coin with a symbol */
export function coin(x, y, s = 1, symbol = '$', rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wEll(0, 0, 90, 90, C.yellow, { seed: 70, n: 20 }); ctx.beginPath(); ctx.arc(0, 0, 66, 0, TAU); ctx.lineWidth = 6; ctx.strokeStyle = C.orangeDark; ctx.stroke();
  ctx.font = '900 96px Inter'; ctx.fillStyle = C.orangeDark; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(symbol, 0, 6);
  ctx.restore();
}
/** light bulb; on = glowing orange rays */
export function bulb(x, y, s = 1, on = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  if (on > 0) for (let i = 0; i < 8; i++) { const an = -Math.PI / 2 + (i - 3.5) * 0.45; line([[Math.cos(an) * 130, Math.sin(an) * 130 - 20], [Math.cos(an) * (130 + 46 * on), Math.sin(an) * (130 + 46 * on) - 20]], C.ink, 12); }
  wRect(-34, 70, 68, 56, 14, C.grayLight, { seed: 80 });
  blob([[0, -110], [60, -90], [88, -30], [70, 30], [36, 70], [-36, 70], [-70, 30], [-88, -30], [-60, -90]], on > 0 ? C.yellow : C.white, { seed: 81 });
  ctx.restore();
}
/** stopwatch-less clock face for "time passes" beats (a = hand angle) */
export function clock(x, y, s = 1, ang = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wEll(0, 0, 150, 150, C.white, { seed: 90, n: 20 });
  for (let i = 0; i < 12; i++) { ctx.save(); ctx.rotate(i * Math.PI / 6); line([[0, -126], [0, i % 3 === 0 ? -98 : -110]], C.ink, 8); ctx.restore(); }
  line([[0, 0], [Math.cos(ang - Math.PI / 2) * 100, Math.sin(ang - Math.PI / 2) * 100]], C.red, 12);
  line([[0, 0], [Math.cos(ang / 12 - Math.PI / 2) * 64, Math.sin(ang / 12 - Math.PI / 2) * 64]], C.ink, 14);
  circle(0, 0, 14, C.ink);
  ctx.restore();
}

/** gold crown (260 wide at s = 1), origin = bottom centre */
export function crown(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  poly([[-130, 0], [-140, -150], [-70, -80], [0, -190], [70, -80], [140, -150], [130, 0]], C.yellow, { seed: 200, wob: 2 });
  wRect(-130, -26, 260, 40, 10, C.orange, { seed: 201, wob: 1.2 });
  for (const [cx2, cy2] of [[-140, -154], [0, -196], [140, -154]]) circle(cx2, cy2, 14, C.red);
  ctx.restore();
}
/** a tooth (200 tall at s = 1); colour = enamel (white) or e.g. C.blue for the bluetooth joke */
export function tooth(x, y, s = 1, color = C.white, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  blob([[-70, -90], [-34, -110], [0, -96], [34, -110], [70, -90], [78, -20], [56, 40], [50, 110], [26, 118], [10, 50], [-10, 50], [-26, 118], [-50, 110], [-56, 40], [-78, -20]], color, { seed: 210, wob: 1.5 });
  line([[-44, -70], [-24, -84]], C.white, 10);
  ctx.restore();
}
/** radio waves: 3 arcs expanding from (x, y) toward ang. t = time for the pulse, p = alpha (0..1) */
export function waves(x, y, s = 1, ang = 0, t = 0, p = 1, color = C.orange) {
  if (p <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.globalAlpha = p;
  for (let i = 0; i < 3; i++) { const k = ((t * 1.2 + i / 3) % 1), r = (50 + k * 160) * s; ctx.globalAlpha = p * (1 - k * 0.8); ctx.beginPath(); ctx.arc(0, 0, r, -0.7, 0.7); ctx.strokeStyle = C.ink; ctx.lineWidth = 22 * s; ctx.lineCap = 'round'; ctx.stroke(); ctx.strokeStyle = color; ctx.lineWidth = 11 * s; ctx.stroke(); }
  ctx.restore();
}
/** sticky note (paper yellow square with a line of bold text) */
export function note(text, x, y, s = 1, rot = 0, size = 52) {
  if (s <= 0) return;
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-150 + 8, -110 + 9, 300, 220, 12, C.ink, { lw: 0 });
  wRect(-150, -110, 300, 220, 12, C.yellow, { seed: 220 });
  ctx.font = `900 ${size}px Inter`; ctx.fillStyle = C.ink; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const fit = Math.min(1, 262 / ctx.measureText(text).width);          // shrink long words to stay on the note
  ctx.scale(fit, fit); ctx.fillText(text, 0, 6 / fit);
  ctx.restore();
}
/** stone tablet (rounded, grey) for runes / old inscriptions. 260x340 at s = 1; draw rune strokes with K.rune */
export function stone(x, y, s = 1, rot = 0, inner = null) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  blob([[-110, -170], [0, -186], [110, -170], [126, 0], [116, 170], [0, 182], [-116, 170], [-126, 0]], C.grayLight, { seed: 230 });
  if (inner) inner();
  ctx.restore();
}
/** Younger Futhark runes drawn as strokes in a 120x200 box: 'hagall' (H) · 'bjarkan' (B) · 'fehu' (F) */
export function rune(kind, x, y, s = 1, color = C.ink) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  if (kind === 'hagall') { line([[0, -100], [0, 100]], color, 16); line([[-46, -40], [46, 40]], color, 14); line([[-46, 40], [46, -40]], color, 14); }
  if (kind === 'bjarkan') { line([[0, -100], [0, 100]], color, 16); line([[0, -100], [52, -50], [0, 0], [52, 50], [0, 100]], color, 14); }
  if (kind === 'fehu') { line([[0, -100], [0, 100]], color, 16); line([[0, -40], [52, -90]], color, 14); line([[0, 10], [52, -40]], color, 14); }
  ctx.restore();
}

/** flame (300 tall at s = 1), origin = bottom centre. t = time for the flicker */
export function flame(x, y, s = 1, t = 0) {
  if (s <= 0) return;
  const f = Math.sin(t * 9) * 12, g = Math.sin(t * 7 + 1) * 14;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  blob([[-90, 0], [-104, -70], [-60, -150], [-20 + f, -240], [10, -180], [40 + g, -300], [80, -170], [112, -90], [92, 0]], C.red, { seed: 240, wob: 1.5 });
  blob([[-52, 0], [-58, -50], [-26, -110], [10 + g / 2, -180], [46, -100], [64, -40], [52, 0]], C.orange, { seed: 241, wob: 1 });
  blob([[-24, 0], [-28, -34], [0, -84], [30, -30], [26, 0]], C.yellow, { seed: 242, wob: 1 });
  ctx.restore();
}
/** wooden plank platform with two legs. x, y = top-left-centre: y is the TOP surface, w = width */
export function platform(x, y, w = 560) {
  wRect(x - w / 2 + 40, y + 40, 46, 80, 8, C.hairDark, { seed: 251 });
  wRect(x + w / 2 - 86, y + 40, 46, 80, 8, C.hairDark, { seed: 252 });
  wRect(x - w / 2, y, w, 46, 10, C.hair, { seed: 250 });
}
/** cog wheel (200 across at s = 1), rot in radians */
export function gear(x, y, s = 1, rot = 0, color = C.grayLight) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  const pts = []; for (let i = 0; i < 32; i++) { const a = (i / 32) * TAU, tooth = Math.floor(i / 2) % 2 === 0; pts.push([Math.cos(a) * (tooth ? 100 : 76), Math.sin(a) * (tooth ? 100 : 76)]); }
  poly(pts, color, { seed: 260, wob: 1 });
  circle(0, 0, 30, C.paper); ctx.lineWidth = 7; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.restore();
}

// ═════════════════════════ THE HOST ═════════════════════════
// One hero: scruffy bearded guy, black sweater (sleeves pushed up), light jeans (rolled), white sneakers with orange panels.
// Origin = chest centre. At s = 1 he is ~1125 px tall (hair top ≈ -545, feet ≈ +640). Close-up: s 1.5-2.0.
// Arm poses are elbow/hand points for the RIGHT arm (x mirrors for the left). Blend them with armPose(a, b, t).
export const ARM = {
  down: { e: [186, 20], h: [176, 188] },
  cross: { e: [210, 8], h: [-118, -30] },          // the signature crossed-arms stance: front (right) arm
  crossBack: { e: [210, 44], h: [-92, 26] },       // ...and the back (left) arm: pass as `armL`
  point: { e: [262, -96], h: [226, -300], finger: -0.12 },   // index finger up
  wave: { e: [262, -110], h: [300, -330] },
  hip: { e: [262, 30], h: [140, 110] },
  shrug: { e: [236, -4], h: [292, -130] },         // palm up, "no idea" (use on both arms)
  chin: { e: [196, -46], h: [52, -224] },          // thinking: hand on the beard
  hold: { e: [210, -40], h: [188, -250] },         // holding a prop up next to the head
  open: { e: [236, -30], h: [336, -108] },         // "let me explain"
};
export const armPose = (a, b, t) => ({ e: [lerp(a.e[0], b.e[0], t), lerp(a.e[1], b.e[1], t)], h: [lerp(a.h[0], b.h[0], t), lerp(a.h[1], b.h[1], t)], finger: b.finger ?? a.finger });

function arm(side, pose, o) {
  const sh = [150 * side, -150], e = [pose.e[0] * side, pose.e[1]], h = [pose.h[0] * side, pose.h[1]];
  const ang = Math.atan2(h[1] - e[1], h[0] - e[0]), len = Math.hypot(h[0] - e[0], h[1] - e[1]);
  // forearm: bare skin with a few hairs
  inkLine([e, h], C.skin, 56);
  ctx.save(); ctx.translate(e[0], e[1]); ctx.rotate(ang);
  for (let i = 0; i < 6; i++) { const x0 = 40 + i * (len - 90) / 6, y0 = (rnd(i + side * 7) - 0.5) * 30; line([[x0, y0], [x0 + 9, y0 + 5]], C.hairDark, 4); }
  ctx.restore();
  // sleeve: shoulder -> elbow, pushed up past the elbow, ending in a ribbed cuff
  const ext = [lerp(e[0], h[0], 0.2), lerp(e[1], h[1], 0.2)];
  inkLine([sh, e, ext], C.sweater, 90);
  ctx.save(); ctx.translate(ext[0], ext[1]); ctx.rotate(ang); wEll(0, 0, 18, 46, C.sweaterHi, { seed: 5, lw: 6, wob: 1 }); ctx.restore();
  line([[sh[0] - 8 * side, sh[1] + 4], [lerp(sh[0], e[0], 0.5) - 8 * side, lerp(sh[1], e[1], 0.5) + 2]], C.sweaterHi, 12);
  // hand: palm + thumb + finger lines
  ctx.save(); ctx.translate(h[0], h[1]); ctx.rotate(ang);
  wEll(24, 0, 42, 34, C.skin, { seed: 14 });
  wEll(10, -side * 30, 22, 14, C.skin, { seed: 15, rot: -0.5 * side, lw: 6 });
  for (const k of [-12, 2, 16]) line([[44, k], [66, k * 0.9]], C.ink, 5);
  ctx.restore();
  if (pose.finger != null && side === 1) { ctx.save(); ctx.translate(h[0], h[1]); ctx.rotate(pose.finger + (o.finger || 0)); wRect(-14, -98, 28, 92, 14, C.skin, { seed: 16, lw: 7 }); ctx.restore(); }
}

function legs(o) {
  for (const side of [-1, 1]) {
    const x = side * 66;
    const pts = [[x - 66, 170], [x, 160], [x + 66, 170], [x + 62, 340], [x + 58, 522], [x, 528], [x - 58, 522], [x - 62, 340]];
    // leg
    const P = blob(pts, C.jeans, { seed: 100 + side });
    ctx.save(); smooth(P); ctx.clip();
    ctx.fillStyle = C.jeansShade; ctx.fillRect(x + side * 12, 150, 80, 400);               // outer shade band
    line([[x - 18, 230], [x - 22, 330], [x - 8, 420]], C.jeansShade, 8);                      // fold lines
    line([[x + 22, 300], [x + 28, 380]], C.jeansShade, 7);
    ctx.restore(); smooth(P); ctx.lineWidth = INK; ctx.strokeStyle = C.ink; ctx.lineJoin = 'round'; ctx.stroke();
    // rolled cuff
    blob([[x - 70, 500], [x, 494], [x + 70, 500], [x + 72, 540], [x, 548], [x - 72, 540]], C.jeansLight, { seed: 110 + side, wob: 1.5 });
    line([[x - 56, 522], [x + 56, 522]], C.jeansShade, 6);
    // ankle
    rr(x - 22, 548, 44, 22, 8); ctx.fillStyle = C.skin; ctx.fill();
    // sneaker (toe points outward)
    ctx.save(); ctx.translate(x, 0); ctx.scale(side, 1);
    blob([[-56, 556], [30, 556], [66, 586], [128, 598], [148, 626], [126, 650], [-54, 652], [-70, 618]], C.shoe, { seed: 120 + side });          // upper
    blob([[66, 596], [128, 604], [146, 626], [126, 648], [76, 650], [60, 620]], C.orange, { seed: 123 + side, lw: 6, wob: 1 });                    // toe cap
    blob([[-56, 612], [20, 604], [34, 628], [-52, 640]], C.orange, { seed: 125 + side, lw: 6, wob: 1 });                                          // side stripe
    wRect(-72, 638, 224, 30, 14, C.shoeShade, { seed: 127 + side, wob: 1.2 });                                                                    // sole
    for (const k of [0, 1, 2]) line([[8 + k * 16, 566 + k * 6], [24 + k * 16, 580 + k * 6]], C.ink, 5);                                           // laces
    ctx.restore();
  }
}

function torso() {
  // neck
  wEll(0, -222, 46, 40, C.skinShade, { seed: 130 });
  // sweater: loose, slightly wider at the hem
  const P = blob([[-132, -196], [0, -214], [132, -196], [170, -126], [176, 40], [170, 190], [90, 218], [0, 220], [-90, 218], [-170, 190], [-176, 40], [-170, -126]], C.sweater, { seed: 131 });
  ctx.save(); smooth(P); ctx.clip();
  line([[-120, 120], [-60, 70], [10, 110]], C.sweaterHi, 9);      // fabric folds
  line([[60, 140], [110, 90], [150, 120]], C.sweaterHi, 9);
  line([[-100, -120], [-60, -60]], C.sweaterHi, 9);
  line([[-176, 196], [176, 196]], C.sweaterHi, 16);               // ribbed hem
  ctx.restore(); smooth(P); ctx.lineWidth = INK; ctx.strokeStyle = C.ink; ctx.lineJoin = 'round'; ctx.stroke();
  // ribbed round collar
  wEll(0, -208, 66, 30, C.sweaterHi, { seed: 132, lw: 7 });
  wEll(0, -204, 44, 17, C.skinShade, { seed: 133, lw: 5, wob: 1 });
}

/**
 * The head alone (also exported for the style sheet). o = { eyes, mouth, talk, brow, frown, look, lookY, sweat }
 * eyes: 'n' | 'wide' | 'happy' | 'closed' | 'squint' · mouth: 'smile' | 'grin' | 'o' | 'flat' | 'smirk' | 'talk' | 'sad'
 */
export function head(o = {}) {
  ctx.save(); ctx.translate(0, -340);
  // ears + head
  for (const sd of [-1, 1]) { wEll(sd * 146, 10, 26, 38, C.skin, { seed: 140 + sd }); ell(sd * 148, 12, 10, 18, C.skinShade); }
  wEll(0, 0, 142, 134, C.skin, { seed: 141, n: 20 });
  // beard + moustache
  const B = blob([[-150, -10], [-154, 56], [-130, 120], [-82, 166], [0, 184], [82, 166], [130, 120], [154, 56], [150, -10], [112, 14], [64, 34], [0, 26], [-64, 34], [-112, 14]], C.hair, { seed: 142 });
  ctx.save(); smooth(B); ctx.clip();
  for (const [x0, y0, x1, y1] of [[-100, 60, -112, 130], [-60, 90, -66, 160], [-20, 100, -22, 170], [30, 100, 36, 172], [70, 84, 84, 150], [112, 56, 124, 120]]) line([[x0, y0], [x1, y1]], C.hairDark, 6);
  ctx.globalAlpha = 0.7; line([[-120, 40], [-96, 110]], C.hairHi, 10); line([[96, 100], [120, 56]], C.hairHi, 10); ctx.globalAlpha = 1;
  ctx.restore(); smooth(B); ctx.lineWidth = INK; ctx.strokeStyle = C.ink; ctx.lineJoin = 'round'; ctx.stroke();
  // mouth (sits in the beard)
  const m = o.mouth || 'smile'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (m === 'smile') { ctx.beginPath(); ctx.moveTo(-34, 84); ctx.quadraticCurveTo(0, 112, 34, 84); ctx.strokeStyle = C.mouth; ctx.lineWidth = 9; ctx.stroke(); }
  if (m === 'smirk') { ctx.beginPath(); ctx.moveTo(-30, 94); ctx.quadraticCurveTo(10, 104, 40, 70); ctx.strokeStyle = C.mouth; ctx.lineWidth = 9; ctx.stroke(); }
  if (m === 'flat') line([[-30, 92], [30, 92]], C.mouth, 9);
  if (m === 'sad') { ctx.beginPath(); ctx.moveTo(-32, 104); ctx.quadraticCurveTo(0, 78, 32, 104); ctx.strokeStyle = C.mouth; ctx.lineWidth = 9; ctx.stroke(); }
  if (m === 'o') { wEll(0, 96, 24, 32, C.mouth, { seed: 150, lw: 5, wob: 1 }); ell(0, 110, 15, 10, C.tongue); }
  if (m === 'talk') { const k = clamp(o.talk ?? 0.6); wEll(0, 90 + k * 8, 34, 8 + k * 24, C.mouth, { seed: 151, lw: 5, wob: 1 }); if (k > 0.35) ell(0, 90 + k * 22, 20, 7 + k * 5, C.tongue); }
  if (m === 'grin') {
    blob([[-44, 74], [0, 82], [44, 74], [38, 112], [0, 128], [-38, 112]], C.mouth, { seed: 152, lw: 6, wob: 1 });
    ctx.save(); rr(-34, 78, 68, 20, 6); ctx.fillStyle = C.white; ctx.fill(); ctx.restore();
  }
  for (const sd of [-1, 1]) wEll(sd * 38, 56, 52, 24, C.hair, { seed: 153 + sd, rot: sd * 0.25, lw: 7, wob: 1.2 });   // moustache lobes
  // nose
  wEll(0, 38, 30, 26, C.skinShade, { seed: 156 });
  ell(-8, 30, 9, 6, C.skin);
  // eyes
  const lk = (o.look || 0) * 9, lky = (o.lookY || 0) * 7;
  for (const sd of [-1, 1]) {
    const ex = sd * 54, ey = -30;
    if (o.eyes === 'closed') { ctx.beginPath(); ctx.arc(ex, ey + 8, 20, 0.1 * Math.PI, 0.9 * Math.PI); ctx.strokeStyle = C.ink; ctx.lineWidth = 8; ctx.stroke(); continue; }
    if (o.eyes === 'happy') { ctx.beginPath(); ctx.arc(ex, ey + 14, 22, 1.15 * Math.PI, 1.85 * Math.PI); ctx.strokeStyle = C.ink; ctx.lineWidth = 9; ctx.stroke(); continue; }
    const wide = o.eyes === 'wide', sq = o.eyes === 'squint';
    wEll(ex, ey, wide ? 44 : 38, wide ? 50 : sq ? 24 : 44, C.white, { seed: 160 + sd, lw: 7, wob: 1 });
    circle(ex + lk, ey + lky + 2, wide ? 8 : 11, C.ink); circle(ex + lk + 4, ey + lky - 4, 3.5, C.white);
  }
  // messy hair: spiky tufts + a side swoop
  const hair = poly([[-150, -40], [-166, -96], [-140, -118], [-150, -168], [-104, -148], [-92, -200], [-56, -168], [-30, -214], [4, -170], [40, -222], [62, -170], [102, -198], [110, -150], [150, -156], [138, -112], [160, -84], [142, -44], [118, -100], [60, -118], [-10, -108], [-70, -118], [-120, -96], [-150, -62]], C.hair, { seed: 170, wob: 2 });
  ctx.save(); ctx.beginPath(); ctx.moveTo(hair[0][0], hair[0][1]); for (let i = 1; i < hair.length; i++) ctx.lineTo(hair[i][0], hair[i][1]); ctx.closePath(); ctx.clip();
  for (const [x0, y0, x1, y1] of [[-100, -150, -90, -100], [-30, -180, -20, -110], [40, -190, 36, -110], [96, -170, 84, -104], [-128, -100, -116, -70]]) line([[x0, y0], [x1, y1]], C.hairDark, 6);
  ctx.globalAlpha = 0.7; line([[-70, -150], [-40, -120]], C.hairHi, 10); line([[60, -168], [84, -140]], C.hairHi, 10); ctx.globalAlpha = 1;
  ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.moveTo(hair[0][0], hair[0][1]); for (let i = 1; i < hair.length; i++) ctx.lineTo(hair[i][0], hair[i][1]); ctx.closePath(); ctx.lineWidth = INK; ctx.strokeStyle = C.ink; ctx.lineJoin = 'round'; ctx.stroke(); ctx.restore();
  // brows (after the hair so they stay visible): brow 0..1 raises, frown 0..1 angles them down toward the nose
  const br = (o.brow || 0) * 18, fr = (o.frown || 0) * 18;
  for (const sd of [-1, 1]) {
    ctx.beginPath(); ctx.moveTo(sd * 92, -84 - br + fr * 0.2); ctx.quadraticCurveTo(sd * 58, -104 - br - fr * 0.3, sd * 18, -84 - br + fr);
    ctx.strokeStyle = C.ink; ctx.lineWidth = 24; ctx.lineCap = 'round'; ctx.stroke();
    ctx.strokeStyle = C.hairDark; ctx.lineWidth = 12; ctx.stroke();
  }
  if (o.sweat) sweat(128, -90, 0.7, 1);
  ctx.restore();
}

/**
 * The hero. o = { x, y, s, rot, arm (pose), armL (pose, default = mirror of arm), finger (extra wag rad), eyes, mouth, talk, brow, frown, look, lookY,
 *   sweat, holding: (x, y) => draw a prop at the right hand, holdingL: same for the left, flip (face the other way) }
 */
export function host(o = {}) {
  const s = o.s || 1;
  ctx.save(); ctx.translate(o.x ?? 540, o.y ?? 1000); ctx.rotate(o.rot || 0); ctx.scale(s * (o.flip ? -1 : 1), s);
  const ra = o.arm || ARM.cross, la = o.armL || (ra === ARM.cross ? ARM.crossBack : ARM.down);
  legs(o);
  torso();
  arm(-1, la, o);
  if (o.holdingL) o.holdingL(-la.h[0] + 30, la.h[1] - 10);
  head(o);
  arm(1, ra, o);
  if (o.holding) o.holding(ra.h[0] - 10, ra.h[1] - 40);
  ctx.restore();
}
