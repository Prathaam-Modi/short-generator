// Music props for the Reel look (cassettebydimo): same Toon Host rules (flat fill + wobbly ink outline), same palette.
// Every prop is drawn centred at (x, y), scale s, optional rotation; t = film time for the little animations.
import { ctx, C, TAU, wRect, wEll, inkLine, circle } from './lib.js';

/** turntable / DJ deck (440 x 320 at s = 1). Platter spins with t */
export function deck(x, y, s = 1, t = 0, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-220, -160, 440, 320, 30, C.gray, { seed: 51 });
  wEll(-30, 0, 128, 128, C.ink, { seed: 52, lw: 0 });
  ctx.save(); ctx.translate(-30, 0); ctx.rotate(t * 3.4);
  for (const r of [112, 92, 72]) { ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.lineWidth = 3; ctx.strokeStyle = '#3A3A3A'; ctx.stroke(); }
  wEll(0, 0, 44, 44, C.orange, { seed: 53 });
  circle(0, 0, 8, C.ink); circle(24, -8, 5, C.white);
  ctx.restore();
  // tonearm
  wEll(168, -108, 22, 22, C.grayLight, { seed: 54, lw: 6 });
  inkLine([[168, -108], [150, -20], [70, 60]], C.grayLight, 12, 5);
  wRect(46, 52, 46, 26, 8, C.orange, { seed: 55, lw: 6, wob: 1 });
  // start button + pitch fader
  wRect(150, 100, 52, 38, 10, C.green, { seed: 56, lw: 6, wob: 1 });
  wRect(180, -60, 22, 120, 8, C.grayLight, { seed: 57, lw: 5, wob: 1 });
  wRect(172, -10, 38, 20, 6, C.white, { seed: 58, lw: 5, wob: 1 });
  ctx.restore();
}

/** DJ mixer (300 x 380): two channel faders + knobs + a crossfader */
export function mixer(x, y, s = 1, fade = 0.5, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-150, -190, 300, 380, 26, C.gray, { seed: 61 });
  for (const cx of [-70, 70]) {
    for (let i = 0; i < 3; i++) { wEll(cx, -140 + i * 54, 20, 20, i === 0 ? C.orange : C.grayLight, { seed: 62 + i, lw: 6, wob: 1 }); ctx.beginPath(); ctx.moveTo(cx, -140 + i * 54); ctx.lineTo(cx + 9, -152 + i * 54); ctx.lineWidth = 4; ctx.strokeStyle = C.ink; ctx.stroke(); }
    wRect(cx - 7, 30, 14, 100, 6, C.ink, { lw: 0 });
    wRect(cx - 24, 50 + (1 - (cx < 0 ? fade : 1 - fade)) * 50, 48, 24, 7, C.white, { seed: 70, lw: 5, wob: 1 });
  }
  wRect(-60, 152, 120, 14, 6, C.ink, { lw: 0 });
  wRect(-22 + (fade - 0.5) * 70, 142, 44, 34, 8, C.orange, { seed: 71, lw: 5, wob: 1 });
  ctx.restore();
}

/** headphones (240 x 230) */
export function headphones(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  inkLine([[-92, 30], [-96, -50], [-50, -104], [0, -118], [50, -104], [96, -50], [92, 30]], C.gray, 18, 7);
  for (const sx of [-1, 1]) {
    wRect(sx * 96 - 34, -20, 68, 116, 26, C.orange, { seed: 81 + sx });
    wRect(sx * 96 - 20, 0, 40, 76, 16, C.orangeDark, { seed: 83 + sx, lw: 5, wob: 1 });
  }
  ctx.restore();
}

/** speaker cabinet (260 x 380); beat = 0..1 pulses the woofer */
export function speaker(x, y, s = 1, beat = 0, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-130, -190, 260, 380, 24, C.gray, { seed: 91 });
  wEll(0, -100, 36 + beat * 4, 36 + beat * 4, C.grayLight, { seed: 92, lw: 6 });
  circle(0, -100, 12, C.ink);
  wEll(0, 40, 80 + beat * 10, 80 + beat * 10, C.ink, { seed: 93, lw: 0 });
  wEll(0, 40, 58 + beat * 10, 58 + beat * 10, C.orange, { seed: 94 });
  circle(0, 40, 16, C.orangeDark); circle(-20, 20, 6, C.white);
  ctx.restore();
}

/** cassette tape (360 x 230). Reels turn with t. The channel's mascot prop */
export function cassette(x, y, s = 1, t = 0, rot = 0, label = '') {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-180, -115, 360, 230, 22, C.orange, { seed: 101 });
  wRect(-148, -88, 296, 116, 14, C.paper, { seed: 102, lw: 6, wob: 1 });
  if (label) { ctx.font = '900 30px Inter'; ctx.fillStyle = C.ink; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, 0, -66); }
  for (const cx of [-70, 70]) {
    wEll(cx, 2, 30, 30, C.ink, { seed: 103 + cx, lw: 0 });
    ctx.save(); ctx.translate(cx, 2); ctx.rotate(t * 2.4);
    for (let i = 0; i < 6; i++) { ctx.rotate(TAU / 6); ctx.fillStyle = C.white; ctx.fillRect(-4, -30, 8, 14); }
    ctx.restore();
  }
  wRect(-96, 52, 192, 52, 10, C.orangeDark, { seed: 110 });
  for (const cx of [-60, 60]) circle(cx, 78, 9, C.ink);
  ctx.restore();
}

/** synth keyboard (460 x 200): white keys with 3 black keys, lit = index of a pressed key (or -1) */
export function keys(x, y, s = 1, lit = -1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-230, -100, 460, 200, 18, C.gray, { seed: 121 });
  for (let i = 0; i < 6; i++) wRect(-212 + i * 71, -64, 64, 152, 10, i === lit ? C.orange : C.white, { seed: 122 + i, lw: 5, wob: 1 });
  for (const i of [0, 1, 3, 4]) wRect(-212 + (i + 1) * 71 - 20, -64, 40, 88, 8, C.ink, { lw: 0 });
  for (let i = 0; i < 4; i++) wEll(-190 + i * 40, -82, 9, 9, C.grayLight, { seed: 130 + i, lw: 4, wob: 0.6 });
  ctx.restore();
}

/** 4x4 drum pad grid (300 x 300); lit = array of pad indexes that glow */
export function pads(x, y, s = 1, lit = [], rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-150, -150, 300, 300, 24, C.gray, { seed: 141 });
  for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) { const i = r * 4 + c; wRect(-126 + c * 62, -126 + r * 62, 52, 52, 10, lit.includes(i) ? (i % 3 === 0 ? C.orange : C.yellow) : C.grayLight, { seed: 142 + i, lw: 5, wob: 0.8 }); }
  ctx.restore();
}

/** a waveform strip: w x h, bars follow v (0..1 array); hi = bars at/after this index in orange */
export function waveform(x, y, w, h, v, hi = -1) {
  const n = v.length, bw = w / n;
  ctx.save(); ctx.translate(x, y);
  wRect(-w / 2 - 20, -h / 2 - 20, w + 40, h + 40, 22, C.sweater, { seed: 151 });
  v.forEach((a, i) => wRect(-w / 2 + i * bw + 3, -a * h / 2, bw - 6, Math.max(8, a * h), 5, hi >= 0 && i >= hi ? C.orange : C.white, { lw: 4, wob: 0.6, seed: 152 + i }));
  ctx.restore();
}

/** a rotary knob (80 at s = 1), ang in radians (0 = up) */
export function knob(x, y, s = 1, ang = 0, color = C.orange) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  for (let i = 0; i < 9; i++) { const a = -2.2 + i * 0.55; ctx.beginPath(); ctx.arc(Math.sin(a) * 58, -Math.cos(a) * 58, 4, 0, TAU); ctx.fillStyle = C.ink; ctx.fill(); }
  wEll(0, 0, 40, 40, color, { seed: 161 });
  ctx.rotate(ang); wRect(-5, -36, 10, 30, 4, C.ink, { lw: 0 });
  ctx.restore();
}

/** a floating music note / sound ripple for decoration */
export function noteIcon(x, y, s = 1, rot = 0, color = C.orange) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  inkLine([[22, 70], [22, -60]], C.ink, 12, 0);
  inkLine([[22, -60], [70, -38], [70, -8]], C.ink, 12, 0);
  wEll(-4, 74, 30, 22, color, { seed: 171, rot: -0.4 });
  ctx.restore();
}
