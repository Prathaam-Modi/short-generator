// Captions: 1-3 words, Inter Black, white with a thick ink outline, ONE orange word, centre lower third.
// Each script line has "caps": "WHAT IF *YOU | SWALLOW *GUM?"  ("|" = next caption, "*" = the orange word).
// Without "caps", the line is chunked automatically (2-3 words, the longest word goes orange).
// A chunk appears 0.05 s before its first word and stays until the next chunk (or shortly after the line ends).
import { ctx, C, clamp, lerp, seg, eob } from './lib.js';
import { T, lineWords } from './timing.js';

export const CAP = { y: 985, size: 58, maxW: 1560 };   // long-form: quiet subtitle, bottom edge, mixed case
let caps = [];

function autoChunks(text) {
  // clause-aware: break at , . ; : ? ! first, then split clauses longer than 7 words into near-equal halves
  const clauses = text.split(/(?<=[,.;:?!])\s+/).map((c) => c.split(/\s+/).filter(Boolean)).filter((c) => c.length), out = [];
  for (const c of clauses) {
    const parts = Math.ceil(c.length / 7), size = Math.ceil(c.length / parts);
    for (let i = 0; i < c.length; i += size) out.push(c.slice(i, i + size));
  }
  // merge tiny leftovers (1-2 words) into the previous chunk when it stays short
  for (let i = out.length - 1; i > 0; i--) if (out[i].length <= 2 && out[i - 1].length + out[i].length <= 8) { out[i - 1] = out[i - 1].concat(out[i]); out.splice(i, 1); }
  const len = (w) => w.replace(/[^A-Za-z]/g, '').length;
  return out.map((c) => { const k = c.reduce((b, w, j) => (len(w) > len(c[b]) ? j : b), 0); return c.map((w, j) => (j === k ? '*' + w : w)).join(' '); });
}

export function buildCaptions(script) {
  caps = [];
  script.lines.forEach((ln, i) => {
    const chunks = (ln.caps ? ln.caps.split('|') : autoChunks(ln.text)).map((s) => s.trim()).filter(Boolean);
    const ws = lineWords(i); if (!ws.length) return;
    const counts = chunks.map((c) => c.split(/\s+/).length), N = counts.reduce((a, b) => a + b, 0);
    const nm = (w) => String(w).toLowerCase().replace(/[^a-z0-9']+/g, '');
    let acc = 0, from = 0;
    chunks.forEach((c, j) => {
      // find the chunk's first word in the spoken line (from where the last chunk started); else place it by word count
      const first = nm(c.split(/\s+/)[0]);
      let idx = j === 0 ? 0 : ws.findIndex((w, k) => k > from && first && (nm(w.w) === first || (first.length > 2 && nm(w.w).startsWith(first))));
      if (idx < 0) idx = Math.max(from + (j ? 1 : 0), Math.min(ws.length - 1, Math.round(acc * ws.length / N)));
      acc += counts[j]; from = idx;
      caps.push({ line: i, s: ws[idx].s - 0.05, words: c.split(/\s+/).map((w) => ({ txt: w.replace('*', ''), hi: w.startsWith('*') })) });
    });
  });
  caps.forEach((c, k) => {
    const next = caps[k + 1], lineEnd = T.lines[c.line].end;
    c.e = next ? (next.s - lineEnd > 0.7 && next.line !== c.line ? lineEnd + 0.35 : next.s) : T.dur;
  });
  return caps;
}
export const captionList = () => caps;

export function drawCaption(t) {
  const c = caps.find((c) => t >= c.s && t < c.e); if (!c) return;
  const lt = t - c.s, size = CAP.size;
  ctx.font = `900 ${size}px Inter`; ctx.letterSpacing = '0px';
  const sp = size * 0.28;
  c.words.forEach((w) => (w.w = ctx.measureText(w.txt).width));
  const width = (ws) => ws.reduce((a, w) => a + w.w, 0) + sp * (ws.length - 1);
  let lines = [c.words];
  if (width(c.words) > CAP.maxW && c.words.length > 1) {
    let best = null;
    for (let i = 1; i < c.words.length; i++) { const a = c.words.slice(0, i), b = c.words.slice(i), m = Math.max(width(a), width(b)); if (!best || m < best.m) best = { m, l: [a, b] }; }
    lines = best.l;
  }
  const fit = Math.min(1, CAP.maxW / Math.max(...lines.map(width)));
  const sc = fit; ctx.globalAlpha = clamp(lt / 0.12);
  ctx.save(); ctx.translate(1920 / 2, CAP.y); ctx.scale(sc, sc);
  ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.lineJoin = 'round';
  const lh = size, y0 = -(lines.length - 1) * lh / 2;
  lines.forEach((ln, li) => {
    let x = -width(ln) / 2; const y = y0 + li * lh;
    for (const w of ln) {
      ctx.lineWidth = 12; ctx.strokeStyle = C.ink; ctx.strokeText(w.txt, x, y + 3); ctx.strokeText(w.txt, x, y);
      ctx.fillStyle = w.hi ? C.orange : C.white; ctx.fillText(w.txt, x, y); x += w.w + sp;
    }
  });
  ctx.letterSpacing = '0px'; ctx.restore(); ctx.globalAlpha = 1;
}
