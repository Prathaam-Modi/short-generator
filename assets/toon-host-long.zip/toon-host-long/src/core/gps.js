// GPS props (same inked look): globe, satellite, broadcast rings, map, location dot, atom, dish, jet, Sputnik, lighthouse, gravity well.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, rnd, circle, line, ell, blob, poly, wEll, wRect, inkLine } from './lib.js';
import * as R from './space.js';

export function globe(x, y, r, rot = 0) {
  ctx.save(); ctx.translate(x, y);
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fillStyle = C.blue; ctx.fill(); ctx.save(); ctx.clip();
  ctx.rotate(rot);
  for (const [bx, by, bs, sd] of [[-0.35, -0.3, 0.42, 3], [0.38, 0.1, 0.36, 4], [-0.1, 0.5, 0.28, 5], [0.1, -0.7, 0.2, 6]]) {
    const P = []; for (let i = 0; i < 9; i++) { const a = (i / 9) * TAU, rr = bs * (0.7 + rnd(sd * 10 + i) * 0.6); P.push([bx * r + Math.cos(a) * rr * r, by * r + Math.sin(a) * rr * r * 0.8]); }
    blob(P, C.green, { seed: sd, lw: 6 });
  }
  ctx.restore();
  ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.lineWidth = 9; ctx.strokeStyle = C.ink; ctx.stroke();
  ctx.restore();
}
/** satellite ~380 wide at s = 1; hi = orange body */
export function sat(x, y, s = 1, rot = 0, hi = false) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  for (const sx of [-1, 1]) {
    ctx.save(); ctx.scale(sx, 1);
    inkLine([[40, 0], [70, 0]], C.grayLight, 10, 5);
    wRect(70, -42, 130, 84, 6, C.blue, { seed: 201, lw: 7, wob: 1 });
    for (let i = 1; i < 3; i++) line([[70 + i * 43, -40], [70 + i * 43, 40]], C.white, 4);
    line([[72, 0], [198, 0]], C.white, 4);
    ctx.restore();
  }
  wRect(-44, -44, 88, 88, 14, hi ? C.orange : C.grayLight, { seed: 202 });
  circle(0, 0, 14, C.ink);
  inkLine([[0, -44], [0, -78]], C.ink, 5, 0); circle(0, -84, 9, C.orange);
  ctx.restore();
}
/** expanding broadcast rings from (x, y); t = clock */
export function rings(x, y, t, o = {}) {
  const { n = 3, max = 420, color = C.white, w = 7, speed = 0.5, arc = null } = o;
  ctx.save(); ctx.lineWidth = w; ctx.strokeStyle = color; ctx.lineCap = 'round';
  for (let i = 0; i < n; i++) { const p = (t * speed + i / n) % 1; ctx.globalAlpha = (1 - p) * 0.9; ctx.beginPath(); if (arc) ctx.arc(x, y, 30 + p * max, arc[0], arc[1]); else ctx.arc(x, y, 30 + p * max, 0, TAU); ctx.stroke(); }
  ctx.restore();
}
/** flat city-map background: pale blocks, white roads, a river and a park */
export function map() {
  R.paper();
  ctx.fillStyle = '#BFD6EA'; ctx.beginPath(); ctx.moveTo(-50, 760); ctx.bezierCurveTo(500, 640, 900, 900, 1400, 760); ctx.bezierCurveTo(1650, 700, 1800, 760, 1980, 700); ctx.lineTo(1980, 830); ctx.bezierCurveTo(1800, 880, 1650, 820, 1400, 890); ctx.bezierCurveTo(900, 1030, 500, 770, -50, 890); ctx.fill();
  ctx.fillStyle = '#CFE3C6'; ctx.fillRect(1180, 160, 420, 300);
  for (const x of [260, 600, 940, 1280, 1620]) line([[x, -20], [x, 1100]], C.white, 34);
  for (const y of [230, 500]) line([[-20, y], [1940, y]], C.white, 34);
  line([[-20, 40], [1940, 380]], C.white, 22);
}
/** location dot: blue core, white ring, orange pulse */
export function dot(x, y, s = 1, t = 0, o = {}) {
  const { pulse = true, color = C.blue, ring = C.orange } = o;
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  if (pulse) { const p = (t * 0.8) % 1; ctx.globalAlpha = 1 - p; ctx.beginPath(); ctx.arc(0, 0, 40 + p * 90, 0, TAU); ctx.lineWidth = 8; ctx.strokeStyle = ring; ctx.stroke(); ctx.globalAlpha = 1; }
  circle(0, 0, 38, C.white); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke();
  circle(0, 0, 25, color);
  ctx.restore();
}
export function lighthouse(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[-80, 0], [80, 0], [50, -330], [-50, -330]], C.white, { seed: 211 });
  poly([[-72, -60], [72, -60], [66, -130], [-66, -130]], C.red, { seed: 212 });
  poly([[-58, -190], [58, -190], [54, -260], [-54, -260]], C.red, { seed: 213 });
  wRect(-62, -400, 124, 72, 10, C.yellow, { seed: 214 }); poly([[-76, -400], [76, -400], [0, -470]], C.gray, { seed: 215 });
  ctx.restore();
}
export function dish(x, y, s = 1, ang = -0.8) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  poly([[-60, 0], [60, 0], [30, -110], [-30, -110]], C.grayLight, { seed: 221 });
  ctx.save(); ctx.translate(0, -120); ctx.rotate(ang);
  ctx.beginPath(); ctx.ellipse(0, 0, 130, 130, 0, Math.PI * 0.05, Math.PI * 0.95); ctx.closePath(); ctx.fillStyle = C.white; ctx.fill(); ctx.lineWidth = 8; ctx.strokeStyle = C.ink; ctx.lineJoin = 'round'; ctx.stroke();
  inkLine([[0, 0], [0, 130]], C.ink, 6, 0); circle(0, 138, 12, C.orange);
  ctx.restore(); ctx.restore();
}
export function atom(x, y, s = 1, t = 0) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  for (let i = 0; i < 3; i++) { ctx.save(); ctx.rotate(i * Math.PI / 3); ctx.beginPath(); ctx.ellipse(0, 0, 230, 80, 0, 0, TAU); ctx.lineWidth = 7; ctx.strokeStyle = C.ink; ctx.stroke(); ctx.restore(); }
  for (let i = 0; i < 3; i++) { const a = t * (2 + i * 0.4) + i * 2.1; const ex = Math.cos(a) * 230, ey = Math.sin(a) * 80, r = i * Math.PI / 3; const X = ex * Math.cos(r) - ey * Math.sin(r), Y = ex * Math.sin(r) + ey * Math.cos(r); circle(X, Y, 20, C.blue); ctx.lineWidth = 6; ctx.strokeStyle = C.ink; ctx.stroke(); }
  wEll(0, 0, 54, 54, C.orange, { seed: 231, n: 14 });
  ctx.restore();
}
export function jet(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wEll(0, 0, 150, 30, C.white, { seed: 5 }); poly([[-20, 0], [-90, -70], [-60, -70], [30, 0]], C.blue, { seed: 6 }); poly([[-20, 6], [-90, 76], [-60, 76], [30, 6]], C.blue, { seed: 7 }); poly([[-120, -4], [-160, -56], [-136, -56], [-96, -4]], C.orange, { seed: 8 });
  ctx.restore();
}
export function sputnik(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  for (const [a, l] of [[-0.5, 260], [-0.2, 300], [0.2, 300], [0.5, 260]]) inkLine([[60, 0], [60 + Math.cos(a) * l, Math.sin(a) * l]], C.grayLight, 8, 4);
  for (const [a, l] of [[-0.5, 260], [-0.2, 300], [0.2, 300], [0.5, 260]]) inkLine([[-60, 0], [-60 - Math.cos(a) * l, Math.sin(a) * l]], C.grayLight, 8, 4);
  wEll(0, 0, 90, 90, C.grayLight, { seed: 241, n: 18 }); ell(-26, -30, 24, 14, '#B7B2AC', -0.6);
  ctx.restore();
}
/** gravity well: sheet that dips to a bottom at x. returns y of the sheet at px */
export function well(cx, y0, wd, depth) {
  const f = (px) => y0 + depth * Math.exp(-Math.pow((px - cx) / (wd * 0.28), 2));
  ctx.save(); ctx.beginPath(); ctx.moveTo(cx - wd, f(cx - wd));
  for (let i = 1; i <= 80; i++) { const px = cx - wd + (2 * wd * i) / 80; ctx.lineTo(px, f(px)); }
  ctx.lineWidth = 12; ctx.strokeStyle = C.ink; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.stroke();
  for (let k = 1; k <= 3; k++) { ctx.beginPath(); for (let i = 0; i <= 60; i++) { const px = cx - wd + (2 * wd * i) / 60; const yy = f(px) + k * 30; i ? ctx.lineTo(px, yy) : ctx.moveTo(px, yy); } ctx.lineWidth = 5; ctx.strokeStyle = C.grayLight; ctx.stroke(); }
  ctx.restore(); return f;
}
/** two-line clock face with its own label (small) */
export function labeledClock(x, y, s, ang, label, hi = false) {
  K_clock(x, y, s, ang); R.pill(label, x, y + 150 * s + 70, 38, 1, { hi });
}
import * as K from './kit.js';
function K_clock(x, y, s, ang) { K.clock(x, y, s, ang); }
export function cereal(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  wRect(-110, -170, 220, 340, 10, C.yellow, { seed: 251 }); wRect(-80, -130, 160, 110, 30, C.white, { seed: 252, lw: 6 });
  R.txt('CRUNCH', 0, -75, 34, C.red, 'center', 1); wRect(-100, 40, 200, 90, 8, C.orange, { seed: 253, lw: 6 });
  ctx.restore();
}
export function ticket(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-130, -70, 260, 140, 14, C.white, { seed: 261 }); line([[40, -62], [40, 62]], C.grayLight, 5); jet(-50, 0, 0.4, 0);
  ctx.restore();
}
