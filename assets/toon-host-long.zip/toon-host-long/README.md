# Toon Host LONG-FORM engine (landscape 1920x1080)
Reference project: "How Does A Rocket Land Itself?" (script.json + src/shots.js). Copy this folder to a new project dir, then:
 1. write script.json (lines, sources, voice am_michael, speed 1.0..1.05, lead 0.5, outro 1.4, gap 0.3, music "bed", badge SE)
 2. voice.py + words.py from the faceless-shorts SKILL/scripts (same as Shorts; data/ gets narration.wav, lines.json, words.json)
 3. rewrite src/shots.js for the new topic (keep helpers, chapters via add({chap}), style rules in src/sheet.js).
    New props go in src/core/space.js or kit.js in the same flat-fill + thick ink look.
 4. node tools/capture.mjs check  (CHECK OK) ; cues ; python mix.py ; sheet ; frames ; video
    Render: CRF=24 MAXRATE=1500k node tools/capture.mjs video renders/<name>.mp4  (6 min video renders in ~6 min, ~35 MB)
    Thumbnail frame without captions: QS='&nocap=1' node tools/capture.mjs frames review/th "<t>"
 Style sheet: QS='&sheet=1' node tools/capture.mjs frames review/sheet "0"
 Thumbnail scene mode: QS='&thumb=1' node tools/capture.mjs frames review/th "0" renders src/thumb.js (dark sky, big rocket, ship). For a new topic rewrite src/thumb.js with ONE big focal object on a DARK flat background (navy), then add text with PIL (see state/published.md THUMBNAIL RULES).
