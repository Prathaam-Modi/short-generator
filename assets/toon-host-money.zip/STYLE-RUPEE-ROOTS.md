## 10. Rupee Roots variant (money explained for India, @rupeerootsin)
Same Toon Host engine and rules (flat fill, wobbly ink outline, host constant), re-skinned in `src/core/lib.js` C palette:
ink `#17211D` · wall mint `#CFE6D6` · floor `#B3CFBB` · paper cream `#FFF4DC` · **host sweater deep green `#0E6B57`** · **GOLD `#F7B733` is THE accent**
(caption keyword, key prop, coins, sneaker panels; dark gold `#D9921A`) · pale gold `#FFE48A` for bursts · green `#43A85A` = right/done · red = wrong/danger.
Money props in `src/core/money.js` (`import * as R`): `R.rupee(x,y,s,rot,flip)`, `R.coinStack(x,y,s,n)`, `R.note(x,y,s,rot,color,val)`, `R.piggy`, `R.bank`,
`R.upiPhone(x,y,s,rot,done)`, `R.sprout(x,y,s,grow)` (channel mascot prop: roots + sprout), `R.growth(x,y,w,h,values,p)`, `R.jar`, `R.calc`.
Badge "RR" (set `"badge":"RR"` in script.json). Style sheet: `style-sheet-rupee-roots.jpg`.
Rules: use the rupee sign (Inter Black has it), Indian examples (UPI, FD, chai, auto fares), numbers in lakh/crore.
Compliance: education only, never name or recommend specific stocks, funds, brokers or coins, no return promises, no buy/sell calls, no live market data.
Keep the "not advice" disclaimer in every description.
Voice: Kokoro `hm_psi` (Hindi-trained male, speaks English with an Indian accent), speed 1.04. Set in script.json.
