// Toon Host engine: canvas, palette, math and drawing primitives.
// Every drawing function in the kit uses the shared `ctx` exported here (set once by main.js).
export const W = 1080, H = 1920, FPS = 30;
export let ctx = null;
export function setCtx(c) { ctx = c; }

// The style sheet palette. Only these (plus the derived shades) appear on screen.
export const C = {
  // world
  bg: '#CFE6D6', bgLight: '#DCEFE2', floor: '#B3CFBB', floorLine: '#9FBDA9', paper: '#FFF4DC', paperLine: '#EBDDB8',
  ink: '#17211D', white: '#FFFFFF',
  // the host
  skin: '#F2B891', skinShade: '#DE9A74', hair: '#A85B2C', hairDark: '#7E411D', hairHi: '#C4743A',
  sweater: '#0E6B57', sweaterHi: '#1C8A72', jeans: '#A8C8E4', jeansShade: '#86AED0', jeansLight: '#C4DCEF',
  shoe: '#F6F4F0', shoeShade: '#DCD7D0',
  mouth: '#5A2323', tongue: '#E0707A',
  // accents: orange is THE accent (sneakers, keyword, key props); yellow = bursts + coins; red = danger; green = good
  orange: '#F7B733', orangeDark: '#D9921A', yellow: '#FFE48A', red: '#D8392B', green: '#43A85A', blue: '#4A7FB5',
  gray: '#4B4B4B', grayLight: '#8C8782',
};

// ---------- math ----------
export const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const seg = (t, a, b) => clamp((t - a) / ((b - a) || 1e-6));
export const eo = (t) => 1 - Math.pow(1 - t, 3);
export const eio = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const eob = (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
export const rnd = (i) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
export const TAU = Math.PI * 2;

// ---------- primitives ----------
export function rr(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); }
export function circle(x, y, r, fill) { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fillStyle = fill; ctx.fill(); }
export function ell(x, y, rx, ry, fill, rot = 0) { ctx.beginPath(); ctx.ellipse(x, y, rx, ry, rot, 0, TAU); ctx.fillStyle = fill; ctx.fill(); }
export function line(pts, color, w) {
  ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.strokeStyle = color; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.stroke();
}
export function fillAll(color) { ctx.fillStyle = color; ctx.fillRect(-300, -300, W + 600, H + 600); }

// ---------- the hand-inked look ----------
// Every character and prop is a FILL plus a thick ink outline (INK px) whose points are nudged by a few px (seeded, so it
// never shimmers between frames): that is the "drawn by hand" wobble.
export const INK = 8;
const jit = (pts, seed, w) => pts.map((p, i) => [p[0] + (rnd(seed * 31 + i * 2) - 0.5) * 2 * w, p[1] + (rnd(seed * 31 + i * 2 + 1) - 0.5) * 2 * w]);
/** closed smooth curve through the midpoints of the polygon (points act as soft corners) */
export function smooth(P) {
  const n = P.length, mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const m0 = mid(P[n - 1], P[0]);
  ctx.beginPath(); ctx.moveTo(m0[0], m0[1]);
  for (let i = 0; i < n; i++) { const m = mid(P[i], P[(i + 1) % n]); ctx.quadraticCurveTo(P[i][0], P[i][1], m[0], m[1]); }
  ctx.closePath();
}
function finish(fill, o) {
  const { lw = INK, stroke = C.ink } = o;
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (lw) { ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke(); }
}
/** soft blob through points, fill + wobbly ink outline. o = { lw, seed, wob, stroke }. Returns the jittered points (for clip) */
export function blob(pts, fill, o = {}) { const P = jit(pts, o.seed ?? 1, o.wob ?? 2); smooth(P); finish(fill, o); return P; }
/** straight-edged polygon (spiky hair, bursts), round joins, same wobble */
export function poly(pts, fill, o = {}) {
  const P = jit(pts, o.seed ?? 1, o.wob ?? 2);
  ctx.beginPath(); ctx.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length; i++) ctx.lineTo(P[i][0], P[i][1]); ctx.closePath();
  finish(fill, o); return P;
}
/** wobbly ellipse, filled + outlined */
export function wEll(cx, cy, rx, ry, fill, o = {}) {
  const n = o.n || 16, rot = o.rot || 0, pts = [];
  for (let i = 0; i < n; i++) { const a = (i / n) * TAU, x = Math.cos(a) * rx * 1.035, y = Math.sin(a) * ry * 1.035; pts.push([cx + x * Math.cos(rot) - y * Math.sin(rot), cy + x * Math.sin(rot) + y * Math.cos(rot)]); }
  return blob(pts, fill, o);
}
/** wobbly rounded rectangle (props, signs), filled + outlined */
export function wRect(x, y, w, h, r, fill, o = {}) {
  r = Math.min(r, w / 2, h / 2); const k = r * 0.55;
  const pts = [[x + r, y], [x + w - r, y], [x + w - k * 0.4, y + k * 0.4], [x + w, y + r], [x + w, y + h - r], [x + w - k * 0.4, y + h - k * 0.4], [x + w - r, y + h], [x + r, y + h], [x + k * 0.4, y + h - k * 0.4], [x, y + h - r], [x, y + r], [x + k * 0.4, y + k * 0.4]];
  return blob(pts, fill, { wob: 1.6, ...o });
}
/** a thick outlined limb / tube along a polyline: ink first, colour on top. lw = outline px on each side (0 = no outline) */
export function inkLine(pts, color, w, lw = INK) {
  if (lw) line(pts, C.ink, w + lw * 2);
  line(pts, color, w);
}

/** outlined bold text (the caption look), centred at x, y */
export function bigText(text, x, y, size, fill = C.white, rot = 0, sc = 1) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(sc, sc);
  ctx.font = `900 ${size}px Inter`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.lineWidth = size * 0.2; ctx.strokeStyle = C.ink; ctx.strokeText(text, 0, 0); ctx.fillStyle = fill; ctx.fillText(text, 0, 0);
  ctx.restore();
}
