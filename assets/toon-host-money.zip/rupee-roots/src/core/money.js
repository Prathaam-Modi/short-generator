// Money props for the Rupee Roots look: same Toon Host rules (flat fill + wobbly ink outline), green + gold palette.
// Every prop is drawn centred at (x, y), scale s, optional rotation; t = film time for the little animations.
import { ctx, C, TAU, wRect, wEll, blob, inkLine, circle, line } from './lib.js';

const RS = (txt, x, y, size, color = C.ink) => { ctx.save(); ctx.font = `900 ${size}px Inter`; ctx.fillStyle = color; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, x, y); ctx.restore(); };

/** gold rupee coin (180 at s = 1). squash 0..1 = turning edge-on (flip) */
export function rupee(x, y, s = 1, rot = 0, flip = 1) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s * Math.max(0.12, Math.abs(flip)), s);
  wEll(0, 0, 90, 90, C.orange, { seed: 301, n: 20 });
  ctx.beginPath(); ctx.arc(0, 0, 66, 0, TAU); ctx.lineWidth = 6; ctx.strokeStyle = C.orangeDark; ctx.stroke();
  RS('₹', 0, 6, 100, C.orangeDark);
  circle(-48, -48, 8, C.yellow);
  ctx.restore();
}

/** stack of n coins (rises as n grows) */
export function coinStack(x, y, s = 1, n = 4) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  for (let i = 0; i < n; i++) { const cy = -i * 30; wEll(0, cy, 90, 30, C.orangeDark, { seed: 311 + i }); wEll(0, cy - 14, 90, 30, C.orange, { seed: 331 + i }); }
  ctx.restore();
}

/** banknote (340 x 180) with a rupee in the middle */
export function note(x, y, s = 1, rot = 0, color = C.green, val = '₹') {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-170, -90, 340, 180, 14, color, { seed: 321 });
  wRect(-148, -68, 296, 136, 8, 'rgba(255,255,255,0.18)', { seed: 322, lw: 4, wob: 1 });
  wEll(0, 0, 52, 52, C.paper, { seed: 323, lw: 6 });
  RS(val, 0, 4, 66, C.ink);
  circle(-122, -44, 10, C.paper); circle(122, 44, 10, C.paper);
  ctx.restore();
}

/** piggy bank (360 x 290); the coin slot on top, ears + curly tail */
export function piggy(x, y, s = 1, rot = 0, bob = 0) {
  ctx.save(); ctx.translate(x, y + bob); ctx.rotate(rot); ctx.scale(s, s);
  for (const lx of [-90, 90]) wRect(lx - 28, 70, 56, 90, 16, '#E58A9A', { seed: 341 + lx });
  inkLine([[-170, -20], [-208, -50], [-190, -84], [-214, -100]], '#F2A3B0', 10, 5);
  wEll(0, -6, 175, 125, '#F2A3B0', { seed: 345, n: 22 });
  blob([[96, -60], [150, -66], [150, -14], [96, -10]], '#E58A9A', { seed: 346 });
  wEll(140, -38, 44, 40, '#E58A9A', { seed: 347 });
  circle(132, -38, 7, C.ink); circle(152, -38, 7, C.ink);
  wEll(70, -62, 12, 12, C.ink, { seed: 348, lw: 0 });
  blob([[40, -110], [66, -170], [96, -112]], '#E58A9A', { seed: 349 });
  wRect(-50, -112, 100, 20, 8, C.ink, { seed: 350, lw: 0 });
  ctx.restore();
}

/** simple bank building (360 x 330): triangle roof, 4 pillars, steps, a rupee on the roof */
export function bank(x, y, s = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-190, 120, 380, 40, 8, C.grayLight, { seed: 361 });
  wRect(-170, 90, 340, 36, 8, C.paper, { seed: 362 });
  for (let i = 0; i < 4; i++) wRect(-130 + i * 86 - 22, -50, 44, 142, 10, C.paper, { seed: 363 + i });
  blob([[-200, -52], [0, -190], [200, -52]], C.orange, { seed: 368, wob: 1.2 });
  wEll(0, -102, 38, 38, C.paper, { seed: 369, lw: 6 });
  RS('₹', 0, -100, 46);
  ctx.restore();
}

/** UPI-style phone: green screen, big tick when done (0..1 = tick drawn). 240 x 440 */
export function upiPhone(x, y, s = 1, rot = 0, done = 1) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-120, -220, 240, 440, 34, C.ink, { seed: 371 });
  wRect(-102, -196, 204, 392, 22, C.paper, { seed: 372, lw: 0 });
  wRect(-102, -196, 204, 120, 22, C.green, { seed: 373, lw: 0 });
  RS('₹ 250', 0, -136, 52, C.white);
  wEll(0, 20, 58, 58, C.green, { seed: 374, lw: 6 });
  if (done > 0) { ctx.beginPath(); ctx.moveTo(-26, 22); ctx.lineTo(-6, 44); ctx.lineTo(30, -2); ctx.lineWidth = 14; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = C.white; ctx.stroke(); }
  wRect(-70, 120, 140, 40, 16, C.orange, { seed: 375, lw: 5, wob: 1 });
  ctx.restore();
}

/** sprout with roots (the channel mascot prop). grow 0..1 */
export function sprout(x, y, s = 1, grow = 1, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  inkLine([[0, 20], [-50, 70], [-90, 60]], '#A9642F', 9, 4); inkLine([[0, 20], [40, 80], [78, 74]], '#A9642F', 9, 4); inkLine([[0, 20], [4, 90]], '#A9642F', 9, 4);
  wEll(0, 10, 100, 34, '#8A5326', { seed: 381 });
  const h = 190 * grow; inkLine([[0, 10], [4, 10 - h * 0.5], [0, 10 - h]], C.green, 18, 6);
  if (grow > 0.4) { const g = Math.min(1, (grow - 0.4) / 0.6); ctx.save(); ctx.translate(0, 10 - h * 0.7); ctx.scale(g, g); blob([[0, 0], [-60, -30], [-110, -10], [-70, 34], [-10, 18]], '#6FD07A', { seed: 382, wob: 1 }); blob([[4, -20], [66, -50], [110, -24], [70, 10], [8, 0]], C.green, { seed: 383, wob: 1 }); ctx.restore(); }
  ctx.restore();
}

/** rising line chart in a board (w x h box centred): values 0..1, p draws it, ends with an arrow dot */
export function growth(x, y, w, h, values, p = 1, color = C.green) {
  ctx.save(); ctx.translate(x - w / 2, y - h / 2);
  wRect(0, 0, w, h, 18, C.paper, { seed: 391 });
  const n = values.length, pts = values.map((v, i) => [30 + (i / (n - 1)) * (w - 60), h - 30 - v * (h - 60)]);
  const upto = p * (n - 1), shown = []; for (let i = 0; i <= Math.floor(upto); i++) shown.push(pts[i]);
  if (Math.floor(upto) < n - 1) { const f = upto - Math.floor(upto), a = pts[Math.floor(upto)], b = pts[Math.floor(upto) + 1]; shown.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]); }
  if (shown.length > 1) inkLine(shown, color, 14, 5);
  const e = shown[shown.length - 1]; circle(e[0], e[1], 16, C.orange);
  ctx.restore();
}

/** jar of coins (200 x 260) */
export function jar(x, y, s = 1, fill = 0.6, rot = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-90, -100, 180, 230, 28, 'rgba(255,255,255,0.45)', { seed: 401 });
  const n = Math.round(fill * 8); for (let i = 0; i < n; i++) wEll(-40 + (i % 3) * 40, 100 - Math.floor(i / 3) * 30, 36, 14, C.orange, { seed: 405 + i, lw: 5, wob: 1 });
  wRect(-100, -134, 200, 40, 12, C.orangeDark, { seed: 402 });
  ctx.restore();
}

/** calculator (220 x 300) */
export function calc(x, y, s = 1, rot = 0, shown = '1,000') {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  wRect(-110, -150, 220, 300, 26, C.gray, { seed: 411 });
  wRect(-86, -126, 172, 66, 10, '#BFE6C8', { seed: 412, lw: 5, wob: 1 });
  RS(shown, 0, -92, 40);
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) wRect(-86 + c * 62, -36 + r * 58, 48, 44, 10, r === 2 && c === 2 ? C.orange : C.grayLight, { seed: 413 + r * 3 + c, lw: 5, wob: 1 });
  ctx.restore();
}
