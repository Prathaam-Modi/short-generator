// The STYLE SHEET for the Rupee Roots variant. Render: QS='&sheet=1' node tools/capture.mjs frames review/sheet "0"
import { ctx, C, W, H, fillAll, rr } from './core/lib.js';
import * as K from './core/kit.js';
import * as R from './core/money.js';

function label(text, x, y, size = 34, color = C.ink, align = 'center') {
  ctx.save(); ctx.font = `900 ${size}px Inter`; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.letterSpacing = '2px'; ctx.fillText(text, x, y); ctx.restore();
}

export function drawSheet() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.letterSpacing = '0px';
  fillAll(C.bg);
  label('RUPEE ROOTS', 540, 96, 108, '#0E6B57');
  label('TOON HOST  ·  GREEN + GOLD  ·  ONE GOLD ACCENT  ·  ₹', 540, 178, 26, C.gray);

  ctx.fillStyle = C.floor; ctx.fillRect(40, 1236, 500, 6);
  K.shadow(290, 1236, 330);
  K.host({ x: 290, y: 780, s: 0.7, arm: K.ARM.cross, mouth: 'smile', eyes: 'n' });
  label('THE HOST', 290, 1290, 30, C.gray);

  const poses = [
    ['CROSSED', { arm: K.ARM.cross, mouth: 'smirk' }],
    ['POINT', { arm: K.ARM.point, mouth: 'grin', eyes: 'wide', brow: 0.6 }],
    ['SHRUG', { arm: K.ARM.shrug, armL: K.ARM.shrug, mouth: 'flat', brow: 0.8, eyes: 'n' }],
    ['THINK', { arm: K.ARM.chin, mouth: 'flat', eyes: 'squint', look: -1, lookY: -1 }],
    ['EXPLAIN', { arm: K.ARM.open, armL: K.ARM.hip, mouth: 'talk', talk: 0.8 }],
    ['WAVE', { arm: K.ARM.wave, mouth: 'grin', eyes: 'happy' }],
  ];
  poses.forEach(([name, o], i) => {
    const cx = 700 + (i % 2) * 280, cy = 500 + Math.floor(i / 2) * 330;
    K.host({ x: cx, y: cy, s: 0.23, ...o });
    label(name, cx, cy + 178, 24, C.gray);
  });

  label('MONEY PROPS', 540, 1395, 30, C.gray);
  R.rupee(110, 1505, 0.62); R.coinStack(250, 1560, 0.6, 4); R.note(420, 1505, 0.5, -0.1); R.piggy(640, 1515, 0.42);
  R.bank(850, 1515, 0.42); R.upiPhone(985, 1505, 0.34, 0.08);

  label('MORE PROPS + MARKS', 540, 1648, 30, C.gray);
  R.sprout(90, 1770, 0.5, 1); R.jar(210, 1770, 0.5, 0.7); R.calc(330, 1770, 0.5);
  R.growth(520, 1760, 200, 130, [0.1, 0.25, 0.2, 0.45, 0.6, 0.85]);
  K.bars(610, 1830, 120, 100, [0.4, 0.7, 0.55, 1], 1, 3);
  K.burst(820, 1770, 0.42, 1); K.mark('?', 820, 1772, 0.34, -0.1, C.orange);
  K.check(920, 1770, 0.22, 1); K.redX(1000, 1770, 0.2, 1);

  const sw = [C.ink, '#0E6B57', C.bg, C.skin, C.hair, C.jeans, C.orange, C.yellow, C.red, C.green];
  sw.forEach((c, i) => { rr(60 + i * 96, 1866, 78, 28, 8); ctx.fillStyle = c; ctx.fill(); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke(); });

  ctx.save(); ctx.translate(540, 232); ctx.font = '900 56px Inter'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.lineWidth = 12; ctx.strokeStyle = C.ink;
  const parts = [['ONE ', C.white], ['GOLD', C.orange], [' WORD', C.white]]; let tw = 0; for (const [t] of parts) tw += ctx.measureText(t).width;
  let x = -tw / 2; ctx.textAlign = 'left';
  for (const [t, c] of parts) { ctx.strokeText(t, x, 0); ctx.fillStyle = c; ctx.fillText(t, x, 0); x += ctx.measureText(t).width; }
  ctx.restore();
}
