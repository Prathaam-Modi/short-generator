// WHY BUYERS WAITED 3 YEARS FOR A MARUTI 800 (Rupee Roots): the shot list.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, wRect, circle } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/money.js';

const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const HOST = { x: 540, y: 738, s: 0.8 };
const CLOSE = { x: 540, y: 1330, s: 1.7 };
const GREEN = '#0E6B57', GREEND = '#0B5A49';

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => (S.push(o), cue(o.at, 'whoosh', { gain: 0.7 }), o);
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const cap = (w, i, st, m = 1.4) => Math.min(Wd(w, i) - st, m);

  { // 1 hook: book now, wait three years
    const st = cut(0), p = cap('years', 0, st, 4.5);
    add({ id: 'S01', at: st, cam: [540, 760], note: 'host, small red car, calendar pages flip, WAIT 3 YEARS',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(380, 1290, 430);
        K.host({ ...HOST, x: 380, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        R.car(800, 1010, 0.8, 0, C.red, lt * 2);
        K.clock(840, 640, 1.1, lt * 3);
        K.sticker('BOOKED IN 1983', 540, 190, 84, C.white, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > p) K.sticker('WAIT ~3 YEARS', 540, 1130, 90, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 2 Harpal Singh lucky draw (cartoon stand-in)
    const st = cut(1), p = cap('lucky', 1, st, 2.6);
    add({ id: 'S02', at: st, cam: [540, 740], note: 'host as stand-in with name sticker, car with burst, LUCKY DRAW',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(380, 1290, 430);
        K.host({ ...HOST, x: 380, y: HOST.y + Math.sin(lt * 2.4) * 4, arm: K.ARM.open, mouth: 'talk', talk: talk(lt) });
        R.car(820, 1000, 0.8, Math.sin(lt * 3) * 0.02, C.white);
        if (lt > p) K.burst(820, 760, 1.0, eob(seg(lt, p, p + 0.3)), C.yellow, lt);
        K.sticker('HARPAL SINGH', 540, 190, 92, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p) K.sticker('LUCKY DRAW WINNER', 540, 1130, 74, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'sparkle', { dur: 0.6 });
  }
  { // 3 licence raj, Ambassador and Padmini
    const st = cut(2), p1 = cap('ambassadors', 2, st, 5), p2 = cap('padmini', 2, st, 8);
    add({ id: 'S03', at: st, cam: [540, 760], note: 'two old-fashioned cars drive in; labels',
      draw(lt, d, t) {
        K.grid(t);
        K.sticker('LICENCE RAJ', 540, 190, 100, C.red, C.white, eob(seg(lt, 0.15, 0.4)), -0.03);
        const a = eo(seg(lt, 0.3, 1.1)), b = eo(seg(lt, p2 - 0.2, p2 + 0.5));
        R.car(lerp(1400, 540, a), 700, 0.85, 0, '#7A8F9E', lt * 3);
        R.car(lerp(-300, 540, b), 1060, 0.85, 0, '#C9A36B', -lt * 3);
        if (lt > p1 - 0.1) K.sticker('AMBASSADOR', 540, 520, 64, C.white, C.ink, eob(seg(lt, p1 - 0.1, p1 + 0.15)), -0.02);
        if (lt > p2 + 0.3) K.sticker('PADMINI', 540, 905, 70, C.white, C.ink, eob(seg(lt, p2 + 0.3, p2 + 0.55)), 0.02);
      } });
    cue(st + 0.2, 'pop'); cue(st + p1, 'pop'); cue(st + p2, 'pop');
  }
  { // 4 Maruti shakes up the market
    const st = cut(3), p = cap('suzuki', 3, st, 3);
    add({ id: 'S04', at: st, cam: [540, 760], note: 'red Maruti zooms in, shock lines, SUZUKI TECH sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(540, 1290, 430);
        const a = eo(seg(lt, 0.1, 0.9));
        R.car(lerp(1400, 540, a), 900, 1.4, 0, C.red, lt * 8);
        K.shockLines(540, 880, 480 * a, eob(seg(lt, 0.8, 1.1)));
        K.sticker('A NEW KIND OF CAR', 540, 190, 74, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('SUZUKI TECHNOLOGY', 540, 1130, 72, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.8, 'slam', { gain: 0.5 });
  }
  { // 5 black market premium
    const st = cut(4), p = cap('forty', 4, st, 4);
    add({ id: 'S05', at: st, cam: [540, 760], note: 'car + coin stack growing, BLACK MARKET, +40% mark',
      draw(lt, d, t) {
        K.dark(t);
        R.car(300, 900, 0.8, 0, C.white);
        R.coinStack(790, 1030, 1.1, 3 + Math.floor(seg(lt, 0.4, p + 0.4) * 5));
        K.sticker('BLACK MARKET', 540, 190, 100, C.red, C.white, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p) K.sticker('PREMIUM UP TO 40%', 540, 1130, 78, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 6 best-selling until 2004
    const st = cut(5), p = cap('thousand', 5, st, 3);
    add({ id: 'S06', at: st, cam: [540, 740], note: 'crown on car, BEST-SELLING sticker, UNTIL 2004',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(540, 1290, 430);
        R.car(540, 980, 1.3, 0, C.red, lt * 2);
        K.crown(540, 690 + Math.sin(lt * 4) * 8, 1.3);
        K.sticker('INDIA\'S #1 CAR', 540, 190, 90, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p) K.sticker('UNTIL 2004', 540, 1130, 96, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'sparkle', { dur: 0.6 });
  }
  { // 7 nearly thirty lakh, last one 2014
    const st = cut(6), p = cap('thirty', 6, st, 1.2), p2 = cap('january', 6, st, 4.5);
    add({ id: 'S07', at: st, cam: [540, 760], note: 'rows of small cars filling, ~30 LAKH, LAST: JAN 2014',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        const n = Math.floor(30 * eo(seg(lt, 0.1, Math.max(p2, 2.5))));
        const cols = ['#D8392B', '#FFFFFF', '#4A7FB5'];
        for (let i = 0; i < n; i++) { const x = 170 + (i % 5) * 185, y = 380 + Math.floor(i / 5) * 120; R.car(x, y, 0.28, 0, cols[i % 3]); }
        K.sticker('NEARLY 30 LAKH MADE', 540, 190, 78, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p2) K.sticker('LAST ONE: JAN 2014', 540, 1130, 78, C.white, C.ink, eob(seg(lt, p2, p2 + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p2, 'thud');
  }
  { // 8 lesson: demand high, supply short
    const st = cut(7), p = cap('skip', 7, st, 8);
    add({ id: 'S08', at: st, cam: [540, 740], note: 'host, one car, queue of coins; lesson stickers',
      draw(lt, d, t) {
        K.grid(t);
        K.host({ ...HOST, x: 340, arm: K.ARM.open, mouth: 'talk', talk: talk(lt) });
        R.car(830, 1010, 0.7, 0, C.red);
        const n = Math.floor(5 * eo(seg(lt, 0.4, 3)));
        for (let i = 0; i < n; i++) R.rupee(660 + i * 70, 720, 0.3, 0, 1);
        K.sticker('HUGE DEMAND, SHORT SUPPLY', 540, 190, 62, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('PAY EXTRA TO SKIP', 540, 1130, 80, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 9 subscribe
    const st = cut(8);
    add({ id: 'S09', at: st, cam: [540, 640], zoom: 0.14, note: 'close-up smile, subscribe sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        K.host({ ...CLOSE, arm: K.ARM.cross, mouth: 'smile', eyes: 'happy' });
        K.sticker('SUBSCRIBE', 540, 190, 110, C.orange, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
      } });
    cue(st + 0.2, 'pop');
  }
  return { shots: S, cues: CUES };
}
