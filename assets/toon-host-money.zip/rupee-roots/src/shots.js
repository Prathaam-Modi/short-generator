// HOW AMUL BEAT A MONOPOLY (Rupee Roots): the shot list.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, wRect, circle } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/money.js';

const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const HOST = { x: 540, y: 738, s: 0.8 };
const CLOSE = { x: 540, y: 1330, s: 1.7 };
const GREEN = '#0E6B57', GREEND = '#0B5A49';

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => (S.push(o), cue(o.at, 'whoosh', { gain: 0.7 }), o);
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const wcut = (word, i) => Wd(word, i) - 0.08;
  const cap = (w, i, st, m = 1.4) => Math.min(Wd(w, i) - st, m);

  { // 1 hook: farmer-sized jar, 1-2 litres
    const st = cut(0), p = cap('litres', 0, st, 2.2);
    add({ id: 'S01', at: st, cam: [540, 760], note: 'host + near-empty jar, AMUL + 1-2 LITRES stickers',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(400, 1290, 430);
        K.host({ ...HOST, x: 390, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        R.jar(830, 960, 1.1, 0.15 + 0.1 * seg(lt, 0.3, p));
        K.sticker('AMUL', 540, 190, 110, C.orange, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > p) K.sticker('1-2 LITRES EACH', 540, 1130, 80, C.white, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'pop');
  }
  { // 2 monopoly sets the price
    const st = cut(1), p = cap('price', 1, st, 3);
    add({ id: 'S02', at: st, cam: [540, 700], note: 'one big company grabs coins, sets the price',
      draw(lt, d, t) {
        K.dark(t);
        R.bank(540, 760, 1.3, Math.sin(lt * 2) * 0.02);
        R.coinStack(180, 1130, 0.9, 3 + Math.floor(seg(lt, 0.4, p) * 5));
        K.sticker('ONE COMPANY', 540, 190, 100, C.red, C.white, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p) K.sticker('SETS THE PRICE', 540, 1130, 80, C.yellow, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 3 ask Sardar Patel
    const st = cut(2);
    add({ id: 'S03', at: st, cam: [540, 740], note: 'host pointing, Tribhuvandas Patel sticker',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(540, 1290, 430);
        K.host({ ...HOST, y: HOST.y + Math.sin(lt * 2.4) * 4, arm: K.ARM.point, mouth: 'talk', talk: talk(lt) });
        K.mark('?', 860, 560 + Math.sin(lt * 3) * 12, eob(seg(lt, 0.2, 0.5)), 0.15, C.orange);
        K.sticker('TRIBHUVANDAS PATEL', 540, 190, 74, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('ASKS FOR ADVICE', 540, 1130, 76, C.white, C.ink, eob(seg(lt, 0.7, 0.95)), 0.03);
      } });
    cue(st + 0.2, 'pop');
  }
  { // 4 form a cooperative: sprout grows
    const st = cut(3), p = cap('cooperative', 3, st, 3);
    add({ id: 'S04', at: st, cam: [540, 760], note: 'sprout grows, FORM A COOPERATIVE sticker, check',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(540, 1290, 430);
        R.sprout(540, 1000, 1.7, eo(seg(lt, 0.3, p + 0.6)));
        K.sticker('STOP SELLING ALONE', 540, 190, 76, C.red, C.white, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > p) { K.sticker('FORM A CO-OP', 540, 1130, 84, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03); K.check(840, 520, 0.5, eob(seg(lt, p + 0.2, p + 0.45))); }
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'sparkle', { dur: 0.6 });
  }
  { // 5 date
    const st = cut(4), p = cap('december', 4, st, 1.4);
    add({ id: 'S05', at: st, cam: [540, 760], note: 'cream paper, date sticker, bank-like building',
      draw(lt, d, t) {
        K.grid(t);
        R.bank(540, 780, 1.4);
        K.sticker('DEC 1946', 540, 190, 120, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('ANAND, GUJARAT', 540, 1130, 78, C.yellow, C.ink, eob(seg(lt, 0.5, 0.75)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.5, 'thud', { gain: 0.5 });
  }
  { // 6 buffalo milk powder "impossible"
    const st = cut(5), p = cap('impossible', 5, st, 5);
    add({ id: 'S06', at: st, cam: [540, 720], note: 'host, milk powder jar, IMPOSSIBLE red X then tick',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(400, 1290, 430);
        K.host({ ...HOST, x: 380, arm: K.ARM.open, armL: K.ARM.hip, mouth: 'talk', talk: talk(lt) });
        R.jar(840, 960, 1.1, 0.8);
        K.sticker('BUFFALO MILK POWDER', 540, 190, 66, C.white, C.ink, eob(seg(lt, 0.3, 0.55)), -0.03);
        if (lt > p) { K.redX(840, 640, 0.9, eob(seg(lt, p, p + 0.2))); K.sticker('"IMPOSSIBLE"', 540, 1130, 84, C.red, C.white, eob(seg(lt, p, p + 0.25)), 0.03); }
      } });
    cue(st + 0.3, 'pop'); cue(st + p, 'slam', { gain: 0.5 });
  }
  { // 7 3.6 million farmers
    const st = cut(6), p = cap('three', 6, st, 1.0);
    add({ id: 'S07', at: st, cam: [540, 760], note: 'many farmers as dots, 3.6 MILLION sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        const n = Math.floor(48 * eo(seg(lt, 0.1, 1.8)));
        for (let i = 0; i < n; i++) { const x = 130 + (i % 8) * 117, y = 420 + Math.floor(i / 8) * 130; K.host({ x, y: y + 120, s: 0.13, mouth: 'smile' }); }
        K.sticker('3.6 MILLION', 540, 190, 120, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('FARMERS', 540, 1130, 84, C.white, C.ink, eob(seg(lt, 0.6, 0.85)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.6, 'pop');
  }
  { // 8 turnover
    const st = cut(7), p = cap('ninety', 7, st, 2.6);
    add({ id: 'S08', at: st, cam: [540, 760], note: 'growth chart + big coin stack, 90,000 CRORE sticker',
      draw(lt, d, t) {
        K.grid(t);
        R.growth(540, 560, 800, 460, [0.05, 0.1, 0.18, 0.3, 0.5, 0.75, 1], eo(seg(lt, 0.2, p + 0.4)));
        R.coinStack(540, 1100, 1.1, 6);
        K.sticker('FY 2025', 540, 190, 100, C.white, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > p) K.sticker('~₹90,000 CRORE', 540, 1130, 84, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'sparkle', { dur: 0.6 });
  }
  { // 9 lesson close-up
    const st = cut(8);
    add({ id: 'S09', at: st, cam: [540, 640], zoom: 0.14, note: 'close-up smile, lesson sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        K.host({ ...CLOSE, arm: K.ARM.cross, mouth: 'smile', eyes: 'happy' });
        K.sticker('SMALL + TOGETHER = BIG', 540, 190, 62, C.orange, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
      } });
    cue(st + 0.2, 'pop');
  }
  return { shots: S, cues: CUES };
}
