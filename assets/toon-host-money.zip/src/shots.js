// HE PLANNED A STEEL CITY BUT NEVER SAW IT (Rupee Roots): the shot list.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, wRect, wEll, circle, inkLine } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/money.js';

const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const HOST = { x: 540, y: 738, s: 0.8 };
const CLOSE = { x: 540, y: 1330, s: 1.7 };
const GREEN = '#0E6B57', GREEND = '#0B5A49';

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => (S.push(o), cue(o.at, 'whoosh', { gain: 0.7 }), o);
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const cap = (w, i, st, m = 1.4) => Math.min(Wd(w, i) - st, m);
  const txt = (s, x, y, size, color = C.ink) => { ctx.save(); ctx.font = `900 ${size}px Inter`; ctx.fillStyle = color; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y); ctx.restore(); };

  { // 1 hook: stand-in planner with a blueprint
    const st = cut(0), p = cap('twenty', 0, st, 4);
    add({ id: 'S01', at: st, cam: [540, 760], note: 'stand-in host with scroll, name sticker, 20+ YEARS',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(380, 1290, 430);
        K.host({ ...HOST, x: 380, arm: K.ARM.hold, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        R.scroll(560, 640, 1.0, -0.5);
        ctx.save(); ctx.globalAlpha = 0.9 * eo(seg(lt, 0.8, 2.0));
        R.steelWorks(830, 960, 0.8, 0, 0); ctx.restore();
        K.sticker('JAMSETJI TATA', 540, 190, 88, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('20+ YEARS', 540, 1040, 100, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 2 Manchester lecture
    const st = cut(1), p = cap('gold', 1, st, 5);
    add({ id: 'S02', at: st, cam: [540, 760], note: 'host lectures, bubble, gold ingot lands on GOLD',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(340, 1290, 430);
        K.host({ ...HOST, x: 340, arm: K.ARM.point, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        K.bubble('THE COUNTRY THAT\nMAKES *STEEL\nHAS THE GOLD', 730, 520, 500, 330, 520, 640, 44, eob(seg(lt, 0.9, 1.2)));
        R.ingot(790, 1000 + (1 - eob(seg(lt, p, p + 0.3))) * -120, 0.9, 0.05, 1);
        K.sticker('MANCHESTER LECTURE', 540, 190, 70, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 3 1904
    const st = cut(2), p = cap('four', 2, st, 1.5);
    add({ id: 'S03', at: st, cam: [540, 760], note: 'host sad, scroll drooping, 1904',
      draw(lt, d, t) {
        K.wall('#5A6B64', '#4A5A54', t); K.shadow(380, 1290, 430);
        K.host({ ...HOST, x: 380, mouth: 'talk', talk: talk(lt), brow: -0.4 });
        R.scroll(780, 1060, 1.1, 0.35);
        K.sticker('HE DIED', 540, 190, 100, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('1904', 540, 1040, 130, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 4 1907 registration
    const st = cut(3), pa = cap('seven', 3, st, 2), pb = cap('registered', 3, st, 3), pc = cap('sakchi', 3, st, 5);
    add({ id: 'S04', at: st, cam: [540, 760], note: 'document, REGISTERED stamp, 1907, SAKCHI tag',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        const dy = 760;
        wRect(280, dy - 330, 520, 620, 24, C.paper, { seed: 801 });
        for (let i = 0; i < 6; i++) inkLine([[340, dy - 240 + i * 62], [740 - (i % 3) * 60, dy - 240 + i * 62]], C.paperLine, 12, 0);
        R.steelWorks(540, dy + 130, 0.45, t, 0);
        const sc = eob(seg(lt, pb, pb + 0.25));
        if (sc > 0) { ctx.save(); ctx.translate(560, dy - 60); ctx.rotate(-0.25); ctx.scale(sc, sc);
          wRect(-210, -60, 420, 120, 16, C.green, { seed: 802, lw: 10 }); txt('REGISTERED', 0, 4, 64, C.white); ctx.restore(); }
        K.sticker('1907', 540, 190, 120, C.white, C.ink, eob(seg(lt, pa, pa + 0.25)), -0.03);
        if (lt > pc) K.sticker('SAKCHI', 540, 1100, 100, C.orange, C.ink, eob(seg(lt, pc, pc + 0.25)), 0.03);
      } });
    cue(st + pa, 'pop'); cue(st + pb, 'thud'); cue(st + pc, 'sparkle', { dur: 0.5 });
  }
  { // 5 map: coal N, ore S, Kolkata E
    const st = cut(4), pa = cap('coal', 4, st, 3), pb = cap('iron', 4, st, 4), pc = cap('kolkata', 4, st, 5);
    add({ id: 'S05', at: st, cam: [540, 760], note: 'Sakchi centre, coal north, ore south, Kolkata port east',
      draw(lt, d, t) {
        K.grid(t);
        R.steelWorks(500, 700, 0.5, t, 0.8);
        K.sticker('SAKCHI', 500, 850, 52, C.white, C.ink, 1, 0);
        const a = eo(seg(lt, pa, pa + 0.5)), b = eo(seg(lt, pb, pb + 0.5)), c = eo(seg(lt, pc, pc + 0.5));
        if (a > 0) { K.arrow(500, 500, 100 * a, -Math.PI / 2, a); R.heap(500, 340, 1.2 * a, '#3A4A44'); }
        if (b > 0) { K.arrow(500, 930, 100 * b, Math.PI / 2, b); R.heap(500, 1060, 1.3 * b, '#B5603A'); }
        if (c > 0) { K.arrow(690, 700, 100 * c, 0, c); R.tanker(880, 720, 0.36 * c, 0, Math.sin(lt * 3) * 6); }
        K.sticker('COAL: NORTH', 500, 190, 72, C.white, C.ink, eob(seg(lt, pa, pa + 0.25)), -0.03);
        if (lt > pb) K.sticker('IRON ORE: SOUTH', 500, 1170, 52, C.white, C.ink, eob(seg(lt, pb, pb + 0.25)), 0.03);
        if (lt > pc) K.sticker('KOLKATA PORT', 810, 590, 50, C.orange, C.ink, eob(seg(lt, pc, pc + 0.25)), -0.02);
      } });
    cue(st + pa, 'pop'); cue(st + pb, 'pop'); cue(st + pc, 'thud');
  }
  { // 6 1912 first steel
    const st = cut(5), pa = cap('twelve', 5, st, 3), pb = cap('eight', 5, st, 4);
    add({ id: 'S06', at: st, cam: [540, 760], note: 'steel works smoking, hot ingot slides out, 1912, 8 YEARS',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        R.steelWorks(330, 790, 0.85, t, 1);
        const a = eo(seg(lt, pa - 0.2, pa + 1.0));
        R.ingot(lerp(520, 800, a), 900, 0.9, 0, 1);
        K.sticker('FIRST STEEL', 540, 190, 96, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('1912', 540, 1060, 120, C.orange, C.ink, eob(seg(lt, pa, pa + 0.25)), 0.03);
        if (lt > pb) K.sticker('8 YEARS LATER', 540, 1175, 56, C.white, C.ink, eob(seg(lt, pb, pb + 0.25)), -0.02);
      } });
    cue(st + 0.2, 'pop'); cue(st + pa, 'thud'); cue(st + pb, 'pop');
  }
  { // 7 1919 renamed Jamshedpur
    const st = cut(6), pa = cap('nineteen', 6, st, 2), pb = cap('renamed', 6, st, 3), pc = cap('jamshedpur', 6, st, 4);
    add({ id: 'S07', at: st, cam: [540, 760], note: 'signpost: SAKCHI crossed out, JAMSHEDPUR',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t);
        R.signpost(540, 880, 1.0, 0);
        const bx = 540, by = 710;
        const n = eo(seg(lt, pc, pc + 0.3));
        txt('SAKCHI', bx, by, 90, C.ink);
        if (lt > pb) { ctx.save(); ctx.globalAlpha = eo(seg(lt, pb, pb + 0.2)); inkLine([[bx - 190, by + 4], [bx + 190, by + 4]], C.red, 10, 0); ctx.restore(); }
        if (lt > pc) { ctx.save(); ctx.translate(540, 1010); ctx.rotate(-0.03); ctx.scale(eob(seg(lt, pc, pc + 0.25)), eob(seg(lt, pc, pc + 0.25)));
          wRect(-300, -70, 600, 140, 20, C.orange, { seed: 811 }); txt('JAMSHEDPUR', 0, 4, 80, C.ink); ctx.restore(); }
        K.sticker('1919', 540, 190, 120, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + pb, 'pop'); cue(st + pc, 'thud');
  }
  { // 8 lesson: slow sprout
    const st = cut(7), p = cap('never', 7, st, 5), pe = cap('finished', 7, st, 6);
    add({ id: 'S08', at: st, cam: [540, 740], note: 'host explains, sprout grows slowly, lesson stickers',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(340, 1290, 430);
        K.host({ ...HOST, x: 340, arm: K.ARM.open, mouth: 'talk', talk: talk(lt) });
        R.sprout(820, 960, 1.3, eo(seg(lt, 0.5, pe + 0.5)));
        K.sticker('THE LESSON', 540, 190, 100, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('PLANS TAKE YEARS', 540, 1040, 76, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 9 share CTA
    const st = cut(8), p = cap('jamshedpur', 8, st, 1.5);
    add({ id: 'S09', at: st, cam: [540, 740], note: 'host asks, bubble SEND IT TO A FRIEND',
      draw(lt, d, t) {
        K.grid(t);
        K.host({ ...HOST, x: 360, arm: K.ARM.open, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        K.bubble('SEND IT TO\nA *FRIEND', 760, 760, 380, 300, 560, 840, 64, eob(seg(lt, 0.3, 0.6)));
        K.sticker('SHARE THIS', 540, 190, 100, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.35, 'sparkle', { dur: 0.5 });
  }
  { // 10 subscribe
    const st = cut(9);
    add({ id: 'S10', at: st, cam: [540, 640], zoom: 0.14, note: 'close-up smile, subscribe sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        K.host({ ...CLOSE, arm: K.ARM.cross, mouth: 'smile', eyes: 'happy' });
        K.sticker('SUBSCRIBE', 540, 190, 110, C.orange, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
      } });
    cue(st + 0.2, 'pop');
  }
  return { shots: S, cues: CUES };
}
