// INFOSYS BEGAN WITH RS 10,000 (Rupee Roots): the shot list.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, wRect, circle } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/money.js';

const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const HOST = { x: 540, y: 738, s: 0.8 };
const CLOSE = { x: 540, y: 1330, s: 1.7 };
const GREEN = '#0E6B57', GREEND = '#0B5A49';

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => (S.push(o), cue(o.at, 'whoosh', { gain: 0.7 }), o);
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const wcut = (word, i) => Wd(word, i) - 0.08;
  const cap = (w, i, st, m = 1.4) => Math.min(Wd(w, i) - st, m);

  { // 1a hook: host, INFOSYS sticker
    const st = cut(0), p = cap('eighty-one', 0, st, 3.2);
    add({ id: 'S01', at: st, cam: [540, 760], note: 'host hook, INFOSYS sticker, ? mark',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(540, 1290, 430);
        K.host({ ...HOST, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        K.sticker('INFOSYS', 540, 190, 120, C.orange, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        K.mark('?', 860, 560 + Math.sin(lt * 3) * 12, eob(seg(lt, 0.4, 0.7)), 0.15, C.yellow);
        if (lt > p) K.sticker('1981', 540, 1130, 100, C.white, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'pop');
  }
  { // 1b ten thousand rupees
    const st = wcut('ten', 0), p = cap('ten', 0, st, 1.0);
    add({ id: 'S02', at: st, cam: [540, 760], note: 'few notes + coins, 10,000 sticker',
      draw(lt, d, t) {
        K.grid(t);
        R.note(540, 700, 1.6, -0.06, C.green, '₹');
        R.coinStack(250, 1080, 0.9, 3);
        R.coinStack(830, 1080, 0.9, 3);
        K.sticker('JUST', 540, 190, 90, C.white, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        K.sticker('₹10,000', 540, 1130, 120, C.orange, C.ink, eob(seg(lt, 0.3, 0.55)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.4, 'sparkle', { dur: 0.5 });
  }
  { // 2 savings handed to husband
    const st = cut(1), p = cap('savings', 1, st, 2);
    add({ id: 'S03', at: st, cam: [540, 740], note: 'piggy bank, note handed over, SUDHA MURTY stand-in sticker',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(540, 1290, 430);
        R.piggy(540, 760, 1.5, 0, Math.sin(lt * 3) * 6);
        const f = eo(seg(lt, p, p + 1.0));
        R.note(lerp(380, 740, f), lerp(420, 520, f), 1.0, lerp(-0.2, 0.15, f), C.green, '₹');
        K.sticker('HER SAVINGS', 540, 190, 96, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('SUDHA MURTY', 540, 1130, 80, C.white, C.ink, eob(seg(lt, 0.6, 0.85)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'slide', { dur: 0.6 });
  }
  { // 3 seven engineers, house in Pune
    const st = cut(2), p = cap('house', 2, st, 3);
    add({ id: 'S04', at: st, cam: [540, 760], note: 'seven mini hosts line up, house appears on HOUSE, PUNE sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        const n = Math.floor(7 * eo(seg(lt, 0.1, 1.6)) + 0.001);
        for (let i = 0; i < n; i++) K.host({ x: 130 + i * 136, y: 930, s: 0.2, mouth: 'smile' });
        if (lt > p - 0.4) R.house(540, 790, 1.1 * eob(seg(lt, p - 0.4, p)), 0);
        K.sticker('7 ENGINEERS', 540, 190, 100, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p) K.sticker('PUNE, 1981', 540, 1130, 90, C.white, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud', { gain: 0.5 });
  }
  { // 4 moved to Bangalore 1983
    const st = cut(3), p = cap('bangalore', 3, st, 3);
    add({ id: 'S05', at: st, cam: [540, 760], note: 'house slides, 1983 sticker, MOVED TO BANGALORE',
      draw(lt, d, t) {
        K.grid(t);
        const f = eio(seg(lt, 0.4, 2.0));
        R.house(lerp(300, 780, f), 900, 1.0, 0);
        K.arrow(540, 520, 300, 0, eo(seg(lt, 0.3, 0.8)), C.orange);
        K.sticker('1983', 540, 190, 130, C.orange, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > p) K.sticker('MOVED TO BANGALORE', 540, 1130, 70, C.yellow, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.5, 'slide', { dur: 1.2 });
  }
  { // 5a FY2026 revenue
    const st = cut(4), p = cap('seventy-eight', 4, st, 6);
    add({ id: 'S06', at: st, cam: [540, 760], note: 'growth chart + coin stack, FY 2026 and ~1.78 LAKH CRORE sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        R.growth(540, 560, 800, 460, [0.04, 0.08, 0.15, 0.28, 0.5, 0.75, 1], eo(seg(lt, 0.3, p + 0.5)));
        R.coinStack(540, 960, 1.0, 6);
        K.sticker('FY 2026', 540, 190, 110, C.white, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
        if (lt > p) K.sticker('~₹1.78 LAKH CRORE', 540, 1130, 72, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'sparkle', { dur: 0.6 });
  }
  { // 5b employees
    const st = cut(5);
    add({ id: 'S07', at: st, cam: [540, 760], note: 'rows of mini hosts, OVER 3 LAKH EMPLOYEES',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t);
        const n = Math.floor(40 * eo(seg(lt, 0.1, 1.6)));
        for (let i = 0; i < n; i++) { const x = 130 + (i % 8) * 117, y = 360 + Math.floor(i / 8) * 130; K.host({ x, y: y + 120, s: 0.13, mouth: 'smile' }); }
        K.sticker('3 LAKH+', 540, 190, 120, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('EMPLOYEES', 540, 1130, 90, C.white, C.ink, eob(seg(lt, 0.6, 0.85)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.6, 'pop');
  }
  { // 6 lesson
    const st = cut(6), p = cap('small', 6, st, 6);
    add({ id: 'S08', at: st, cam: [540, 640], zoom: 0.12, note: 'close-up host, lesson sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        K.host({ ...CLOSE, arm: K.ARM.cross, mouth: 'talk', talk: talk(lt), eyes: 'happy' });
        K.sticker('SMALL START, BIG GROWTH', 540, 190, 60, C.orange, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
      } });
    cue(st + 0.2, 'pop');
  }
  { // 7 comment CTA
    const st = cut(7), p = cap('story', 7, st, 2.5);
    add({ id: 'S09', at: st, cam: [540, 740], note: 'host points at COMMENT bubble',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(540, 1290, 430);
        K.host({ ...HOST, x: 360, arm: K.ARM.point, mouth: 'talk', talk: talk(lt) });
        K.bubble('Which *story next?', 810, 470, 420, 130, 620, 540, 32, eob(seg(lt, 0.3, 0.6)));
        K.sticker('COMMENT BELOW', 540, 190, 84, C.white, C.ink, eob(seg(lt, 0.1, 0.35)), -0.03);
      } });
    cue(st + 0.3, 'pop');
  }
  { // 8 subscribe
    const st = cut(8);
    add({ id: 'S10', at: st, cam: [540, 760], note: 'host waves, sprout, SUBSCRIBE sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(400, 1290, 430);
        K.host({ ...HOST, x: 400, arm: K.ARM.wave, mouth: 'smile', eyes: 'happy' });
        R.sprout(830, 1000, 1.3, eo(seg(lt, 0.3, 2.0)));
        K.sticker('SUBSCRIBE', 540, 190, 120, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        K.sticker('RUPEE ROOTS', 540, 1130, 84, C.white, C.ink, eob(seg(lt, 0.5, 0.75)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.6, 'sparkle', { dur: 0.6 });
  }
  return { shots: S, cues: CUES };
}
