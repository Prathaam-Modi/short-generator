// WHY INDIA BUYS ALMOST ALL ITS OIL FROM ABROAD (Rupee Roots): the shot list.
import { ctx, C, W, H, TAU, clamp, lerp, seg, eo, eio, eob, rnd, wRect, circle } from './core/lib.js';
import { L, Le, Wd, T } from './core/timing.js';
import * as K from './core/kit.js';
import * as R from './core/money.js';

const talk = (lt) => 0.45 + 0.5 * Math.abs(Math.sin(lt * 13));
const HOST = { x: 540, y: 738, s: 0.8 };
const CLOSE = { x: 540, y: 1330, s: 1.7 };
const GREEN = '#0E6B57', GREEND = '#0B5A49';

export function buildShots() {
  const S = [], CUES = [];
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const add = (o) => (S.push(o), cue(o.at, 'whoosh', { gain: 0.7 }), o);
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const cap = (w, i, st, m = 1.4) => Math.min(Wd(w, i) - st, m);

  { // 1 hook: 87 crore litres a day
    const st = cut(0), p = cap('every', 0, st, 5);
    add({ id: 'S01', at: st, cam: [540, 760], note: 'host, derrick, barrels fill up, 87 CRORE LITRES',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(380, 1290, 430);
        K.host({ ...HOST, x: 380, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        R.derrick(830, 900, 1.0, lt * 3);
        const n = Math.floor(1 + 4 * eo(seg(lt, 0.3, 3.5)));
        for (let i = 0; i < n; i++) R.barrel(640 + i * 80, 1150, 0.6, 0);
        K.sticker('87 CRORE LITRES', 540, 190, 92, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('EVERY SINGLE DAY', 540, 1040, 84, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 2 twist: 88 of 100 imported (dot grid)
    const st = cut(1), p0 = cap('twist', 1, st, 3), p = cap('eighty', 1, st, 3);
    add({ id: 'S02', at: st, cam: [540, 740], note: '100 dots: 88 gold imported, 12 white home-made',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t);
        const k = Math.floor(100 * eo(seg(lt, p, p + 1.9)));
        for (let i = 0; i < 100; i++) {
          const x = 195 + (i % 10) * 77.5, y = 400 + Math.floor(i / 10) * 77.5, on = lt > p;
          const imp = i < 88, shown = i < k;
          circle(x, y, 30, shown && imp ? C.orange : C.paper);
          ctx.beginPath(); ctx.arc(x, y, 30, 0, TAU); ctx.lineWidth = 5; ctx.strokeStyle = C.ink; ctx.stroke();
          if (!on) continue;
        }
        K.sticker('HERE IS THE TWIST', 540, 190, 84, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p + 0.5) K.sticker('88 OF 100 IMPORTED', 540, 1040, 76, C.orange, C.ink, eob(seg(lt, p + 0.5, p + 0.75)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p0, 'thud'); cue(st + p + 0.5, 'sparkle', { dur: 0.6 });
  }
  { // 3 import bill
    const st = cut(2), p = cap('thirty', 2, st, 5.5);
    add({ id: 'S03', at: st, cam: [540, 760], note: 'tanker sails in over waves, coins, 137 BILLION DOLLARS',
      draw(lt, d, t) {
        K.wall('#2E6F9E', '#245A82', t); 
        const a = eo(seg(lt, 0.1, 1.6));
        R.tanker(lerp(-500, 500, a), 780, 1.6, 0, Math.sin(lt * 3) * 8);
        R.coinStack(850, 980, 1.0, 3 + Math.floor(seg(lt, 0.8, p + 0.5) * 5));
        K.sticker('2024-25 OIL BILL', 540, 190, 88, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('$137 BILLION', 540, 1040, 100, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 4 wells slowing
    const st = cut(3), p = cap('slowing', 3, st, 2);
    add({ id: 'S04', at: st, cam: [540, 760], note: 'host sad, derrick nods slower',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t); K.shadow(380, 1290, 430);
        K.host({ ...HOST, x: 340, mouth: 'talk', talk: talk(lt), brow: -0.3 });
        R.derrick(800, 900, 1.1, lt * 3 * (1 - 0.7 * seg(lt, 0.5, 2)));
        K.sticker('OUR OWN WELLS', 540, 190, 90, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > p) K.sticker('SLOWING DOWN', 540, 1040, 90, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 5 output bars 37 -> 29 million tonnes
    const st = cut(4), pa = cap('thirty', 4, st, 2), pb = cap('under', 4, st, 6);
    add({ id: 'S05', at: st, cam: [540, 760], note: 'two bars 37.46 vs 28.70 million tonnes, year stickers',
      draw(lt, d, t) {
        K.grid(t);
        const base = 1010, ha = 500 * eo(seg(lt, pa - 0.3, pa + 0.7)), hb = 383 * eo(seg(lt, pb - 0.3, pb + 0.7));
        wRect(260, base - ha, 230, ha, 14, C.orangeDark, { seed: 501 });
        wRect(590, base - hb, 230, hb, 14, C.orange, { seed: 502 });
        K.sticker('OIL OUTPUT', 540, 190, 90, C.white, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
        if (lt > pa) { K.sticker('37 MILLION', 375, base - ha - 70, 52, C.white, C.ink, eob(seg(lt, pa, pa + 0.25)), -0.03); K.sticker('2014-15', 375, base + 60, 56, C.white, C.ink, eob(seg(lt, pa, pa + 0.25)), 0.02); }
        if (lt > pb) { K.sticker('29 MILLION', 705, base - hb - 70, 52, C.white, C.ink, eob(seg(lt, pb, pb + 0.25)), 0.03); K.sticker('2024-25', 705, base + 60, 56, C.white, C.ink, eob(seg(lt, pb, pb + 0.25)), -0.02); }
      } });
    cue(st + 0.2, 'pop'); cue(st + pa, 'pop'); cue(st + pb, 'thud');
  }
  { // 6 lesson
    const st = cut(5), p = cap('yours', 5, st, 7);
    add({ id: 'S06', at: st, cam: [540, 740], note: 'host, barrel across a gap, lesson stickers',
      draw(lt, d, t) {
        K.wall(C.blue, '#3D6C9E', t); K.shadow(340, 1290, 430);
        K.host({ ...HOST, x: 340, arm: K.ARM.open, mouth: 'talk', talk: talk(lt) });
        R.barrel(830, 960, 1.1, Math.sin(lt * 2) * 0.03);
        R.rupee(830, 700, 0.5, 0, Math.cos(lt * 4));
        K.sticker('MOSTLY BOUGHT ABROAD', 540, 190, 66, C.white, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
        if (lt > p) K.sticker('PRICE NOT YOURS', 540, 1040, 84, C.orange, C.ink, eob(seg(lt, p, p + 0.25)), 0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + p, 'thud');
  }
  { // 7 comment CTA
    const st = cut(6), p = cap('fuel', 6, st, 1.5);
    add({ id: 'S07', at: st, cam: [540, 740], note: 'host asks, bubble PETROL? DIESEL? GAS?',
      draw(lt, d, t) {
        K.grid(t);
        K.host({ ...HOST, x: 360, arm: K.ARM.open, mouth: 'talk', talk: talk(lt), brow: 0.3 });
        K.bubble('PETROL?\nDIESEL?\n*GAS?', 760, 760, 380, 360, 560, 840, 64, eob(seg(lt, 0.3, 0.6)));
        K.sticker('COMMENT BELOW', 540, 190, 100, C.orange, C.ink, eob(seg(lt, 0.15, 0.4)), -0.03);
      } });
    cue(st + 0.2, 'pop'); cue(st + 0.35, 'sparkle', { dur: 0.5 });
  }
  { // 8 subscribe
    const st = cut(7);
    add({ id: 'S08', at: st, cam: [540, 640], zoom: 0.14, note: 'close-up smile, subscribe sticker',
      draw(lt, d, t) {
        K.wall(GREEN, GREEND, t);
        K.host({ ...CLOSE, arm: K.ARM.cross, mouth: 'smile', eyes: 'happy' });
        K.sticker('SUBSCRIBE', 540, 190, 110, C.orange, C.ink, eob(seg(lt, 0.2, 0.45)), -0.03);
      } });
    cue(st + 0.2, 'pop');
  }
  return { shots: S, cues: CUES };
}
